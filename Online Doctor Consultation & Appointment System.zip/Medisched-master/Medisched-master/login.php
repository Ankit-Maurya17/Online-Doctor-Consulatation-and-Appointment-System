<?php
session_start();

// Database connection
$conn = new mysqli("localhost", "root", "", "MediSched");

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$error = '';

if (isset($_POST['login'])) {
    $type = $_POST['type'];
    $identifier = $_POST['email'];
    $pass = $_POST['pass'];
    
    // Validate input
    if (empty($identifier) || empty($pass)) {
        $error = "Please fill in all fields";
    } else {
        if ($type == "Doctor") {
            // Query for doctors
            $sql = "SELECT id FROM doctors WHERE email = ? AND pass = ?";
        } else if ($type == "Patient") {
            // Query for patients
            $sql = "SELECT id FROM patients WHERE (email = ? OR phone = ?) AND pass = ?";
        }

        if ($stmt = $conn->prepare($sql)) {
            if ($type == "Doctor") {
                $stmt->bind_param("ss", $identifier, $pass);
            } else {
                // Convert phone to integer if it's a number
                $phone = is_numeric($identifier) ? (int)$identifier : 0;
                $stmt->bind_param("sis", $identifier, $phone, $pass);
            }

            if (!$stmt->execute()) {
                $error = "Database error: " . $stmt->error;
            } else {
                $result = $stmt->get_result();

                if ($result->num_rows > 0) {
                    $_SESSION['user'] = $identifier;
                    if ($type == "Doctor") {
                        header("Location: doctor/index.php");
                    } else {
                        header("Location: patient/index.php");
                    }
                    exit();
                } else {
                    $error = "Invalid email/phone number or password";
                }
            }
            $stmt->close();
        } else {
            $error = "Database error: " . $conn->error;
        }
    }
}

// Close connection at the end
$conn->close();
?>

<!-- Login Form -->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - Medisched</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .login-container {
            max-width: 400px;
            margin: 100px auto;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
        }
        .form-label {
            font-weight: 500;
        }
        .form-text {
            color: #6c757d;
            font-size: 0.9rem;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="login-container">
            <h2 class="text-center mb-4">Login</h2>
            
            <?php if ($error): ?>
                <div class="alert alert-danger"><?php echo $error; ?></div>
            <?php endif; ?>

            <form method="POST" action="">
                <div class="mb-3">
                    <label for="type" class="form-label">User Type</label>
                    <select class="form-select" id="type" name="type" required>
                        <option value="Doctor">Doctor</option>
                        <option value="Patient">Patient</option>
                    </select>
                </div>
                
                <div class="mb-3">
                    <label for="email" class="form-label">Email/Phone</label>
                    <input type="text" class="form-control" id="email" name="email" required>
                    <div class="form-text">Enter email for doctors or email/phone number for patients</div>
                </div>
                
                <div class="mb-3">
                    <label for="pass" class="form-label">Password</label>
                    <input type="password" class="form-control" id="pass" name="pass" required>
                </div>
                
                <button type="submit" name="login" class="btn btn-primary w-100">Login</button>
            </form>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>