<?php
session_start();
$conn = new mysqli("localhost", "root", "", "MediSched");

if(isset($_POST['fgpass'])) {
    $phone = $_POST['phone'];	
    $email = $_POST['email'];
    $type = $_POST['type'];
    $pass = $_POST['npass'];
    $error = false;

    if(empty($phone) || empty($email) || empty($pass)) {
        $_SESSION['error_msg'] = "Please fill all the required fields";
        $error = true;
    }

    if(!$error) {
        if($type == "Doctor") {
            $sql = "SELECT email FROM doctors WHERE email = ? AND contact = ?";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("ss", $email, $phone);
            $stmt->execute();
            $result = $stmt->get_result();
            $count = $result->num_rows;

            if($count > 0) {
                $update_sql = "UPDATE doctors SET pass = ? WHERE email = ?";
                $update_stmt = $conn->prepare($update_sql);
                $update_stmt->bind_param("ss", $pass, $email);
                $update_stmt->execute();
                $_SESSION['success_msg'] = "Password updated successfully";
                header("location: index.php");
                exit();
            } else {
                $_SESSION['error_msg'] = "Invalid email or phone number";
            }
        } else if ($type == "Patient") {
            $sql = "SELECT email FROM patients WHERE email = ? AND phone = ?";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("ss", $email, $phone);
            $stmt->execute();
            $result = $stmt->get_result();
            $count = $result->num_rows;

            if($count > 0) {
                $update_sql = "UPDATE patients SET pass = ? WHERE email = ?";
                $update_stmt = $conn->prepare($update_sql);
                $update_stmt->bind_param("ss", $pass, $email);
                $update_stmt->execute();
                $_SESSION['success_msg'] = "Password updated successfully";
                header("location: index.php");
                exit();
            } else {
                $_SESSION['error_msg'] = "Invalid email or phone number";
            }
        }
    }

    // If we reach here, there was an error
    header("location: index.php");
    exit();
}

$conn->close();
?>