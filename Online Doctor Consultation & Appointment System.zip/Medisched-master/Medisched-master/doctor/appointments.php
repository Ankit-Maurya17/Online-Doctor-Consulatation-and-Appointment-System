<?php
session_start();
include('../includes/refresh_session.php');

// Database connection
$conn = new mysqli("localhost", "root", "", "Medisched_db");

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if user is logged in
if(!isset($_SESSION['user'])) {
    header("Location: ../login.php");
    exit();
}

// Get doctor details
$email = $_SESSION['user'];
$sql = "SELECT * FROM doctors WHERE email = '$email'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    $doctor = $result->fetch_assoc();
} else {
    header("Location: ../login.php");
    exit();
}

// Get filter parameter (today, past, upcoming, all)
$filter = isset($_GET['filter']) ? $_GET['filter'] : 'today';
$today = date('Y-m-d');

// Prepare the base SQL query
$appointments_sql = "SELECT 
    a.id, 
    a.date_time, 
    a.status, 
    a.patient_id,
    p.name as patient_name, 
    p.phone as patient_phone,
    p.email as patient_email
FROM appointments a 
INNER JOIN patients p ON a.patient_id = p.id 
WHERE a.doctor_id = ? ";

// Add filter condition based on user selection
switch($filter) {
    case 'past':
        $appointments_sql .= "AND DATE(a.date_time) < ? ";
        $date_param = $today;
        break;
    case 'upcoming':
        $appointments_sql .= "AND DATE(a.date_time) > ? ";
        $date_param = $today;
        break;
    case 'today':
        $appointments_sql .= "AND DATE(a.date_time) = ? ";
        $date_param = $today;
        break;
    case 'all':
        // No additional date filter for 'all'
        break;
}

$appointments_sql .= " ORDER BY a.date_time";

$stmt = $conn->prepare($appointments_sql);

// Bind parameters based on the filter
if ($filter == 'all') {
    $stmt->bind_param('i', $doctor['id']);
} else {
    $stmt->bind_param('is', $doctor['id'], $date_param);
}

$stmt->execute();
$appointments_result = $stmt->get_result();

// Debug information
if ($appointments_result->num_rows > 0) {
    $debug_data = $appointments_result->fetch_all(MYSQLI_ASSOC);
    echo "<!-- Debug: Found " . count($debug_data) . " appointments -->";
    $appointments_result->data_seek(0);
} else {
    echo "<!-- Debug: No appointments found -->";
}

if ($appointments_result === false) {
    die("Error in query: " . $conn->error);
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Today's Appointments - Medisched</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../assets/css/style.css">
    <style>
        .health-problem {
            max-height: 50px;
            overflow: hidden;
            text-overflow: ellipsis;
            display: -webkit-box;
            -webkit-line-clamp: 2;
            -webkit-box-orient: vertical;
        }
        .action-btn {
            margin-right: 5px;
        }
        .status-badge {
            padding: 5px 10px;
            border-radius: 15px;
        }
    </style>
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <nav id="sidebar" class="col-md-3 col-lg-2 d-md-block bg-light sidebar">
                <div class="position-sticky pt-3">
                    <ul class="nav flex-column">
                        <li class="nav-item">
                            <a class="nav-link" href="index.php">
                                <span data-feather="home"></span>
                                Dashboard
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link active" href="appointments.php">
                                <span data-feather="calendar"></span>
                                Appointments
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="profile.php">
                                <span data-feather="user"></span>
                                Profile
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="../logout.php">
                                <span data-feather="log-out"></span>
                                Logout
                            </a>
                        </li>
                    </ul>
                </div>
            </nav>

            <!-- Main content -->
            <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
                <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                    <h1 class="h2">Appointments</h1>
                    
                    <?php 
                    // Determine title based on filter
                    $filter_title = '';
                    switch($filter) {
                        case 'past':
                            $filter_title = 'Past Appointments';
                            break;
                        case 'upcoming':
                            $filter_title = 'Upcoming Appointments';
                            break;
                        case 'today':
                            $filter_title = 'Today\'s Appointments';
                            break;
                        case 'all':
                            $filter_title = 'All Appointments';
                            break;
                    }
                    ?>
                    <h5><?php echo $filter_title; ?></h5>
                </div>
                
                <!-- Appointment Filters -->
                <div class="btn-group mb-4" role="group" aria-label="Appointment filters">
                    <a href="appointments.php?filter=today" class="btn <?php echo $filter == 'today' ? 'btn-primary' : 'btn-outline-primary'; ?>">
                        <i class="fas fa-calendar-day"></i> Today
                    </a>
                    <a href="appointments.php?filter=upcoming" class="btn <?php echo $filter == 'upcoming' ? 'btn-primary' : 'btn-outline-primary'; ?>">
                        <i class="fas fa-calendar-plus"></i> Upcoming
                    </a>
                    <a href="appointments.php?filter=past" class="btn <?php echo $filter == 'past' ? 'btn-primary' : 'btn-outline-primary'; ?>">
                        <i class="fas fa-calendar-minus"></i> Past
                    </a>
                    <a href="appointments.php?filter=all" class="btn <?php echo $filter == 'all' ? 'btn-primary' : 'btn-outline-primary'; ?>">
                        <i class="fas fa-calendar-alt"></i> All
                    </a>
                </div>

                <!-- Appointments table -->
                <div class="table-responsive">
                    <table class="table table-striped table-sm">
                        <thead class="table-primary">
                            <tr>
                                <th>Name</th>
                                <th>Contact Number</th>
                                <th>Appointment Time</th>
                                <th>Status</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if($appointments_result->num_rows > 0): ?>
                                <?php while($appointment = $appointments_result->fetch_assoc()): ?>
                                <tr>
                                    <td>
                                        <?php 
                                        $name = $appointment['patient_name'] ?? '';
                                        echo !empty(trim($name)) ? htmlspecialchars($name) : 'N/A';
                                        ?>
                                    </td>
                                    <td>
                                        <?php 
                                        $phone = $appointment['patient_phone'] ?? '';
                                        echo !empty(trim($phone)) ? htmlspecialchars($phone) : 'N/A';
                                        ?>
                                    </td>
                                    <td><?php echo date('h:i A', strtotime($appointment['date_time'])); ?></td>
                                    <td>
                                        <?php 
                                        $status = $appointment['status'];
                                        switch($status) {
                                            case 'Pending':
                                                $status_class = 'bg-warning text-dark';
                                                break;
                                            case 'Confirmed':
                                                $status_class = 'bg-success text-white';
                                                break;
                                            case 'Cancelled':
                                                $status_class = 'bg-danger text-white';
                                                break;
                                            default:
                                                $status_class = 'bg-secondary text-white';
                                        }
                                        ?>
                                        <span class="badge <?php echo $status_class; ?>"><?php echo htmlspecialchars($status); ?></span>
                                    </td>
                                    <td>
                                        <div class="btn-group">
                                            <a href="appointment_details.php?id=<?php echo $appointment['id']; ?>" 
                                               class="btn btn-sm btn-info action-btn">View</a>
                                            <?php if($appointment['status'] == 'Pending' || $appointment['status'] == 'Confirmed'): ?>
                                                <button type="button" class="btn btn-sm btn-danger action-btn" 
                                                        onclick="handleCancelAppointment(<?php echo $appointment['id']; ?>)">
                                                    Cancel
                                                </button>
                                            <?php endif; ?>
                                        </div>
                                    </td>
                                </tr>
                                <?php endwhile; ?>
                            <?php else: ?>
                                <tr>
                                    <td colspan="5" class="text-center">
                                        <?php
                                        switch($filter) {
                                            case 'past':
                                                echo 'No past appointments found';
                                                break;
                                            case 'upcoming':
                                                echo 'No upcoming appointments scheduled';
                                                break;
                                            case 'today':
                                                echo 'No appointments scheduled for today';
                                                break;
                                            case 'all':
                                                echo 'No appointments found';
                                                break;
                                        }
                                        ?>
                                    </td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>

                <!-- Quick Actions -->
                <div class="card mt-4">
                    <div class="card-body">
                        <h5 class="card-title">Quick Actions</h5>
                        <div class="row">
                            <div class="col-md-4">
                                <div class="stat">
                                    <h6>Total Appointments</h6>
                                    <p class="stat-number"><?php echo $appointments_result->num_rows; ?></p>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="stat">
                                    <h6>Pending Appointments</h6>
                                    <p class="stat-number"><?php 
                                        $pending_sql = "SELECT COUNT(*) as count FROM appointments 
                                                       WHERE doctor_id = {$doctor['id']} 
                                                       AND DATE(date_time) = '$today' 
                                                       AND status = 'Pending'";
                                        $pending_result = $conn->query($pending_sql);
                                        $pending = $pending_result->fetch_assoc();
                                        echo $pending['count'];
                                    ?></p>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="stat">
                                    <h6>Confirmed Appointments</h6>
                                    <p class="stat-number"><?php 
                                        $confirmed_sql = "SELECT COUNT(*) as count FROM appointments 
                                                         WHERE doctor_id = {$doctor['id']} 
                                                         AND DATE(date_time) = '$today' 
                                                         AND status = 'Confirmed'";
                                        $confirmed_result = $conn->query($confirmed_sql);
                                        $confirmed = $confirmed_result->fetch_assoc();
                                        echo $confirmed['count'];
                                    ?></p>
                                </div>
                            </div>
                        </div>
                        <div class="mt-4">
                            <a href="patient_records.php" class="btn btn-primary">View Patient Records</a>
                        </div>
                    </div>
                </div>
            </main>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/feather-icons/dist/feather.min.js"></script>
    <script>
        feather.replace()
    </script>
<!-- Add Font Awesome for icons -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">

<script>
// Function to handle appointment cancellation
function handleCancelAppointment(appointmentId) {
    if (confirm('Are you sure you want to cancel this appointment?')) {
        // Show loading state on all matching buttons
        const cancelBtns = document.querySelectorAll(`button[onclick="handleCancelAppointment(${appointmentId})"]`);
        cancelBtns.forEach(btn => {
            btn.disabled = true;
            btn.innerHTML = '<span class="spinner-border spinner-border-sm" role="status"></span> Processing';
        });

        fetch('cancel_appointment.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                appointment_id: appointmentId
            })
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                alert('Appointment cancelled successfully');
                location.reload();
            } else {
                alert('Error: ' + data.message);
                cancelBtns.forEach(btn => {
                    btn.disabled = false;
                    btn.innerHTML = 'Cancel';
                });
            }
        })
        .catch(error => {
            console.error('Error:', error);
            alert('Failed to cancel appointment');
            cancelBtns.forEach(btn => {
                btn.disabled = false;
                btn.innerHTML = 'Cancel';
            });
        });
    }
}

// Function to handle appointment rescheduling
document.addEventListener('DOMContentLoaded', function() {
    const rescheduleForm = document.querySelectorAll('[id^="rescheduleForm"]');
    rescheduleForm.forEach(form => {
        form.addEventListener('submit', function(e) {
            e.preventDefault();
            const appointmentId = this.id.replace('rescheduleForm', '');
            const newDateTime = this.querySelector('[name="new_datetime"]').value;

            fetch('reschedule_appointment.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    appointment_id: appointmentId,
                    new_datetime: newDateTime
                })
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    alert('Appointment rescheduled successfully');
                    location.reload();
                } else {
                    alert('Error rescheduling appointment: ' + data.message);
                }
            })
            .catch(error => {
                console.error('Error:', error);
                alert('Error rescheduling appointment');
            });
        });
    });
});
</script>

</body>
</html>
