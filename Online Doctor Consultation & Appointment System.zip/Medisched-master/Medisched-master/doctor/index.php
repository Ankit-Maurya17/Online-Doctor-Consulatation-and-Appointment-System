<?php
session_start();
include('../includes/refresh_session.php');

// Database connection
$conn = new mysqli("localhost", "root", "", "Medisched_db");

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if user is logged in
if(!isset($_SESSION['user'])) {
    header("Location: ../login.php");
    exit();
}

// Get doctor details
$email = $_SESSION['user'];
$sql = "SELECT * FROM doctors WHERE email = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $email);
$stmt->execute();
$result = $stmt->get_result();
$stmt->close();

if ($result->num_rows > 0) {
    $doctor = $result->fetch_assoc();
} else {
    header("Location: ../login.php");
    exit();
}

// Get appointment statistics
$stats_sql = "SELECT 
                (SELECT COUNT(*) FROM appointments WHERE doctor_id = ?) as total_appointments,
                (SELECT COUNT(*) FROM appointments WHERE doctor_id = ? AND status = 'Pending') as pending_appointments,
                (SELECT COUNT(*) FROM appointments WHERE doctor_id = ? AND status = 'Confirmed') as confirmed_appointments,
                (SELECT COUNT(*) FROM appointments WHERE doctor_id = ? AND status = 'Cancelled') as cancelled_appointments";

$stmt = $conn->prepare($stats_sql);
$stmt->bind_param("iiii", $doctor['id'], $doctor['id'], $doctor['id'], $doctor['id']);
$stmt->execute();
$stats_result = $stmt->get_result();
$stats = $stats_result->fetch_assoc();
$stmt->close();

// Get today's statistics
$today = date('Y-m-d');
$today_stats_sql = "SELECT COUNT(*) as total_today, 
                    SUM(CASE WHEN status = 'Pending' THEN 1 ELSE 0 END) as pending_today,
                    SUM(CASE WHEN status = 'Confirmed' THEN 1 ELSE 0 END) as confirmed_today,
                    SUM(CASE WHEN status = 'Cancelled' THEN 1 ELSE 0 END) as cancelled_today
                    FROM appointments 
                    WHERE doctor_id = ? 
                    AND DATE(date_time) = ?";

$stmt = $conn->prepare($today_stats_sql);
$stmt->bind_param("is", $doctor['id'], $today);
$stmt->execute();
$today_stats = $stmt->get_result()->fetch_assoc();
$stmt->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Doctor Dashboard - Medisched</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.7.2/font/bootstrap-icons.css">
    <style>
        .dashboard-header {
            background: linear-gradient(135deg, #6366f1, #818cf8);
            color: white;
            padding: 2rem 1rem;
            margin-bottom: 2rem;
            border-radius: 10px;
        }
        .dashboard-header h1 {
            margin: 0;
            font-size: 2rem;
        }
        .dashboard-header p {
            margin: 0;
            font-size: 1.1rem;
            opacity: 0.9;
        }
        .stat-card {
            background: white;
            border-radius: 10px;
            padding: 1.5rem;
            margin-bottom: 1rem;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            transition: transform 0.3s ease;
        }
        .stat-card:hover {
            transform: translateY(-5px);
        }
        .stat-icon {
            font-size: 2rem;
            margin-bottom: 1rem;
        }
        .stat-number {
            font-size: 1.5rem;
            font-weight: bold;
            margin-bottom: 0.5rem;
        }
        .stat-label {
            color: #64748b;
            font-size: 0.9rem;
        }
        .bg-light-blue {
            background-color: #e3f2fd !important;
            color: #1976d2;
        }
        .bg-light-yellow {
            background-color: #fff3cd !important;
            color: #856404;
        }
        .bg-light-green {
            background-color: #d4edda !important;
            color: #28a745;
        }
        .bg-light-red {
            background-color: #f8d7da !important;
            color: #dc3545;
        }
        .feature-card {
            background: white;
            border-radius: 10px;
            padding: 1.5rem;
            margin-bottom: 1rem;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            transition: transform 0.3s ease;
        }
        .feature-card:hover {
            transform: translateY(-5px);
        }
        .feature-icon {
            font-size: 2rem;
            margin-bottom: 1rem;
            color: #6366f1;
        }
        .progress {
            height: 8px;
            border-radius: 4px;
            margin-top: 0.5rem;
        }
    </style>
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <nav id="sidebar" class="col-md-3 col-lg-2 d-md-block bg-light sidebar">
                <div class="position-sticky pt-3">
                    <ul class="nav flex-column">
                        <li class="nav-item">
                            <a class="nav-link active" href="index.php">
                                <i class="bi bi-house-door"></i>
                                Dashboard
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="appointments.php">
                                <i class="bi bi-calendar-check"></i>
                                Appointments
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="patient_records.php">
                                <i class="bi bi-people"></i>
                                Patient Records
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="profile.php">
                                <i class="bi bi-person"></i>
                                Profile
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="../logout.php">
                                <i class="bi bi-box-arrow-right"></i>
                                Logout
                            </a>
                        </li>
                    </ul>
                </div>
            </nav>

            <!-- Main content -->
            <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
                <!-- Dashboard Header -->
                <div class="dashboard-header">
                    <div class="container">
                        <div class="row align-items-center">
                            <div class="col-md-8">
                                <h1>Welcome <?php echo htmlspecialchars($doctor['name']); ?></h1>
                                <p>Here's a quick overview of your appointments</p>
                            </div>
                            <div class="col-md-4 text-end">
                                <div class="d-flex justify-content-end">
                                    <div class="me-3">
                                        <span class="badge bg-primary">Total Appointments: <?php echo $stats['total_appointments']; ?></span>
                                    </div>
                                    <div>
                                        <span class="badge bg-success">Pending: <?php echo $stats['pending_appointments']; ?></span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Appointment Statistics -->
                <div class="row mb-4">
                    <div class="col-md-3">
                        <div class="stat-card bg-light-blue">
                            <div class="stat-icon">
                                <i class="bi bi-calendar4-week"></i>
                            </div>
                            <div class="stat-number"><?php echo $stats['total_appointments']; ?></div>
                            <div class="stat-label">Total Appointments</div>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="stat-card bg-light-yellow">
                            <div class="stat-icon">
                                <i class="bi bi-hourglass"></i>
                            </div>
                            <div class="stat-number"><?php echo $stats['pending_appointments']; ?></div>
                            <div class="stat-label">Pending Appointments</div>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="stat-card bg-light-green">
                            <div class="stat-icon">
                                <i class="bi bi-check-circle"></i>
                            </div>
                            <div class="stat-number"><?php echo $stats['confirmed_appointments']; ?></div>
                            <div class="stat-label">Confirmed Appointments</div>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="stat-card bg-light-red">
                            <div class="stat-icon">
                                <i class="bi bi-x-circle"></i>
                            </div>
                            <div class="stat-number"><?php echo $stats['cancelled_appointments']; ?></div>
                            <div class="stat-label">Cancelled Appointments</div>
                        </div>
                    </div>
                </div>

                <!-- Features -->
                <div class="row mb-4">
                    <div class="col-md-4">
                        <div class="feature-card">
                            <div class="feature-icon">
                                <i class="bi bi-calendar-check"></i>
                            </div>
                            <h5>Manage Appointments</h5>
                            <p>View, confirm, and manage all your appointments.</p>
                            <a href="appointments.php" class="btn btn-primary btn-sm">View Appointments</a>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="feature-card">
                            <div class="feature-icon">
                                <i class="bi bi-people"></i>
                            </div>
                            <h5>Patient Records</h5>
                            <p>Access and manage your patient records.</p>
                            <a href="patient_records.php" class="btn btn-primary btn-sm">View Records</a>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="feature-card">
                            <div class="feature-icon">
                                <i class="bi bi-person"></i>
                            </div>
                            <h5>Profile Settings</h5>
                            <p>Update your personal information and settings.</p>
                            <a href="profile.php" class="btn btn-primary btn-sm">Update Profile</a>
                        </div>
                    </div>
                </div>

                <!-- Patient Appointment History -->
                <div class="appointment-history mb-5">
                    <div class="d-flex justify-content-between align-items-center mb-4">
                        <h5>Patient Appointment History</h5>
                        <div class="d-flex align-items-center">
                            <select class="form-select form-select-sm" id="historyFilter" style="width: auto;">
                                <option value="all">All Time</option>
                                <option value="today">Today</option>
                                <option value="week">This Week</option>
                                <option value="month">This Month</option>
                            </select>
                            <input type="text" class="form-control form-control-sm" id="patientSearch" placeholder="Search patient..." style="width: 200px;">
                        </div>
                    </div>
                    
                    <?php
                    // Get all appointments with patient details and history
                    $history_sql = "SELECT 
                                    a.id,
                                    a.patient_id,
                                    a.date_time,
                                    a.status,
                                    p.name as patient_name, 
                                    p.phone as patient_phone,
                                    p.email as patient_email,
                                    (SELECT COUNT(*) 
                                     FROM appointments prev 
                                     WHERE prev.patient_id = p.id 
                                     AND prev.doctor_id = a.doctor_id 
                                     AND prev.date_time <= a.date_time) as visit_count
                                FROM appointments a 
                                INNER JOIN patients p ON a.patient_id = p.id 
                                WHERE a.doctor_id = ? 
                                ORDER BY a.date_time DESC";
                    
                    $stmt = $conn->prepare($history_sql);
                    $stmt->bind_param("i", $doctor['id']);
                    $stmt->execute();
                    $history_result = $stmt->get_result();
                    $stmt->close();
                    ?>
                    
                    <div class="table-responsive">
                        <table class="table table-hover" id="appointmentHistoryTable">
                            <thead>
                                <tr>
                                    <th>Patient Name</th>
                                    <th>Contact</th>
                                    <th>Date & Time</th>
                                    <th>Visit #</th>
                                    <th>Status</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php while($appointment = $history_result->fetch_assoc()): ?>
                                <tr>
                                    <td>
                                        <div><?php echo htmlspecialchars($appointment['patient_name']); ?></div>
                                        <small class="text-muted"><?php echo htmlspecialchars($appointment['patient_email']); ?></small>
                                    </td>
                                    <td><?php echo htmlspecialchars($appointment['patient_phone']); ?></td>
                                    <td>
                                        <div><?php echo date('Y-m-d', strtotime($appointment['date_time'])); ?></div>
                                        <small class="text-muted"><?php echo date('H:i', strtotime($appointment['date_time'])); ?></small>
                                    </td>
                                    <td>
                                        <span class="badge bg-info"><?php echo $appointment['visit_count']; ?></span>
                                    </td>
                                    <td>
                                        <span class="badge bg-<?php echo ($appointment['status'] == 'Confirmed') ? 'success' : (($appointment['status'] == 'Cancelled') ? 'danger' : 'warning'); ?>">
                                            <?php echo htmlspecialchars($appointment['status']); ?>
                                        </span>
                                    </td>
                                    <td>
                                        <div class="btn-group">
                                            <a href="patient_records.php?patient_id=<?php echo $appointment['patient_id']; ?>" class="btn btn-sm btn-primary">
                                                View Details
                                            </a>
                                            <button type="button" class="btn btn-sm btn-outline-primary dropdown-toggle dropdown-toggle-split" data-bs-toggle="dropdown">
                                                <span class="visually-hidden">Toggle Dropdown</span>
                                            </button>
                                            <ul class="dropdown-menu">
                                                <li><a class="dropdown-item" href="#" onclick="updateStatus(<?php echo $appointment['id']; ?>, 'Confirmed')">Mark Confirmed</a></li>
                                                <li><a class="dropdown-item" href="#" onclick="updateStatus(<?php echo $appointment['id']; ?>, 'Cancelled')">Mark Cancelled</a></li>
                                                <li><hr class="dropdown-divider"></li>
                                                <li><a class="dropdown-item" href="#" onclick="viewHistory(<?php echo $appointment['patient_id']; ?>)">Full History</a></li>
                                            </ul>
                                        </div>
                                    </td>
                                </tr>
                                <?php endwhile; ?>
                            </tbody>
                        </table>
                    </div>
                </div>

                <script>
                document.getElementById('historyFilter').addEventListener('change', function() {
                    filterAppointments();
                });

                document.getElementById('patientSearch').addEventListener('input', function() {
                    filterAppointments();
                });

                function filterAppointments() {
                    const filter = document.getElementById('historyFilter').value;
                    const search = document.getElementById('patientSearch').value.toLowerCase();
                    const rows = document.querySelectorAll('#appointmentHistoryTable tbody tr');

                    rows.forEach(row => {
                        const date = new Date(row.cells[2].querySelector('div').textContent);
                        const patientName = row.cells[0].querySelector('div').textContent.toLowerCase();
                        const today = new Date();
                        let show = true;

                        // Filter by date
                        if (filter === 'today') {
                            show = date.toDateString() === today.toDateString();
                        } else if (filter === 'week') {
                            const weekAgo = new Date(today.getTime() - 7 * 24 * 60 * 60 * 1000);
                            show = date >= weekAgo;
                        } else if (filter === 'month') {
                            const monthAgo = new Date(today.getFullYear(), today.getMonth() - 1, today.getDate());
                            show = date >= monthAgo;
                        }

                        // Filter by patient name
                        if (show && search) {
                            show = patientName.includes(search);
                        }

                        row.style.display = show ? '' : 'none';
                    });
                }

                function updateStatus(appointmentId, status) {
                    // Add your status update logic here
                    console.log(`Update appointment ${appointmentId} to ${status}`);
                }

                function viewHistory(patientId) {
                    window.location.href = `patient_records.php?patient_id=${patientId}&show=history`;
                }
                </script>
                </div>
            </main>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script>
        // Add any additional JavaScript here
    </script>
</body>
</html>
