<?php
// Database connection
$host = "localhost";
$username = "root";
$password = "";
$database = "medisched_db";

$conn = new mysqli($host, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Create prescriptions table
$sql = "CREATE TABLE IF NOT EXISTS prescriptions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    appointment_id INT NOT NULL,
    prescription_text TEXT NOT NULL,
    next_visit_date DATE,
    follow_up_instructions TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (appointment_id) REFERENCES appointments(id)
)";

if ($conn->query($sql) === TRUE) {
    echo "Prescriptions table created successfully";
} else {
    echo "Error creating table: " . $conn->error;
}

$conn->close();
?>
