<?php
session_start();
header('Content-Type: application/json');

// Enable error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Log function for debugging
function debug_log($message) {
    file_put_contents('reschedule_debug.log', date('Y-m-d H:i:s') . ' - ' . $message . "\n", FILE_APPEND);
}

debug_log('Reschedule request received');

// Database connection
debug_log('Attempting database connection');
$conn = new mysqli("localhost", "root", "", "Medisched_db");

if ($conn->connect_error) {
    debug_log('Database connection failed: ' . $conn->connect_error);
    echo json_encode(['success' => false, 'message' => 'Database connection failed: ' . $conn->connect_error]);
    exit();
}
debug_log('Database connection successful');

// Check if user is logged in
debug_log('Checking if user is logged in');
if(!isset($_SESSION['user'])) {
    debug_log('User not logged in');
    echo json_encode(['success' => false, 'message' => 'User not logged in']);
    exit();
}
debug_log('User is logged in: ' . $_SESSION['user']);

// Get appointment ID and new datetime
debug_log('Getting request parameters');
$appointment_id = isset($_POST['appointment_id']) ? intval($_POST['appointment_id']) : 0;
$new_date = isset($_POST['new_date']) ? $_POST['new_date'] : '';
$new_time = isset($_POST['new_time']) ? $_POST['new_time'] : '';
$reason = isset($_POST['reason']) ? $_POST['reason'] : 'Rescheduled by doctor';

debug_log('Parameters: ID=' . $appointment_id . ', Date=' . $new_date . ', Time=' . $new_time . ', Reason=' . $reason);

if(empty($appointment_id) || empty($new_date) || empty($new_time)) {
    debug_log('Missing required parameters');
    echo json_encode(['success' => false, 'message' => 'Missing required parameters']);
    exit();
}
debug_log('All required parameters present');

// Combine date and time
$new_datetime = $new_date . ' ' . $new_time . ':00';
debug_log('Combined datetime: ' . $new_datetime);

// Update appointment
debug_log('Preparing SQL statement');
$sql = "UPDATE appointments SET 
        date_time = ?, 
        status = 'Rescheduled', 
        reschedule_reason = ?, 
        updated_at = NOW() 
    WHERE id = ?";

try {
    $stmt = $conn->prepare($sql);
    if (!$stmt) {
        debug_log('Prepare statement failed: ' . $conn->error);
        echo json_encode(['success' => false, 'message' => 'Prepare statement failed: ' . $conn->error]);
        exit();
    }
    debug_log('SQL statement prepared successfully');
    
    debug_log('Binding parameters');
    $bind_result = $stmt->bind_param("ssi", $new_datetime, $reason, $appointment_id);
    if (!$bind_result) {
        debug_log('Parameter binding failed: ' . $stmt->error);
        echo json_encode(['success' => false, 'message' => 'Parameter binding failed: ' . $stmt->error]);
        exit();
    }
    debug_log('Parameters bound successfully');
    
    debug_log('Executing statement');
    if($stmt->execute()) {
        debug_log('Appointment rescheduled successfully');
        echo json_encode(['success' => true, 'message' => 'Appointment rescheduled successfully']);
    } else {
        debug_log('Failed to execute statement: ' . $stmt->error);
        echo json_encode(['success' => false, 'message' => 'Failed to reschedule appointment: ' . $stmt->error]);
    }
} catch (Exception $e) {
    debug_log('Exception caught: ' . $e->getMessage());
    echo json_encode(['success' => false, 'message' => 'Exception: ' . $e->getMessage()]);
}

debug_log('Closing statement and connection');
$stmt->close();
$conn->close();
debug_log('Process completed');
?>
