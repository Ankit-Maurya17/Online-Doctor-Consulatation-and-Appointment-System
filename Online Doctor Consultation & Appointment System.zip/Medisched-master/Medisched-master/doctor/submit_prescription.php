<?php
session_start();

// Database connection
$host = "localhost";
$username = "root";
$password = "";
$database = "Medisched_db";

$conn = new mysqli($host, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    echo json_encode(['success' => false, 'message' => 'Database connection failed: ' . $conn->connect_error]);
    exit;
}

// Check if required parameters are provided
if (!isset($_POST['appointment_id']) || !isset($_POST['prescription_text'])) {
    echo json_encode(['success' => false, 'message' => 'Required parameters missing']);
    exit;
}

$appointment_id = $_POST['appointment_id'];
$prescription_text = $_POST['prescription_text'];
$next_visit_date = isset($_POST['next_visit_date']) ? $_POST['next_visit_date'] : null;
$follow_up_instructions = isset($_POST['follow_up_instructions']) ? $_POST['follow_up_instructions'] : null;

// Prepare and execute query to insert prescription
$sql = "INSERT INTO prescriptions (
            appointment_id,
            prescription_text,
            next_visit_date,
            follow_up_instructions,
            created_at
        ) VALUES (?, ?, ?, ?, NOW())";

$stmt = $conn->prepare($sql);
if (!$stmt) {
    echo json_encode(['success' => false, 'message' => 'Error preparing query: ' . $conn->error]);
    exit;
}

$stmt->bind_param("isss", $appointment_id, $prescription_text, $next_visit_date, $follow_up_instructions);
$result = $stmt->execute();

if ($result) {
    echo json_encode(['success' => true, 'message' => 'Prescription submitted successfully']);
} else {
    echo json_encode(['success' => false, 'message' => 'Error submitting prescription: ' . $stmt->error]);
}

$stmt->close();
$conn->close();
?>
