<?php
session_start();

// Database connection
$host = "localhost";
$username = "root";
$password = "";
$database = "medisched_db";

$conn = new mysqli($host, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    echo json_encode(['success' => false, 'message' => 'Database connection failed: ' . $conn->connect_error]);
    exit;
}

// Check if appointment_id is provided
if (!isset($_POST['appointment_id'])) {
    echo json_encode(['success' => false, 'message' => 'Appointment ID is required']);
    exit;
}

$appointment_id = $_POST['appointment_id'];

// Prepare and execute query
$sql = "SELECT 
            p.name as patient_name,
            p.phone as patient_phone,
            p.email as patient_email,
            a.date_time as appointment_time,
            a.created_at as booking_time,
            a.reason as reason,
            a.status as status,
            pr.prescription_text,
            pr.next_visit_date,
            pr.follow_up_instructions
        FROM appointments a 
        JOIN patients p ON a.patient_id = p.id 
        LEFT JOIN prescriptions pr ON a.id = pr.appointment_id
        WHERE a.id = ?";

$stmt = $conn->prepare($sql);
if (!$stmt) {
    echo json_encode(['success' => false, 'message' => 'Error preparing query: ' . $conn->error]);
    exit;
}

$stmt->bind_param("i", $appointment_id);
$result = $stmt->execute();

if ($result) {
    $appointment = $stmt->get_result()->fetch_assoc();
    
    if ($appointment) {
        // Format dates
        $appointment['appointment_time'] = date('M d, Y h:i A', strtotime($appointment['appointment_time']));
        $appointment['booking_time'] = date('Y-m-d H:i:s', strtotime($appointment['booking_time']));
        
        // Prepare prescription data
        $prescription = [];
        if (!empty($appointment['prescription_text'])) {
            $prescription = [
                'text' => trim($appointment['prescription_text']),
                'next_visit_date' => $appointment['next_visit_date'] ? date('Y-m-d', strtotime($appointment['next_visit_date'])) : null,
                'follow_up_instructions' => $appointment['follow_up_instructions']
            ];
        }

        echo json_encode([
            'success' => true,
            'data' => [
                'patient_name' => $appointment['patient_name'] ?? '',
                'patient_phone' => $appointment['patient_phone'] ?? '',
                'patient_email' => $appointment['patient_email'] ?? '',
                'appointment_time' => $appointment['appointment_time'] ?? '',
                'booking_time' => $appointment['booking_time'] ?? '',
                'reason' => $appointment['reason'] ?? '',
                'status' => $appointment['status'] ?? '',
                'prescription' => $prescription
            ]
        ]);
    } else {
        echo json_encode(['success' => false, 'message' => 'Appointment not found']);
    }
} else {
    echo json_encode(['success' => false, 'message' => 'Error executing query: ' . $stmt->error]);
}

$stmt->close();
$conn->close();
?>
