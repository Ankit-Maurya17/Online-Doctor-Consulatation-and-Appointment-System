<?php
session_start();

// Database connection
$host = "localhost";
$username = "root";
$password = "";
$database = "medisched_db";

$conn = new mysqli($host, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    echo json_encode(['success' => false, 'message' => 'Database connection failed: ' . $conn->connect_error]);
    exit;
}

// Check if required parameters are provided
if (!isset($_POST['appointment_id']) || !isset($_POST['status'])) {
    echo json_encode(['success' => false, 'message' => 'Required parameters missing']);
    exit;
}

$appointment_id = $_POST['appointment_id'];
$status = $_POST['status'];

// Prepare and execute query to update appointment status
$sql = "UPDATE appointments SET status = ? WHERE id = ?";

$stmt = $conn->prepare($sql);
if (!$stmt) {
    echo json_encode(['success' => false, 'message' => 'Error preparing query: ' . $conn->error]);
    exit;
}

$stmt->bind_param("si", $status, $appointment_id);
$result = $stmt->execute();

if ($result) {
    echo json_encode(['success' => true, 'message' => 'Appointment status updated successfully']);
} else {
    echo json_encode(['success' => false, 'message' => 'Error updating appointment status: ' . $stmt->error]);
}

$stmt->close();
$conn->close();
?>
