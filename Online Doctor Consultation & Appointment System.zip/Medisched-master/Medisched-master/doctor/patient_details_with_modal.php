<?php
// Include the original patient details page
include_once('patient_details.php');

// Include the cancel appointment modal
include_once('cancel_appointment_modal.php');
?>
