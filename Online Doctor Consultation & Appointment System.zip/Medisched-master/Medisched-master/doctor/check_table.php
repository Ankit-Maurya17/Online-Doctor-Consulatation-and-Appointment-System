<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Database connection
$conn = new mysqli("localhost", "root", "", "Medisched_db");

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if reschedule_reason column exists
$sql = "SHOW COLUMNS FROM appointments LIKE 'reschedule_reason'"; 
$result = $conn->query($sql);

if ($result->num_rows == 0) {
    echo "<p>The 'reschedule_reason' column does not exist. Adding it now...</p>";
    
    // Add the column if it doesn't exist
    $alter_sql = "ALTER TABLE appointments ADD COLUMN reschedule_reason VARCHAR(255) DEFAULT NULL AFTER status";
    if ($conn->query($alter_sql) === TRUE) {
        echo "<p>Column 'reschedule_reason' added successfully.</p>";
    } else {
        echo "<p>Error adding column: " . $conn->error . "</p>";
    }
} else {
    echo "<p>The 'reschedule_reason' column already exists.</p>";
}

// Show the current structure of the appointments table
echo "<h3>Current structure of the appointments table:</h3>";
$structure_sql = "DESCRIBE appointments";
$structure_result = $conn->query($structure_sql);

if ($structure_result->num_rows > 0) {
    echo "<table border='1'>";
    echo "<tr><th>Field</th><th>Type</th><th>Null</th><th>Key</th><th>Default</th><th>Extra</th></tr>";
    
    while($row = $structure_result->fetch_assoc()) {
        echo "<tr>";
        echo "<td>" . $row["Field"] . "</td>";
        echo "<td>" . $row["Type"] . "</td>";
        echo "<td>" . $row["Null"] . "</td>";
        echo "<td>" . $row["Key"] . "</td>";
        echo "<td>" . $row["Default"] . "</td>";
        echo "<td>" . $row["Extra"] . "</td>";
        echo "</tr>";
    }
    
    echo "</table>";
} else {
    echo "<p>No results found.</p>";
}

$conn->close();
?>
