<?php
session_start();
include("../includes/refresh_session.php");

if(!isset($_SESSION['user'])){
    header("location:../index.php");
    exit();
}

// Refresh session data
refresh_session_data('doctor');

// Database connection
$conn = new mysqli("localhost", "root", "", "MediSched");

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get doctor's ID
$doctor_id = $_SESSION['user'];

// Get notifications for this doctor
$sql = "SELECT n.*, p.name as patient_name, b.date, b.time 
        FROM notifications n 
        JOIN patients p ON n.patient_email = p.email 
        JOIN bookings b ON n.appointment_id = b.id 
        WHERE n.doctor_id = ? 
        ORDER BY n.created_at DESC";

$stmt = $conn->prepare($sql);
if ($stmt === false) {
    die("Error preparing statement: " . $conn->error);
}

$stmt->bind_param("i", $doctor_id);
if ($stmt->execute() === false) {
    die("Error executing statement: " . $stmt->error);
}

$result = $stmt->get_result();
$notifications = $result->fetch_all(MYSQLI_ASSOC);
$stmt->close();

// Mark notifications as read
if(isset($_POST['mark_read'])) {
    $notification_ids = $_POST['notification_ids'];
    
    foreach($notification_ids as $id) {
        $update_sql = "UPDATE notifications SET status = 'read' WHERE id = ?";
        $update_stmt = $conn->prepare($update_sql);
        
        if ($update_stmt === false) {
            die("Error preparing update statement: " . $conn->error);
        }
        
        $update_stmt->bind_param("i", $id);
        if ($update_stmt->execute() === false) {
            die("Error updating notification: " . $update_stmt->error);
        }
        $update_stmt->close();
    }
    
    header("location: notifications.php");
    exit();
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Notifications - Medisched</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        .notifications-container {
            max-width: 1000px;
            margin: 50px auto;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
        }
        .notification-item {
            border-bottom: 1px solid #ddd;
            padding: 15px 0;
        }
        .notification-item:last-child {
            border-bottom: none;
        }
        .unread {
            font-weight: bold;
        }
        .notification-actions {
            margin-top: 10px;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="notifications-container">
            <h2 class="text-center mb-4">Appointment Notifications</h2>
            
            <?php if(empty($notifications)): ?>
                <div class="text-center py-5">
                    <i class="fas fa-bell-slash fa-3x text-muted mb-3"></i>
                    <p class="text-muted">No notifications yet</p>
                </div>
            <?php else: ?>
                <form method="POST" action="" class="mb-4">
                    <div class="notification-actions">
                        <button type="submit" name="mark_read" class="btn btn-outline-primary">
                            Mark Selected as Read
                        </button>
                    </div>
                    
                    <div class="table-responsive">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th><input type="checkbox" id="select-all"></th>
                                    <th>Patient</th>
                                    <th>Appointment Details</th>
                                    <th>Date</th>
                                    <th>Time</th>
                                    <th>Status</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach($notifications as $notification): ?>
                                    <tr class="<?php echo $notification['status'] == 'unread' ? 'unread' : ''; ?>">
                                        <td>
                                            <input type="checkbox" name="notification_ids[]" value="<?php echo $notification['id']; ?>">
                                        </td>
                                        <td><?php echo htmlspecialchars($notification['patient_name']); ?></td>
                                        <td>
                                            <pre><?php echo htmlspecialchars($notification['message']); ?></pre>
                                        </td>
                                        <td><?php echo htmlspecialchars($notification['date']); ?></td>
                                        <td><?php echo htmlspecialchars($notification['time']); ?></td>
                                        <td>
                                            <span class="badge bg-<?php echo $notification['status'] == 'unread' ? 'primary' : 'secondary'; ?>">
                                                <?php echo ucfirst($notification['status']); ?>
                                            </span>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </form>
            <?php endif; ?>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Select all checkbox functionality
        document.getElementById('select-all').addEventListener('change', function(e) {
            const checkboxes = document.querySelectorAll('input[type="checkbox"][name="notification_ids[]"]');
            checkboxes.forEach(checkbox => {
                checkbox.checked = e.target.checked;
            });
        });
    </script>
</body>
</html>
