<?php
session_start();
header('Content-Type: application/json');

// Database connection
$conn = new mysqli("localhost", "root", "", "Medisched_db");

if ($conn->connect_error) {
    echo json_encode(['success' => false, 'message' => 'Database connection failed']);
    exit();
}

// Check if user is logged in
if(!isset($_SESSION['user'])) {
    echo json_encode(['success' => false, 'message' => 'User not logged in']);
    exit();
}

// Get doctor details
$email = $_SESSION['user'];
$sql = "SELECT * FROM doctors WHERE email = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $email);
$stmt->execute();
$result = $stmt->get_result();
$doctor = $result->fetch_assoc();
$stmt->close();

if (!$doctor) {
    echo json_encode(['success' => false, 'message' => 'Doctor not found']);
    exit();
}

// Get JSON data
$json = file_get_contents('php://input');
$data = json_decode($json, true);

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $appointment_id = $data['appointment_id'] ?? '';
    $new_datetime = $data['new_datetime'] ?? '';
    
    if(empty($appointment_id) || empty($new_datetime)) {
        echo json_encode(['success' => false, 'message' => 'Appointment ID and new datetime are required']);
        exit();
    }

    // Check if appointment exists and belongs to the doctor
    $check_sql = "SELECT a.*, p.name as patient_name, p.phone as patient_phone 
                  FROM appointments a 
                  JOIN patients p ON a.patient_id = p.id 
                  WHERE a.id = ? AND a.doctor_id = ?";
    $check_stmt = $conn->prepare($check_sql);
    $check_stmt->bind_param("ii", $appointment_id, $doctor['id']);
    $check_stmt->execute();
    $appointment = $check_stmt->get_result()->fetch_assoc();
    $check_stmt->close();

    if (!$appointment) {
        echo json_encode(['success' => false, 'message' => 'Appointment not found or unauthorized']);
        exit();
    }

    // Update appointment date/time
    $sql = "UPDATE appointments 
            SET date_time = ?,
                status = 'Rescheduled',
                reschedule_reason = 'Rescheduled by doctor'
            WHERE id = ? 
            AND doctor_id = ?";
    
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sii", $new_datetime, $appointment_id, $doctor['id']);
    
    if($stmt->execute()) {
        echo json_encode([
            'success' => true, 
            'message' => 'Appointment rescheduled successfully',
            'new_datetime' => date('F j, Y h:i A', strtotime($new_datetime))
        ]);
    } else {
        echo json_encode(['success' => false, 'message' => 'Error rescheduling appointment: ' . $conn->error]);
    }
    $stmt->close();
} else {
    echo json_encode(['success' => false, 'message' => 'Invalid request method']);
}

$conn->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reschedule Appointment - Medisched</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <nav id="sidebar" class="col-md-3 col-lg-2 d-md-block bg-light sidebar">
                <div class="position-sticky pt-3">
                    <ul class="nav flex-column">
                        <li class="nav-item">
                            <a class="nav-link" href="index.php">
                                <span data-feather="home"></span>
                                Dashboard
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="appointments.php">
                                <span data-feather="calendar"></span>
                                Appointments
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="profile.php">
                                <span data-feather="user"></span>
                                Profile
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="../logout.php">
                                <span data-feather="log-out"></span>
                                Logout
                            </a>
                        </li>
                    </ul>
                </div>
            </nav>

            <!-- Main content -->
            <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
                <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                    <h1 class="h2">Reschedule Appointment</h1>
                </div>

                <!-- Success message -->
                <?php if(isset($_GET['success'])): ?>
                <div class="alert alert-success">
                    Appointment rescheduled successfully!
                </div>
                <?php endif; ?>

                <!-- Error message -->
                <?php if(isset($error)): ?>
                <div class="alert alert-danger">
                    <?php echo htmlspecialchars($error); ?>
                </div>
                <?php endif; ?>

                <!-- Reschedule form -->
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title">Appointment Details</h5>
                        <p><strong>Patient:</strong> <?php echo htmlspecialchars($appointment['patient_name']); ?></p>
                        <p><strong>Current Time:</strong> <?php echo date('F j, Y h:i A', strtotime($appointment['date_time'])); ?></p>
                        
                        <form method="POST" action="">
                            <input type="hidden" name="appointment_id" value="<?php echo $appointment['id']; ?>">
                            <div class="mb-3">
                                <label for="new_date" class="form-label">New Date</label>
                                <input type="date" class="form-control" id="new_date" name="new_date" required>
                            </div>
                            
                            <div class="mb-3">
                                <label for="new_time" class="form-label">New Time</label>
                                <input type="time" class="form-control" id="new_time" name="new_time" required>
                            </div>
                            
                            <div class="mb-3">
                                <label for="reason" class="form-label">Reason for Rescheduling</label>
                                <textarea class="form-control" id="reason" name="reason" rows="3" required></textarea>
                            </div>
                            
                            <div class="d-grid gap-2">
                                <button type="submit" class="btn btn-primary">Reschedule Appointment</button>
                                <a href="appointments.php" class="btn btn-secondary">Cancel</a>
                            </div>
                        </form>
                    </div>
                </div>
            </main>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/feather-icons/dist/feather.min.js"></script>
    <script>
        feather.replace()
        
        // Set minimum date to today
        const today = new Date().toISOString().split('T')[0];
        document.getElementById('new_date').min = today;
    </script>
</body>
</html>
