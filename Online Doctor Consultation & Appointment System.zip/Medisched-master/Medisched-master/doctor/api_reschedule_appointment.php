<?php
session_start();
header('Content-Type: application/json');

// Enable error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Database connection
$conn = new mysqli("localhost", "root", "", "Medisched_db");

if ($conn->connect_error) {
    echo json_encode(['success' => false, 'message' => 'Database connection failed']);
    exit();
}

// Check if user is logged in
if(!isset($_SESSION['user'])) {
    echo json_encode(['success' => false, 'message' => 'User not logged in']);
    exit();
}

// Get doctor details
$email = $_SESSION['user'];
$sql = "SELECT * FROM doctors WHERE email = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $email);
$stmt->execute();
$result = $stmt->get_result();
$doctor = $result->fetch_assoc();
$stmt->close();

if (!$doctor) {
    echo json_encode(['success' => false, 'message' => 'Doctor not found']);
    exit();
}

// Get JSON data
$json = file_get_contents('php://input');

// Log the raw input for debugging
file_put_contents('debug_reschedule.log', date('Y-m-d H:i:s') . " - Raw input: " . $json . PHP_EOL, FILE_APPEND);

$data = json_decode($json, true);

// Log the decoded data
file_put_contents('debug_reschedule.log', date('Y-m-d H:i:s') . " - Decoded data: " . print_r($data, true) . PHP_EOL, FILE_APPEND);

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $appointment_id = $data['appointment_id'] ?? '';
    $new_datetime = $data['new_datetime'] ?? '';
    
    if(empty($appointment_id) || empty($new_datetime)) {
        echo json_encode(['success' => false, 'message' => 'Appointment ID and new datetime are required']);
        exit();
    }

    // Check if appointment exists and belongs to the doctor
    $check_sql = "SELECT a.*, p.name as patient_name, p.phone as patient_phone 
                  FROM appointments a 
                  JOIN patients p ON a.patient_id = p.id 
                  WHERE a.id = ? AND a.doctor_id = ?";
    $check_stmt = $conn->prepare($check_sql);
    $check_stmt->bind_param("ii", $appointment_id, $doctor['id']);
    $check_stmt->execute();
    $appointment = $check_stmt->get_result()->fetch_assoc();
    $check_stmt->close();

    if (!$appointment) {
        echo json_encode(['success' => false, 'message' => 'Appointment not found or unauthorized']);
        exit();
    }

    // Update appointment date/time
    $sql = "UPDATE appointments 
            SET date_time = ?,
                status = 'Rescheduled',
                reschedule_reason = 'Rescheduled by doctor'
            WHERE id = ? 
            AND doctor_id = ?";
    
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sii", $new_datetime, $appointment_id, $doctor['id']);
    
    if($stmt->execute()) {
        echo json_encode([
            'success' => true, 
            'message' => 'Appointment rescheduled successfully',
            'new_datetime' => date('F j, Y h:i A', strtotime($new_datetime))
        ]);
    } else {
        echo json_encode(['success' => false, 'message' => 'Error rescheduling appointment: ' . $conn->error]);
    }
    $stmt->close();
} else {
    echo json_encode(['success' => false, 'message' => 'Invalid request method']);
}

$conn->close();
?>
