<?php
session_start();
include('../includes/refresh_session.php');

// Database connection
$conn = new mysqli("localhost", "root", "", "Medisched_db");

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if user is logged in
if(!isset($_SESSION['user'])) {
    header("Location: ../login.php");
    exit();
}

// Get doctor details
$email = $_SESSION['user'];
$sql = "SELECT * FROM doctors WHERE email = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $email);
$stmt->execute();
$result = $stmt->get_result();
$stmt->close();

if ($result->num_rows > 0) {
    $doctor = $result->fetch_assoc();
} else {
    header("Location: ../login.php");
    exit();
}

// Get appointment statistics
$stats_sql = "SELECT 
                (SELECT COUNT(*) FROM appointments WHERE doctor_id = ?) as total_appointments,
                (SELECT COUNT(*) FROM appointments WHERE doctor_id = ? AND status = 'Pending') as pending_appointments,
                (SELECT COUNT(*) FROM appointments WHERE doctor_id = ? AND status = 'Confirmed') as confirmed_appointments,
                (SELECT COUNT(*) FROM appointments WHERE doctor_id = ? AND status = 'Cancelled') as cancelled_appointments";

$stmt = $conn->prepare($stats_sql);
$stmt->bind_param("iiii", $doctor['id'], $doctor['id'], $doctor['id'], $doctor['id']);
$stmt->execute();
$stats_result = $stmt->get_result();
$stats = $stats_result->fetch_assoc();
$stmt->close();

// Get patient records
$patient_id = $_GET['patient_id'] ?? '';
$patients_result = null;
$records_result = null;

if($patient_id) {
    $records_sql = "SELECT DISTINCT
                   p.name as patient_name,
                   p.phone as patient_phone,
                   p.email as patient_email,
                   a.date_time as appointment_time,
                   a.created_at as booking_time,
                   a.reason as patient_problem,
                   a.status as appointment_status,
                   a.id as appointment_id
                   FROM appointments a 
                   JOIN patients p ON a.patient_id = p.id 
                   WHERE a.doctor_id = ? 
                   AND a.patient_id = ? 
                   ORDER BY a.date_time DESC";
    $stmt = $conn->prepare($records_sql);
    $stmt->bind_param("ii", $doctor['id'], $patient_id);
    $records_result = $stmt->execute() ? $stmt->get_result() : null;
    $stmt->close();
} else {
    $patients_sql = "SELECT DISTINCT 
                    p.id,
                    p.name as patient_name,
                    p.email as patient_email,
                    p.phone as patient_phone,
                    (SELECT COUNT(*) 
                     FROM appointments a 
                     WHERE a.patient_id = p.id 
                     AND a.doctor_id = ?) as total_appointments,
                    (SELECT COUNT(*) 
                     FROM appointments a 
                     WHERE a.patient_id = p.id 
                     AND a.doctor_id = ? 
                     AND a.status = 'confirmed') as confirmed_appointments
                    FROM patients p 
                    JOIN appointments a ON p.id = a.patient_id 
                    WHERE a.doctor_id = ?";
    $stmt = $conn->prepare($patients_sql);
    $doctor_id = $doctor['id'];
    $stmt->bind_param("iii", $doctor_id, $doctor_id, $doctor_id);
    $patients_result = $stmt->execute() ? $stmt->get_result() : null;
    $stmt->close();
}

// Check if we have results for either query
$has_results = $patient_id ? ($records_result && $records_result->num_rows > 0) : ($patients_result && $patients_result->num_rows > 0);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Patient Records - Medisched</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../assets/css/style.css">
    <style>
        .record-card {
            margin-bottom: 15px;
            border-left: 4px solid #007bff;
        }
        .status-badge {
            padding: 5px 10px;
            border-radius: 15px;
        }
        .stat-card {
            background: white;
            border-radius: 10px;
            padding: 1.5rem;
            margin-bottom: 1rem;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            transition: transform 0.3s ease;
        }
        .stat-card:hover {
            transform: translateY(-5px);
        }
        .stat-icon {
            font-size: 2rem;
            margin-bottom: 1rem;
        }
        .stat-number {
            font-size: 1.5rem;
            font-weight: bold;
            margin-bottom: 0.5rem;
        }
        .stat-label {
            color: #64748b;
            font-size: 0.9rem;
        }
        .bg-light-blue {
            background-color: #e3f2fd !important;
            color: #1976d2;
        }
        .bg-light-yellow {
            background-color: #fff3cd !important;
            color: #856404;
        }
        .bg-light-green {
            background-color: #d4edda !important;
            color: #28a745;
        }
        .bg-light-red {
            background-color: #f8d7da !important;
            color: #dc3545;
        }

    </style>
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <nav id="sidebar" class="col-md-3 col-lg-2 d-md-block bg-light sidebar">
                <div class="position-sticky pt-3">
                    <ul class="nav flex-column">
                        <li class="nav-item">
                            <a class="nav-link" href="index.php">
                                <span data-feather="home"></span>
                                Dashboard
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="appointments.php">
                                <span data-feather="calendar"></span>
                                Appointments
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link active" href="patient_records.php">
                                <span data-feather="user"></span>
                                Patient Records
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="profile.php">
                                <span data-feather="user"></span>
                                Profile
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="../logout.php">
                                <span data-feather="log-out"></span>
                                Logout
                            </a>
                        </li>
                    </ul>
                </div>
            </nav>

            <!-- Main content -->
            <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
                <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                    <h1 class="h2">Patient Records</h1>
                </div>

                <!-- Appointment Statistics -->
                <div class="row mb-4">
                    <div class="col-md-3">
                        <div class="stat-card bg-light-blue">
                            <div class="stat-icon">
                                <i class="bi bi-calendar4-week"></i>
                            </div>
                            <div class="stat-number"><?php echo $stats['total_appointments']; ?></div>
                            <div class="stat-label">Total Appointments</div>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="stat-card bg-light-yellow">
                            <div class="stat-icon">
                                <i class="bi bi-hourglass"></i>
                            </div>
                            <div class="stat-number"><?php echo $stats['pending_appointments']; ?></div>
                            <div class="stat-label">Pending Appointments</div>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="stat-card bg-light-green">
                            <div class="stat-icon">
                                <i class="bi bi-check-circle"></i>
                            </div>
                            <div class="stat-number"><?php echo $stats['confirmed_appointments']; ?></div>
                            <div class="stat-label">Confirmed Appointments</div>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="stat-card bg-light-red">
                            <div class="stat-icon">
                                <i class="bi bi-x-circle"></i>
                            </div>
                            <div class="stat-number"><?php echo $stats['cancelled_appointments']; ?></div>
                            <div class="stat-label">Cancelled Appointments</div>
                        </div>
                    </div>
                </div>

                <!-- Patient Selection -->
                <div class="card mb-4">
                    <div class="card-body">
                        <h5 class="card-title">Patient Details Show</h5>
                        <div class="table-responsive">
                            <table class="table table-striped">
                                <thead>
                                    
                                </thead>
                                <tbody>
                                    <?php if($patients_result && $patients_result->num_rows > 0): ?>
                                        <?php while($patient = $patients_result->fetch_assoc()): ?>
                                        <tr>
                                            <td><?php echo htmlspecialchars($patient['patient_name']); ?></td>
                                            <td><?php echo htmlspecialchars($patient['patient_phone']); ?></td>
                                            <td><?php echo htmlspecialchars($patient['patient_email']); ?></td>
                                            <td><?php echo $patient['total_appointments']; ?></td>
                                            <td><?php echo $patient['confirmed_appointments']; ?></td>
                                            <td>
                                                <a href="?patient_id=<?php echo $patient['id']; ?>" 
                                                    class="btn btn-sm btn-primary">
                                                    <i class="bi bi-file-medical"></i> View History
                                                </a>
                                            </td>
                                        </tr>
                                        <?php endwhile; ?>
                                    <?php else: ?>
                                        <tr>
                                            <td colspan="6" class="text-center"></td>
                                        </tr>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>

                <!-- Appointment History -->
                <?php if($patient_id): ?>
                <div class="card">
                    <div class="card-header bg-primary text-white d-flex justify-content-between align-items-center">
                        <h5 class="mb-0">Patient Details</h5>
                        <a href="patient_records.php" class="btn btn-light btn-sm">Back to List</a>
                    </div>
                    <div class="card-body">
                        <?php if($records_result && $records_result->num_rows > 0):
                            $first_record = $records_result->fetch_assoc(); ?>
                        <div class="row mb-4">
                            <div class="col-md-4">
                                <h6 class="text-muted">Patient Name</h6>
                                <p class="mb-0"><?php echo htmlspecialchars($first_record['patient_name'] ?? ''); ?></p>
                            </div>
                            <div class="col-md-4">
                                <h6 class="text-muted">Contact Number</h6>
                                <p class="mb-0"><?php echo htmlspecialchars($first_record['patient_phone'] ?? ''); ?></p>
                            </div>
                        
                        </div>

                        <h5 class="mb-3">Appointment History</h5>
                        <div class="table-responsive">
                            <table class="table table-striped">
                                <thead>
                                    <tr>
                                        <th>Appointment Time</th>
                                        <th>Booking Time</th>
                                        <th>Patient Problem</th>
                                        <th>Status</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php 
                                    // Reset pointer to beginning of result set
                                    $records_result->data_seek(0);
                                    while($record = $records_result->fetch_assoc()): 
                                        $status_class = '';
                                        $status_icon = '';
                                        $status_text = '';
                                        
                                        switch(strtolower($record['appointment_status'])) {
                                            case 'pending':
                                                $status_class = 'text-warning';
                                                $status_icon = 'bi-clock';
                                                $status_text = 'Pending';
                                                break;
                                            case 'confirmed':
                                                $status_class = 'text-success';
                                                $status_icon = 'bi-check-circle';
                                                $status_text = 'Confirmed';
                                                break;
                                            case 'cancelled':
                                                $status_class = 'text-danger';
                                                $status_icon = 'bi-x-circle';
                                                $status_text = 'Cancelled';
                                                break;
                                            case 'rescheduled':
                                                $status_class = 'text-info';
                                                $status_icon = 'bi-calendar-check';
                                                $status_text = 'Rescheduled';
                                                break;
                                        }
                                    ?>
                                    <tr>
                                        <td><?php echo date('M d, Y h:i A', strtotime($record['appointment_time'])); ?></td>
                                        <td><?php echo date('Y-m-d H:i:s', strtotime($record['booking_time'])); ?></td>
                                        <td><?php echo htmlspecialchars($record['patient_problem']); ?></td>
                                        <td class="<?php echo $status_class; ?>">
                                            <i class="bi <?php echo $status_icon; ?> me-1"></i>
                                            <?php echo $status_text; ?>
                                        </td>
                                        <td>
                                            <div class="btn-group">
                                                <button onclick="viewAppointmentDetails('<?php echo $record['appointment_id']; ?>')" 
                                                        class="btn btn-sm btn-outline-primary" 
                                                        title="View Details">
                                                    <i class="bi bi-eye"></i> View Details
                                                </button>
                                                <?php if($record['appointment_status'] == 'Pending'): ?>
                                                    <button type="button" class="btn btn-sm btn-outline-warning" 
                                                            data-bs-toggle="modal" 
                                                            data-bs-target="#rescheduleModal" 
                                                            onclick="document.getElementById('appointment_id_field').value='<?php echo $record['appointment_id']; ?>'">
                                                        <i class="bi bi-calendar2-plus"></i> Reschedule
                                                    </button>
                                                    <button type="button" class="btn btn-sm btn-outline-danger" 
                                                            data-bs-toggle="modal" 
                                                            data-bs-target="#cancelModal" 
                                                            onclick="setAppointmentId('<?php echo $record['appointment_id']; ?>')">
                                                        <i class="bi bi-x-circle"></i> Cancel
                                                    </button>
                                                <?php endif; ?>
                                            </div>
                                        </td>
                                    </tr>
                                    <?php endwhile; ?>
                                <?php else: ?>
                                    <tr>
                                        <td colspan="5" class="text-center">No appointment records found</td>
                                    </tr>
                                <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
                <?php else: ?>
                <div class="alert alert-info">No appointment records found for this patient.</div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <!-- Modals -->
    <!-- Reschedule Appointment Modal -->
    <div class="modal fade" id="rescheduleModal" tabindex="-1" aria-labelledby="rescheduleModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header bg-primary text-white">
                    <h5 class="modal-title" id="rescheduleModalLabel"><i class="bi bi-calendar-plus"></i> Reschedule Appointment</h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div class="alert alert-info" role="alert">
                        <i class="bi bi-info-circle"></i> You are about to reschedule an appointment. Please select a new date and time.
                    </div>
                    <div id="appointmentDetails" class="mb-4 p-3 border rounded bg-light">
                        <h6 class="border-bottom pb-2 mb-3">Current Appointment Details</h6>
                        <div id="currentAppointmentInfo">
                            <!-- This will be populated dynamically -->
                            <p><strong>Appointment ID:</strong> <span id="currentAppointmentId"></span></p>
                        </div>
                    </div>
                    <form id="rescheduleForm" action="direct_reschedule.php" method="get">
                        <input type="hidden" name="id" id="appointment_id_field">
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label for="new_date" class="form-label"><i class="bi bi-calendar-date"></i> New Date</label>
                                <input type="date" class="form-control" id="new_date" name="date" required>
                                <div class="form-text">Select a date from today onwards</div>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label for="new_time" class="form-label"><i class="bi bi-clock"></i> New Time</label>
                                <input type="time" class="form-control" id="new_time" name="time" required>
                                <div class="form-text">Select a suitable time slot</div>
                            </div>
                        </div>
                        <div class="mb-3">
                            <label for="reschedule_reason" class="form-label"><i class="bi bi-chat-left-text"></i> Reason for Rescheduling (Optional)</label>
                            <textarea class="form-control" id="reschedule_reason" name="reason" rows="2" placeholder="Enter reason for rescheduling"></textarea>
                        </div>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">
                        <i class="bi bi-x-circle"></i> Cancel
                    </button>
                    <button type="button" class="btn btn-primary" id="submitReschedule">
                        <i class="bi bi-calendar-check"></i> Confirm Reschedule
                    </button>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Cancel Appointment Modal -->
    <div class="modal fade" id="cancelModal" tabindex="-1" aria-labelledby="cancelModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="cancelModalLabel">Cancel Appointment</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <p>Are you sure you want to cancel this appointment?</p>
                    <p class="text-danger"><small>This action cannot be undone.</small></p>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">No, Keep Appointment</button>
                    <button type="button" class="btn btn-danger" onclick="cancelAppointment()">
                        <i class="bi bi-x-circle"></i> Yes, Cancel Appointment
                    </button>
                </div>
            </div>
        </div>
    </div>
    
    <!-- View Appointment Details Modal -->
    <div class="modal fade" id="viewDetailsModal" tabindex="-1" aria-labelledby="viewDetailsModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="viewDetailsModalLabel">Appointment Details</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div class="row">
                        <div class="col-md-6">
                            <h6 class="text-muted">Patient Information</h6>
                            <div class="mb-3">
                                <label class="form-label">Patient Name:</label>
                                <p id="patientName"></p>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Contact Number:</label>
                                <p id="patientPhone"></p>
                            </div>
                            <div class="mb-3">
                                <label class="form-label"></label>
                                <p id="patientEmail"></p>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <h6 class="text-muted">Appointment Information</h6>
                            <div class="mb-3">
                                <label class="form-label">Appointment Time:</label>
                                <p id="appointmentTime"></p>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Booking Time:</label>
                                <p id="bookingTime"></p>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Reason for Visit:</label>
                                <p id="reason"></p>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Status:</label>
                                <p id="status" class="status-text"></p>
                            </div>
                        </div>
                    </div>
                    

                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>

    <!-- Prescription Modal -->
    <div class="modal fade" id="prescriptionModal" tabindex="-1" aria-labelledby="prescriptionModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="prescriptionModalLabel">Add Prescription</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form id="prescriptionForm">
                        <input type="hidden" id="prescriptionAppointmentId" name="appointment_id">
                        <div class="mb-3">
                            <label for="prescriptionText" class="form-label">Prescription Details</label>
                            <textarea class="form-control" id="prescriptionText" name="prescription_text" rows="4" required></textarea>
                        </div>
                        <div class="mb-3">
                            <label for="nextVisit" class="form-label">Next Visit Date (Optional)</label>
                            <input type="date" class="form-control" id="nextVisit" name="next_visit_date">
                        </div>
                        <div class="mb-3">
                            <label for="followUp" class="form-label">Follow Up Instructions</label>
                            <textarea class="form-control" id="followUp" name="follow_up_instructions" rows="3"></textarea>
                        </div>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    <button type="button" class="btn btn-primary" onclick="submitPrescription()">
                        <i class="bi bi-check-lg"></i> Submit Prescription
                    </button>
                </div>
            </div>
        </div>
    </div>

    <script>
        let currentAppointmentId = null;
        
        function openRescheduleModal(appointmentId, patientName, appointmentDateTime) {
            currentAppointmentId = appointmentId;
            
            // Set the appointment details in the modal
            document.getElementById('currentAppointmentId').textContent = appointmentId;
            document.getElementById('appointment_id_field').value = appointmentId;
            
            // Add more details if needed
            const detailsDiv = document.getElementById('currentAppointmentInfo');
            detailsDiv.innerHTML = `
                <p><strong>Appointment ID:</strong> ${appointmentId}</p>
                <p><strong>Patient:</strong> ${patientName}</p>
                <p><strong>Current Date/Time:</strong> ${appointmentDateTime}</p>
            `;
            
            // Set default values for date and time
            const today = new Date();
            const formattedDate = today.toISOString().split('T')[0];
            document.getElementById('new_date').value = formattedDate;
            document.getElementById('new_time').value = '10:00';
        }
        
        // Add event listener for the submit button
        document.addEventListener('DOMContentLoaded', function() {
            document.getElementById('submitReschedule').addEventListener('click', function() {
                // Basic validation
                const appointmentId = document.getElementById('appointment_id_field').value;
                const newDate = document.getElementById('new_date').value;
                const newTime = document.getElementById('new_time').value;
                
                if (!appointmentId) {
                    alert('Please select an appointment first');
                    return;
                }
                
                if (!newDate || !newTime) {
                    alert('Please select both date and time');
                    return;
                }
                
                // Show loading state on the button
                const rescheduleBtn = document.getElementById('submitReschedule');
                rescheduleBtn.disabled = true;
                rescheduleBtn.innerHTML = '<span class="spinner-border spinner-border-sm" role="status"></span> Processing...';
                
                // Submit the form
                document.getElementById('rescheduleForm').submit();
            });
            
            // Check for status messages in URL parameters
            const urlParams = new URLSearchParams(window.location.search);
            const status = urlParams.get('status');
            const message = urlParams.get('message');
            
            if (status && message) {
                if (status === 'success') {
                    alert('Success: ' + message);
                } else if (status === 'error') {
                    alert('Error: ' + message);
                }
                
                // Clean up the URL to remove the status parameters
                const url = new URL(window.location.href);
                url.searchParams.delete('status');
                url.searchParams.delete('message');
                window.history.replaceState({}, document.title, url.toString());
            }
        });



        function viewAppointmentDetails(appointmentId) {
            if (!appointmentId) {
                alert('Please select an appointment first');
                return;
            }

            // Show loading indicator
            const modal = new bootstrap.Modal(document.getElementById('viewDetailsModal'));
            modal.show();
            document.getElementById('viewDetailsModalLabel').textContent = 'Loading...';
            
            // Clear previous content
            document.getElementById('patientName').textContent = '';
            document.getElementById('patientPhone').textContent = '';
            document.getElementById('patientEmail').textContent = '';
            document.getElementById('appointmentTime').textContent = '';
            document.getElementById('bookingTime').textContent = '';
            document.getElementById('reason').textContent = '';
            document.getElementById('status').textContent = '';
            document.getElementById('status').className = 'status-text';

            // Fetch appointment details
            fetch('get_appointment_details.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: 'appointment_id=' + encodeURIComponent(appointmentId)
            })
            .then(response => {
                if (!response.ok) {
                    throw new Error('Network response was not ok');
                }
                return response.json();
            })
            .then(data => {
                if (data && data.data) {
                    document.getElementById('patientName').textContent = data.data.patient_name || 'N/A';
                    document.getElementById('patientPhone').textContent = data.data.patient_phone || 'N/A';
                    document.getElementById('patientEmail').textContent = data.data.patient_email || 'N/A';
                    document.getElementById('appointmentTime').textContent = data.data.appointment_time || 'N/A';
                    document.getElementById('bookingTime').textContent = data.data.booking_time || 'N/A';
                    document.getElementById('reason').textContent = data.data.reason || 'N/A';
                    
                    const statusElement = document.getElementById('status');
                    statusElement.textContent = data.data.status || 'N/A';
                    statusElement.className = 'status-text ' + getStatusClass(data.data.status || 'pending');

                    // Update modal title
                    document.getElementById('viewDetailsModalLabel').textContent = 'Appointment Details';


                } else {
                    alert('Error: Invalid appointment data');
                    modal.hide();
                    return;
                }
            })
            .catch(error => {
                console.error('Error:', error);
                alert('Error fetching appointment details. Please try again.');
                modal.hide();
            });
        }



        function cancelAppointment() {
            if (!currentAppointmentId) {
                alert('Please select an appointment first');
                return;
            }

            // Show loading state on the button
            const cancelBtn = document.querySelector('#cancelModal .btn-danger');
            cancelBtn.disabled = true;
            cancelBtn.innerHTML = '<span class="spinner-border spinner-border-sm" role="status"></span> Processing...';

            // Send cancel request
            fetch('cancel_appointment.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    appointment_id: currentAppointmentId
                })
            })
            .then(response => response.json())
            .then(data => {
                // Hide the modal
                const modal = bootstrap.Modal.getInstance(document.getElementById('cancelModal'));
                modal.hide();
                
                if (data.success) {
                    alert('Appointment cancelled successfully');
                    // Reload the page to reflect changes
                    location.reload();
                } else {
                    alert('Error: ' + data.message);
                    // Reset button state
                    cancelBtn.disabled = false;
                    cancelBtn.innerHTML = '<i class="bi bi-x-circle"></i> Yes, Cancel Appointment';
                }
            })
            .catch(error => {
                console.error('Error:', error);
                alert('An error occurred. Please try again.');
                
                // Hide the modal
                const modal = bootstrap.Modal.getInstance(document.getElementById('cancelModal'));
                modal.hide();
                
                // Reset button state
                cancelBtn.disabled = false;
                cancelBtn.innerHTML = '<i class="bi bi-x-circle"></i> Yes, Cancel Appointment';
            });
        }

        function getStatusClass(status) {
            switch(status.toLowerCase()) {
                case 'pending':
                    return 'text-warning';
                case 'confirmed':
                    return 'text-success';
                case 'cancelled':
                    return 'text-danger';
                default:
                    return '';
            }
        }
    </script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/feather-icons/dist/feather.min.js"></script>
    <script>
        feather.replace()
    </script>
</body>
</html>
