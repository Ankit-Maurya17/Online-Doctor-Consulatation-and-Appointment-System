<?php
session_start();

// Enable error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Log function for debugging
function debug_log($message) {
    file_put_contents('reschedule_debug.log', date('Y-m-d H:i:s') . ' - ' . $message . "\n", FILE_APPEND);
}

debug_log('Direct reschedule request received');
debug_log('GET params: ' . print_r($_GET, true));

// Database connection
debug_log('Attempting database connection');
$conn = new mysqli("localhost", "root", "", "Medisched_db");

if ($conn->connect_error) {
    debug_log('Database connection failed: ' . $conn->connect_error);
    die("Connection failed: " . $conn->connect_error);
}
debug_log('Database connection successful');

// Check if user is logged in
debug_log('Checking if user is logged in');
if(!isset($_SESSION['user'])) {
    debug_log('User not logged in');
    die("User not logged in");
}
debug_log('User is logged in: ' . $_SESSION['user']);

// Get parameters
debug_log('Getting request parameters');
$appointment_id = isset($_GET['id']) ? intval($_GET['id']) : 0;
$new_date = isset($_GET['date']) ? $_GET['date'] : '';
$new_time = isset($_GET['time']) ? $_GET['time'] : '';
$reason = isset($_GET['reason']) ? $_GET['reason'] : 'Rescheduled by doctor';

debug_log('Parameters: ID=' . $appointment_id . ', Date=' . $new_date . ', Time=' . $new_time . ', Reason=' . $reason);

if(empty($appointment_id) || empty($new_date) || empty($new_time)) {
    debug_log('Missing required parameters');
    die("Missing required parameters");
}
debug_log('All required parameters present');

// Combine date and time
$new_datetime = $new_date . ' ' . $new_time . ':00';
debug_log('Combined datetime: ' . $new_datetime);

// Update appointment
debug_log('Preparing SQL statement');

// First, check if reschedule_reason column exists
debug_log('Checking if reschedule_reason column exists');
$check_column_sql = "SHOW COLUMNS FROM appointments LIKE 'reschedule_reason'";
$check_result = $conn->query($check_column_sql);

if ($check_result->num_rows == 0) {
    debug_log('reschedule_reason column does not exist, using simpler SQL');
    // If column doesn't exist, use a simpler SQL query without that column
    $sql = "UPDATE appointments SET 
            date_time = ?, 
            status = 'Rescheduled', 
            updated_at = NOW() 
        WHERE id = ?";
} else {
    debug_log('reschedule_reason column exists, using full SQL');
    // If column exists, use the full SQL query
    $sql = "UPDATE appointments SET 
            date_time = ?, 
            status = 'Rescheduled', 
            reschedule_reason = ?, 
            updated_at = NOW() 
        WHERE id = ?";
}

try {
    debug_log('Preparing statement');
    $stmt = $conn->prepare($sql);
    if (!$stmt) {
        debug_log('Prepare statement failed: ' . $conn->error);
        throw new Exception('Prepare statement failed: ' . $conn->error);
    }
    debug_log('SQL statement prepared successfully');
    
    debug_log('Binding parameters');
    if ($check_result->num_rows == 0) {
        // If column doesn't exist, only bind date_time and id
        debug_log('Binding only date_time and id parameters');
        $bind_result = $stmt->bind_param("si", $new_datetime, $appointment_id);
    } else {
        // If column exists, bind all parameters
        debug_log('Binding all parameters including reason');
        $bind_result = $stmt->bind_param("ssi", $new_datetime, $reason, $appointment_id);
    }
    
    if (!$bind_result) {
        debug_log('Parameter binding failed: ' . $stmt->error);
        throw new Exception('Parameter binding failed: ' . $stmt->error);
    }
    debug_log('Parameters bound successfully');
    
    debug_log('Executing statement');
    if($stmt->execute()) {
        debug_log('Appointment rescheduled successfully');
        $message = "Appointment rescheduled successfully";
        $success = true;
    } else {
        debug_log('Failed to execute statement: ' . $stmt->error);
        $message = "Failed to reschedule appointment: " . $stmt->error;
        $success = false;
    }
} catch (Exception $e) {
    debug_log('Exception caught: ' . $e->getMessage());
    $message = "Error: " . $e->getMessage();
    $success = false;
}

debug_log('Closing statement and connection');
if (isset($stmt)) {
    $stmt->close();
}
$conn->close();

// Redirect back to patient records with status message
debug_log('Redirecting with status: ' . ($success ? 'success' : 'error') . ' and message: ' . $message);
header("Location: patient_records.php?status=" . ($success ? 'success' : 'error') . "&message=" . urlencode($message));
debug_log('Process completed');
exit();
?>
