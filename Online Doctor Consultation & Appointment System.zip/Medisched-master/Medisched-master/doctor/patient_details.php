<?php
session_start();
include('../includes/refresh_session.php');

// Database connection
$conn = new mysqli("localhost", "root", "", "Medisched_db");

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if (!isset($_GET['patient_id'])) {
    echo "<div class='alert alert-danger'>Invalid patient ID</div>";
    exit;
}

$patient_id = $_GET['patient_id'];

// Get patient details
$sql = "SELECT * FROM patients WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $patient_id);
$stmt->execute();
$patient = $stmt->get_result()->fetch_assoc();
$stmt->close();

// Get appointment history
$sql = "SELECT 
            a.id,
            a.date_time,
            a.status,
            a.reason,
            a.payment_status,
            a.amount_due,
            d.name as doctor_name,
            d.speciality
        FROM appointments a 
        JOIN doctors d ON a.doctor_id = d.id 
        WHERE a.patient_id = ? 
        ORDER BY a.date_time DESC 
        LIMIT 5";

$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $patient_id);
$stmt->execute();
$appointments = $stmt->get_result();
$stmt->close();

// Get medical records
$sql = "SELECT * FROM medical_records WHERE patient_id = ? ORDER BY created_at DESC";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $patient_id);
$stmt->execute();
$records = $stmt->get_result();
$stmt->close();

$conn->close();
?>

<div class="row">
    <div class="col-md-6">
        <h5>Patient Information</h5>
        <div class="card">
            <div class="card-body">
                <p><strong>Name:</strong> <?php echo htmlspecialchars($patient['name']); ?></p>
                <p><strong>Email:</strong> <?php echo htmlspecialchars($patient['email']); ?></p>
                <p><strong>Phone:</strong> <?php echo htmlspecialchars($patient['phone']); ?></p>
                <p><strong>Age:</strong> <?php echo htmlspecialchars($patient['age']); ?></p>
                <p><strong>Gender:</strong> <?php echo htmlspecialchars($patient['gender']); ?></p>
                <p><strong>Blood Group:</strong> <?php echo htmlspecialchars($patient['blood_group']); ?></p>
            </div>
        </div>
    </div>

    <div class="col-md-6">
        <h5>Recent Appointments</h5>
        <div class="card">
            <div class="card-body">
                <table class="table">
                    <thead>
                        <tr>
                            <th>Date</th>
                            <th>Doctor</th>
                            <th>Specialization</th>
                            <th>Status</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while ($appointment = $appointments->fetch_assoc()) {
                            $appointment_date = date('d/m/Y h:i A', strtotime($appointment['date_time']));
                            $status_class = '';
                            $status_icon = '';

                            switch(strtolower($appointment['status'])) {
                                case 'pending':
                                    $status_class = 'text-warning';
                                    $status_icon = 'fa-clock';
                                    break;
                                case 'confirmed':
                                    $status_class = 'text-success';
                                    $status_icon = 'fa-check-circle';
                                    break;
                                case 'cancelled':
                                    $status_class = 'text-danger';
                                    $status_icon = 'fa-times-circle';
                                    break;
                            }
                        ?>
                        <tr>
                            <td><?php echo $appointment_date; ?></td>
                            <td><?php echo htmlspecialchars($appointment['doctor_name']); ?></td>
                            <td><?php echo htmlspecialchars($appointment['speciality']); ?></td>
                            <td class="<?php echo $status_class; ?>">
                                <i class="fas <?php echo $status_icon; ?>"></i>
                                <?php echo ucfirst($appointment['status']); ?>
                            </td>
                            <td>
                                <?php if(strtolower($appointment['status']) != 'cancelled') { ?>
                                    <button class="btn btn-sm btn-primary reschedule-appointment" 
                                            data-appointment-id="<?php echo $appointment['id']; ?>">
                                        <i class="fas fa-calendar-alt"></i> Reschedule
                                    </button>
                                    <button class="btn btn-sm btn-danger cancel-appointment" 
                                            data-appointment-id="<?php echo $appointment['id']; ?>">
                                        <i class="fas fa-times-circle"></i> Cancel
                                    </button>
                                <?php } ?>
                            </td>
                        </tr>
                        <?php } ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<div class="row mt-4">
    <div class="col-12">
        <h5>Medical Records</h5>
        <div class="card">
            <div class="card-body">
                <?php if ($records->num_rows > 0) { ?>
                    <table class="table">
                        <thead>
                            <tr>
                                <th>Date</th>
                                <th>File Name</th>
                                <th>Type</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php while ($record = $records->fetch_assoc()) {
                                $file_extension = pathinfo($record['file_path'], PATHINFO_EXTENSION);
                                $file_type = $file_extension === 'pdf' ? 'PDF' : 'Image';
                            ?>
                            <tr>
                                <td><?php echo date('d/m/Y', strtotime($record['created_at'])); ?></td>
                                <td><?php echo htmlspecialchars($record['file_name']); ?></td>
                                <td><?php echo $file_type; ?></td>
                                <td>
                                    <a href="<?php echo htmlspecialchars($record['file_path']); ?>" 
                                       target="_blank" 
                                       class="btn btn-sm btn-primary">
                                        <i class="fas fa-eye"></i> View
                                    </a>
                                </td>
                            </tr>
                            <?php } ?>
                        </tbody>
                    </table>
                <?php } else { ?>
                    <div class="text-center py-4">
                        <i class="fas fa-file-medical fa-3x text-muted"></i>
                        <p class="text-muted">No medical records found</p>
                    </div>
                <?php } ?>
            </div>
        </div>
    </div>
</div>
< ? p h p   i n c l u d e ( ' a p p o i n t m e n t _ m o d a l s . p h p ' ) ;   ? > 
 
 
