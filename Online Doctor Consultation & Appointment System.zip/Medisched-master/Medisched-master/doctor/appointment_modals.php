<!-- Modal for Reschedule Appointment -->
<div class="modal fade" id="rescheduleModal" tabindex="-1" aria-labelledby="rescheduleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="rescheduleModalLabel">Reschedule Appointment</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form id="rescheduleForm">
                    <input type="hidden" id="reschedule_appointment_id">
                    <div class="mb-3">
                        <label for="new_date" class="form-label">New Date</label>
                        <input type="date" class="form-control" id="new_date" required>
                    </div>
                    <div class="mb-3">
                        <label for="new_time" class="form-label">New Time</label>
                        <input type="time" class="form-control" id="new_time" required>
                    </div>
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                <button type="button" class="btn btn-primary" id="confirmReschedule">Reschedule</button>
            </div>
        </div>
    </div>
</div>

<!-- Modal for Cancel Appointment -->
<div class="modal fade" id="cancelModal" tabindex="-1" aria-labelledby="cancelModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="cancelModalLabel">Cancel Appointment</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <p>Are you sure you want to cancel this appointment?</p>
                <input type="hidden" id="cancel_appointment_id">
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                <button type="button" class="btn btn-danger" id="confirmCancel">Yes, Cancel Appointment</button>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
<script>
    // Set minimum date for reschedule to today
    document.addEventListener('DOMContentLoaded', function() {
        if(document.getElementById('new_date')) {
            const today = new Date().toISOString().split('T')[0];
            document.getElementById('new_date').min = today;
        }
        
        // Reschedule button functionality
        const rescheduleButtons = document.querySelectorAll('.reschedule-appointment');
        rescheduleButtons.forEach(button => {
            button.addEventListener('click', function() {
                const appointmentId = this.getAttribute('data-appointment-id');
                document.getElementById('reschedule_appointment_id').value = appointmentId;
                const modal = new bootstrap.Modal(document.getElementById('rescheduleModal'));
                modal.show();
            });
        });
        
        // Cancel button functionality
        const cancelButtons = document.querySelectorAll('.cancel-appointment');
        cancelButtons.forEach(button => {
            button.addEventListener('click', function() {
                const appointmentId = this.getAttribute('data-appointment-id');
                document.getElementById('cancel_appointment_id').value = appointmentId;
                const modal = new bootstrap.Modal(document.getElementById('cancelModal'));
                modal.show();
            });
        });
        
        // Confirm reschedule functionality
        document.getElementById('confirmReschedule').addEventListener('click', function() {
            const appointmentId = document.getElementById('reschedule_appointment_id').value;
            const newDate = document.getElementById('new_date').value;
            const newTime = document.getElementById('new_time').value;
            
            if (!newDate || !newTime) {
                alert('Please select both date and time');
                return;
            }
            
            const newDatetime = `${newDate} ${newTime}:00`;
            
            // Send reschedule request
            fetch('reschedule_appointment.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    appointment_id: appointmentId,
                    new_datetime: newDatetime
                })
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    alert('Appointment rescheduled successfully');
                    location.reload();
                } else {
                    alert('Error: ' + data.message);
                }
            })
            .catch(error => {
                console.error('Error:', error);
                alert('An error occurred. Please try again.');
            });
        });
        
        // Confirm cancel functionality
        document.getElementById('confirmCancel').addEventListener('click', function() {
            const appointmentId = document.getElementById('cancel_appointment_id').value;
            
            // Send cancel request
            fetch('cancel_appointment.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    appointment_id: appointmentId
                })
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    alert('Appointment cancelled successfully');
                    location.reload();
                } else {
                    alert('Error: ' + data.message);
                }
            })
            .catch(error => {
                console.error('Error:', error);
                alert('An error occurred. Please try again.');
            });
        });
    });
</script>
