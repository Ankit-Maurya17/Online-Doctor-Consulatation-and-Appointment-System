<?php
session_start();
include('../includes/refresh_session.php');

// Database connection
$conn = new mysqli("localhost", "root", "", "Medisched_db");

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if user is logged in
if(!isset($_SESSION['user'])) {
    header("Location: ../login.php");
    exit();
}

// Get doctor details
$email = $_SESSION['user'];
$sql = "SELECT * FROM doctors WHERE email = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $email);
$stmt->execute();
$result = $stmt->get_result();
$stmt->close();

if ($result->num_rows > 0) {
    $doctor = $result->fetch_assoc();
} else {
    header("Location: ../login.php");
    exit();
}

// Get appointment details
$appointment_id = $_GET['id'] ?? '';
if(empty($appointment_id)) {
    header("Location: appointments.php");
    exit();
}

// Function to get appointment statistics
function get_appointment_stats($conn, $doctor_id) {
    $stats_sql = "SELECT 
                    COUNT(*) as total,
                    SUM(CASE WHEN status = 'Pending' THEN 1 ELSE 0 END) as pending,
                    SUM(CASE WHEN status = 'Confirmed' THEN 1 ELSE 0 END) as confirmed,
                    SUM(CASE WHEN status = 'Completed' THEN 1 ELSE 0 END) as completed,
                    SUM(CASE WHEN status = 'Cancelled' THEN 1 ELSE 0 END) as cancelled
                  FROM appointments 
                  WHERE doctor_id = ?";
    
    $stmt = $conn->prepare($stats_sql);
    $stmt->bind_param("i", $doctor_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $stats = $result->fetch_assoc();
    $stmt->close();
    
    return $stats;
}

// Handle AJAX request for stats
if (isset($_GET['get_stats'])) {
    $stats = get_appointment_stats($conn, $doctor['id']);
    header('Content-Type: application/json');
    echo json_encode($stats);
    exit();
}

// Process status changes (confirm/cancel/complete)
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if(isset($_POST['confirm_appointment'])) {
        // Confirm appointment
        $sql = "UPDATE appointments 
                SET status = 'Confirmed'
                WHERE id = ? 
                AND doctor_id = ?
                AND status = 'Pending'";
        
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ii", $appointment_id, $doctor['id']);
        
        if($stmt->execute()) {
            // Get updated stats after change
            $stats = get_appointment_stats($conn, $doctor['id']);
            $_SESSION['appointment_stats'] = $stats;
            
            header("Location: appointment_details.php?id=$appointment_id&success=Appointment confirmed successfully");
            exit();
        } else {
            $error = "Error confirming appointment: " . $conn->error;
        }
        $stmt->close();
    }
    elseif(isset($_POST['cancel_appointment'])) {
        // Cancel appointment
        $sql = "UPDATE appointments 
                SET status = 'Cancelled'
                WHERE id = ? 
                AND doctor_id = ?
                AND status = 'Pending'";
        
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ii", $appointment_id, $doctor['id']);
        
        if($stmt->execute()) {
            // Get updated stats after change
            $stats = get_appointment_stats($conn, $doctor['id']);
            $_SESSION['appointment_stats'] = $stats;
            
            header("Location: appointment_details.php?id=$appointment_id&success=Appointment cancelled successfully");
            exit();
        } else {
            $error = "Error cancelling appointment: " . $conn->error;
        }
        $stmt->close();
    }
    elseif(isset($_POST['prescription'])) {
        $prescription = $_POST['prescription'] ?? '';
        
        if(!empty($prescription)) {
            // First check if prescription column exists
            $column_check = $conn->query("SHOW COLUMNS FROM appointments LIKE 'prescription'");
            $prescription_column_exists = ($column_check->num_rows > 0);
            
            if ($prescription_column_exists) {
                $sql = "UPDATE appointments 
                        SET status = 'Completed',
                            prescription = ?
                        WHERE id = ? 
                        AND doctor_id = ?
                        AND status = 'Pending'";
            } else {
                // Fallback to using reason column if prescription doesn't exist
                $sql = "UPDATE appointments 
                        SET status = 'Completed',
                            reason = ?
                        WHERE id = ? 
                        AND doctor_id = ?
                        AND status = 'Pending'";
            }
            
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("sii", $prescription, $appointment_id, $doctor['id']);
            
            if($stmt->execute()) {
                // Get updated stats after change
                $stats = get_appointment_stats($conn, $doctor['id']);
                $_SESSION['appointment_stats'] = $stats;
                
                header("Location: appointment_details.php?id=$appointment_id&success=Prescription submitted successfully");
                exit();
            } else {
                $error = "Error updating appointment: " . $conn->error;
            }
            $stmt->close();
        }
    }
}

// Get appointment details
$sql = "SELECT a.*, p.name as patient_name, p.phone as patient_phone 
        FROM appointments a 
        JOIN patients p ON a.patient_id = p.id 
        WHERE a.id = ? AND a.doctor_id = ?";

$stmt = $conn->prepare($sql);
$stmt->bind_param("ii", $appointment_id, $doctor['id']);
$stmt->execute();
$result = $stmt->get_result();
$stmt->close();

if ($result->num_rows > 0) {
    $appointment = $result->fetch_assoc();
    // Handle both prescription and reason fields for display
    $appointment['prescription_display'] = $appointment['prescription'] ?? $appointment['reason'] ?? '';
} else {
    header("Location: appointments.php?error=Appointment not found");
    exit();
}

// Get current statistics
$stats = get_appointment_stats($conn, $doctor['id']);
$_SESSION['appointment_stats'] = $stats;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Appointment Details</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.7.2/font/bootstrap-icons.css" rel="stylesheet">
    <style>
        .appointment-details {
            background: white;
            border-radius: 10px;
            padding: 2rem;
            margin-bottom: 2rem;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        .prescription-form {
            background: white;
            border-radius: 10px;
            padding: 2rem;
            margin-bottom: 2rem;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        .status-badge {
            padding: 5px 10px;
            border-radius: 15px;
            font-size: 0.9rem;
        }
        .btn-submit {
            background-color: #198754;
            border-color: #198754;
            padding: 0.5rem 2rem;
            font-weight: 600;
        }
        .btn-submit:hover {
            background-color: #157347;
            border-color: #157347;
        }
        .btn-confirm {
            background-color: #0d6efd;
            border-color: #0d6efd;
            padding: 0.5rem 2rem;
            font-weight: 600;
        }
        .btn-confirm:hover {
            background-color: #0b5ed7;
            border-color: #0b5ed7;
        }
        .stats-card {
            border-radius: 10px;
            padding: 1rem;
            margin-bottom: 1rem;
            text-align: center;
            color: white;
        }
        .total-appointments {
            background-color: #0d6efd;
        }
        .pending-appointments {
            background-color: #ffc107;
        }
        .confirmed-appointments {
            background-color: #198754;
        }
        .cancelled-appointments {
            background-color: #dc3545;
        }
    </style>
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <nav id="sidebar" class="col-md-3 col-lg-2 d-md-block bg-light sidebar">
                <div class="position-sticky pt-3">
                    <ul class="nav flex-column">
                        <li class="nav-item">
                            <a class="nav-link" href="index.php">
                                <i class="bi bi-house-door"></i>
                                Dashboard
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="appointments.php">
                                <i class="bi bi-calendar-check"></i>
                                Appointments
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="profile.php">
                                <i class="bi bi-person"></i>
                                Profile
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="../logout.php">
                                <i class="bi bi-box-arrow-right"></i>
                                Logout
                            </a>
                        </li>
                    </ul>
                </div>
            </nav>

            <!-- Main content -->
            <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
                <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                    <h1 class="h2">Appointment Details</h1>
                    <div class="btn-toolbar mb-2 mb-md-0">
                        <a href="appointments.php" class="btn btn-outline-secondary btn-sm">
                            <i class="bi bi-arrow-left"></i> Back to Appointments
                        </a>
                    </div>
                </div>

                <?php if(isset($_GET['success'])): ?>
                    <div class="alert alert-success"><?php echo htmlspecialchars($_GET['success']); ?></div>
                <?php endif; ?>

                <?php if(isset($error)): ?>
                    <div class="alert alert-danger"><?php echo htmlspecialchars($error); ?></div>
                <?php endif; ?>

                <!-- Real-time Statistics Cards -->
                <div class="row mb-4">
                    <div class="col-md-3">
                        <div class="stats-card total-appointments">
                            <h5>Total Appointments</h5>
                            <h3 id="total-appointments"><?php echo $stats['total'] ?? 0; ?></h3>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="stats-card pending-appointments">
                            <h5>Pending</h5>
                            <h3 id="pending-appointments"><?php echo $stats['pending'] ?? 0; ?></h3>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="stats-card confirmed-appointments">
                            <h5>Confirmed</h5>
                            <h3 id="confirmed-appointments"><?php echo $stats['confirmed'] ?? 0; ?></h3>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="stats-card cancelled-appointments">
                            <h5>Cancelled</h5>
                            <h3 id="cancelled-appointments"><?php echo $stats['cancelled'] ?? 0; ?></h3>
                        </div>
                    </div>
                </div>

                <!-- Appointment Details -->
                <div class="appointment-details">
                    <h5 class="mb-4">Appointment Information</h5>
                    <div class="row">
                        <div class="col-md-6">
                            <p><strong>Patient Name:</strong> <?php echo htmlspecialchars($appointment['patient_name']); ?></p>
                            <p><strong>Patient Phone:</strong> <?php echo htmlspecialchars($appointment['patient_phone']); ?></p>
                            <p><strong>Appointment Date:</strong> <?php echo date('F j, Y', strtotime($appointment['date_time'])); ?></p>
                            <p><strong>Appointment Time:</strong> <?php echo date('h:i A', strtotime($appointment['date_time'])); ?></p>
                            <p><strong>Status:</strong>
                                <?php
                                $status_class = 'warning'; // default
                                if ($appointment['status'] == 'Completed') {
                                    $status_class = 'success';
                                } elseif ($appointment['status'] == 'Cancelled') {
                                    $status_class = 'danger';
                                } elseif ($appointment['status'] == 'Confirmed') {
                                    $status_class = 'info';
                                }
                                ?>
                                <span class="status-badge badge bg-<?php echo $status_class; ?>">
                                    <?php echo htmlspecialchars($appointment['status']); ?>
                                </span>
                            </p>
                        </div>
                        <div class="col-md-6">
                            <p><strong>Doctor Name:</strong> <?php echo htmlspecialchars($doctor['name']); ?></p>
                            <p><strong>Specialization:</strong> <?php 
                                if(isset($doctor['specialization']) && !empty($doctor['specialization'])) {
                                    echo htmlspecialchars($doctor['specialization']);
                                } else {
                                    echo htmlspecialchars($doctor['speciality'] ?? 'General Medicine');
                                }
                            ?></p>
                            <p><strong>Appointment ID:</strong> <?php echo $appointment['id']; ?></p>
                        </div>
                    </div>
                </div>

                <!-- Action Buttons -->
                <?php if($appointment['status'] == 'Pending'): ?>
                <div class="row mb-4">
                    <div class="col-md-12">
                        <div class="card">
                            <div class="card-body">
                                <h5 class="card-title">Appointment Actions</h5>
                                <form method="POST" action="" class="d-inline">
                                    <button type="submit" name="confirm_appointment" class="btn btn-confirm me-2">
                                        <i class="bi bi-check-circle"></i> Confirm Appointment
                                    </button>
                                </form>
                                <form method="POST" action="" class="d-inline">
                                    <button type="submit" name="cancel_appointment" class="btn btn-danger me-2" onclick="return confirm('Are you sure you want to cancel this appointment?')">
                                        <i class="bi bi-x-circle"></i> Cancel Appointment
                                    </button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
                <?php endif; ?>

                <!-- Prescription Section -->
                <?php if($appointment['status'] == 'Pending'): ?>
                <div class="prescription-form">
                    <h5 class="mb-4">Write Prescription</h5>
                    <form action="" method="POST" id="prescription-form">
                        <div class="mb-3">
                            <label for="prescription" class="form-label">Prescription</label>
                            <textarea class="form-control" id="prescription" name="prescription" rows="6" required></textarea>
                        </div>
                        
                    </form>
                </div>
                <?php endif; ?>

                <!-- View Prescription -->
                <?php if($appointment['status'] == 'Completed' && !empty($appointment['prescription_display'])): ?>
                <div class="prescription-form">
                    <h5 class="mb-4">Prescription</h5>
                    <div class="card">
                        <div class="card-body">
                            <pre><?php echo htmlspecialchars($appointment['prescription_display']); ?></pre>
                        </div>
                    </div>
                </div>
                <?php endif; ?>

            </main>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script>
        // Function to update statistics in real-time
        function updateStats() {
            $.ajax({
                url: 'appointment_details.php?get_stats=1',
                type: 'GET',
                dataType: 'json',
                success: function(data) {
                    $('#total-appointments').text(data.total);
                    $('#pending-appointments').text(data.pending);
                    $('#confirmed-appointments').text(data.confirmed);
                    $('#cancelled-appointments').text(data.cancelled);
                },
                error: function(xhr, status, error) {
                    console.error("Error fetching stats:", error);
                }
            });
        }

        // Update stats when form is submitted
        $('#prescription-form, form[action=""]').on('submit', function() {
            setTimeout(updateStats, 1000); // Update stats after 1 second
        });

        // Optional: Auto-refresh stats every 30 seconds
        setInterval(updateStats, 30000);
    </script>
</body>
</html>
<?php $conn->close(); ?>