<!-- Modal for confirmation -->
<div class="modal fade" id="cancelConfirmModal" tabindex="-1" role="dialog" aria-labelledby="cancelConfirmModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="cancelConfirmModalLabel">Confirm Cancellation</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                Are you sure you want to cancel this appointment?
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                <button type="button" class="btn btn-danger" id="confirmCancel">Yes, Cancel Appointment</button>
            </div>
        </div>
    </div>
</div>

<script>
$(document).ready(function() {
    let appointmentId = null;
    
    // When cancel button is clicked
    $('.cancel-appointment').click(function() {
        appointmentId = $(this).data('appointment-id');
        $('#cancelConfirmModal').modal('show');
    });
    
    // When confirmation is clicked
    $('#confirmCancel').click(function() {
        if (!appointmentId) return;
        
        // Send AJAX request to cancel the appointment
        $.ajax({
            url: 'cancel_appointment.php',
            type: 'POST',
            contentType: 'application/json',
            data: JSON.stringify({
                appointment_id: appointmentId
            }),
            success: function(response) {
                if (response.success) {
                    // Show success message
                    alert(response.message);
                    // Reload the page to show updated status
                    location.reload();
                } else {
                    // Show error message
                    alert('Error: ' + response.message);
                }
            },
            error: function() {
                alert('An error occurred while cancelling the appointment.');
            },
            complete: function() {
                // Close the modal
                $('#cancelConfirmModal').modal('hide');
            }
        });
    });
});
</script>
