<?php
session_start();
include("header.php");

// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get form data
    $recipient = $_POST["recipient"];
    $subject = $_POST["subject"];
    $message = $_POST["message"];
    
    // Validate inputs
    if (empty($recipient) || empty($subject) || empty($message)) {
        echo "<div class='alert alert-danger'>Please fill in all fields.</div>";
        exit();
    }
    
    // Here you would typically save the message to the database
    // For now, we'll just show a success message
    
    echo "<div class='alert alert-success'>Message sent successfully!</div>";
    
    // Redirect back to messages page after 2 seconds
    echo "<script>
        setTimeout(function() {
            window.location.href = 'messages.php';
        }, 2000);
    </script>";
}

include("footer.php");
?>
