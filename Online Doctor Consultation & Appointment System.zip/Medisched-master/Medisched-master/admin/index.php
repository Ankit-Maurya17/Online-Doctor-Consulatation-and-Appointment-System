<?php
include("auth_check.php");
include("header.php");
?>
                <div class="row">
                    <div class="col-md-12">
                        <h2 style="color:black;">Admin Dashboard</h2>   
                        <h5>Welcome Dear Admin, Love to see you back.</h5>
                    </div>
                </div>              
                <hr>
                
                <!-- First Row - List Views -->
                <div class="row">
                    <div class="col-md-4 col-sm-6 col-xs-12">
                        <div class="panel panel-primary text-center no-boder" style="background-color:#a01f62;color:white">
                            <div class="panel-body">
                                <i class="fa fa-user-md fa-5x"></i>
                                <h4><a href="doctor_list.php">Doctors List</a></h4>
                            </div>
                        </div>
                    </div>
                    

                    <div class="col-md-4 col-sm-6 col-xs-12">
                        <div class="panel panel-primary text-center no-boder" style="background-color:#a01f62;color:white">
                            <div class="panel-body">
                                <i class="fa fa-calendar fa-5x"></i>
                                <h4><a href="appointment_list.php">Appointment Details</a></h4>
                            </div>
                        </div>
                    </div>
                </div>
                
                <hr>
                
                <!-- Second Row - Management -->
                <div class="row">
                    <div class="col-md-4 col-sm-6 col-xs-12">
                        <div class="panel panel-primary text-center no-boder" style="background-color:#a01f62;color:white">
                            <div class="panel-body">
                                <i class="fa fa-cog fa-5x"></i>
                                <h4><a href="manage_doctor.php">Manage Doctor</a></h4>
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-md-4 col-sm-6 col-xs-12">
                        <div class="panel panel-primary text-center no-boder" style="background-color:#a01f62;color:white">
                            <div class="panel-body">
                                <i class="fa fa-plus fa-5x"></i>
                                <h4><a href="add_doctor.php">Add Doctor</a></h4>
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-md-4 col-sm-6 col-xs-12">
                        <div class="panel panel-primary text-center no-boder" style="background-color:#a01f62;color:white">
                            <div class="panel-body">
                                <i class="fa fa-envelope fa-5x"></i>
                                <h4><a href="messages.php">Messages/Feedback</a></h4>
                            </div>
                        </div>
                    </div>
                </div>

<?php
include("footer.php");
?>