<?php
include("header.php");
include("../includes/refresh_session.php");

// Database connection
$conn = new mysqli("localhost", "root", "", "Medisched_db");

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Create doctors table if it doesn't exist
$sql = "CREATE TABLE IF NOT EXISTS doctors (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    speciality VARCHAR(255) NOT NULL,
    email VARCHAR(255) NOT NULL,
    phone VARCHAR(20) NOT NULL,
    schedule VARCHAR(50) NOT NULL,
    description TEXT NOT NULL,
    sex ENUM('male', 'female') NOT NULL,
    address TEXT,
    amount_due DECIMAL(10,2) NOT NULL,
    location VARCHAR(255) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
)";

if (!$conn->query($sql)) {
    die("Error creating table: " . $conn->error);
}

// Process form submission for editing doctor
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['edit_doctor'])) {
    $doctor_id = $_POST['doctor_id'] ?? '';
    $full_name = $_POST['full_name'] ?? '';
    $email = $_POST['email'] ?? '';
    $phone = $_POST['phone'] ?? '';
    $location = $_POST['location'] ?? '';
    $speciality = $_POST['speciality'] ?? '';
    $schedule = $_POST['schedule'] ?? '';
    $description = $_POST['description'] ?? '';
    $sex = $_POST['sex'] ?? '';
    $address = $_POST['address'] ?? '';
    $amount_due = $_POST['amount_due'] ?? '';

    // Update doctor data
    $sql = "UPDATE doctors SET 
        name = ?,
        email = ?,
        phone = ?,
        location = ?,
        speciality = ?,
        schedule = ?,
        description = ?,
        sex = ?,
        address = ?,
        amount_due = ?
        WHERE id = ?";
    
    $stmt = $conn->prepare($sql);
    if (!$stmt) {
        die("Error preparing statement: " . $conn->error);
    }

    $stmt->bind_param("ssssssssdsi", 
        $full_name, $email, $phone, $location,
        $speciality, $schedule, $description,
        $sex, $address, $amount_due, $doctor_id
    );
    
    if ($stmt->execute()) {
        // Refresh session data after update
        refresh_after_change('admin');
    } else {
        die("Error updating doctor: " . $stmt->error);
    }
    
    $stmt->close();
}

// Process delete doctor
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['delete_doctor'])) {
    $doctor_id = $_POST['doctor_id'] ?? '';
    
    if (!empty($doctor_id)) {
        $sql = "DELETE FROM doctors WHERE id = ?";
        $stmt = $conn->prepare($sql);
        if (!$stmt) {
            die("Error preparing statement: " . $conn->error);
        }
        
        $stmt->bind_param("i", $doctor_id);
        
        if ($stmt->execute()) {
            // Refresh session data after delete
            refresh_after_change('admin');
        } else {
            die("Error deleting doctor: " . $stmt->error);
        }
        
        $stmt->close();
    }
}

// Get all doctors from the database
$sql = "SELECT * FROM doctors ORDER BY speciality, name";
$result = $conn->query($sql);

$doctors = array();
if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $speciality = $row['speciality'];
        if (!isset($doctors[$speciality])) {
            $doctors[$speciality] = array();
        }
        $doctors[$speciality][] = array(
            'id' => $row['id'],
            'name' => $row['name'],
            'location' => $row['location'],
            'speciality' => $row['speciality'],
            'email' => $row['email'],
            'phone' => $row['phone'],
            'schedule' => $row['schedule'],
            'description' => $row['description'],
            'sex' => $row['sex'],
            'address' => $row['address'],
            'amount_due' => $row['amount_due']
        );
    }
}

$conn->close();
?>

<div class="row">
    <div class="col-md-12">
        <h2 style="color:black;">Manage Doctors</h2>
        <hr>
    </div>
</div>

<div class="row">
    <div class="col-md-12">
        <div class="panel panel-primary">
            <div class="panel-body">
                <?php if (empty($doctors)): ?>
                    <div class="alert alert-info">
                        No doctors found. <a href="add_doctor.php" class="alert-link">Add a new doctor</a>.
                    </div>
                <?php else: ?>
                    <?php foreach($doctors as $speciality => $doctor_list): ?>
                        <div class="panel panel-default">
                            <div class="panel-heading">
                                <h4 class="panel-title"><?php echo htmlspecialchars($speciality); ?></h4>
                            </div>
                            <div class="panel-body">
                                <div class="table-responsive">
                                    <table class="table table-striped">
                                        <thead>
                                            <tr>
                                                <th>Doctor Name</th>
                                                <th>Location</th>
                                                <th>Actions</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php foreach($doctor_list as $doctor): ?>
                                                <tr>
                                                    <td><?php echo htmlspecialchars($doctor['name']); ?></td>
                                                    <td><?php echo htmlspecialchars($doctor['location']); ?></td>
                                                    <td>
                                                        <button type="button" class="btn btn-warning btn-sm" 
                                                                data-toggle="modal" 
                                                                data-target="#editModal"
                                                                data-doctor-id="<?php echo $doctor['id']; ?>"
                                                                data-doctor-name="<?php echo htmlspecialchars($doctor['name']); ?>"
                                                                data-doctor-email="<?php echo htmlspecialchars($doctor['email']); ?>"
                                                                data-doctor-phone="<?php echo htmlspecialchars($doctor['phone']); ?>"
                                                                data-doctor-location="<?php echo htmlspecialchars($doctor['location']); ?>"
                                                                data-doctor-schedule="<?php echo htmlspecialchars($doctor['schedule']); ?>"
                                                                data-doctor-description="<?php echo htmlspecialchars($doctor['description']); ?>"
                                                                data-doctor-sex="<?php echo htmlspecialchars($doctor['sex']); ?>"
                                                                data-doctor-address="<?php echo htmlspecialchars($doctor['address']); ?>"
                                                                data-doctor-fee="<?php echo htmlspecialchars($doctor['amount_due']); ?>">
                                                            <i class="glyphicon glyphicon-edit"></i> Edit
                                                        </button>
                                                        <button type="button" class="btn btn-danger btn-sm" 
                                                                data-toggle="modal" 
                                                                data-target="#deleteModal"
                                                                data-doctor-id="<?php echo $doctor['id']; ?>"
                                                                data-doctor-name="<?php echo htmlspecialchars($doctor['name']); ?>">
                                                            <i class="glyphicon glyphicon-trash"></i> Delete
                                                        </button>
                                                    </td>
                                                </tr>
                                            <?php endforeach; ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<!-- Edit Details Modal -->
<div class="modal fade" id="editModal" role="dialog">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h4 class="modal-title">Edit Doctor Details</h4>
            </div>
            <div class="modal-body">
                <form action="process_edit_doctor.php" method="POST" class="form-horizontal">
                    <input type="hidden" name="doctor_id" id="editDoctorId">
                    
                    <!-- Full Name -->
                    <div class="form-group">
                        <label class="control-label col-sm-2">Full Name:</label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control" name="full_name" id="editName" required>
                        </div>
                    </div>

                    <!-- Email -->
                    <div class="form-group">
                        <label class="control-label col-sm-2">Email:</label>
                        <div class="col-sm-10">
                            <input type="email" class="form-control" name="email" id="editEmail" required>
                        </div>
                    </div>

                    <!-- Phone -->
                    <div class="form-group">
                        <label class="control-label col-sm-2">Phone:</label>
                        <div class="col-sm-10">
                            <input type="tel" class="form-control" name="phone" id="editPhone" required>
                        </div>
                    </div>

                    <!-- Location -->
                    <div class="form-group">
                        <label class="control-label col-sm-2">Location:</label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control" name="location" id="editLocation" required>
                        </div>
                    </div>

                    <!-- Schedule -->
                    <div class="form-group">
                        <label class="control-label col-sm-2">Schedule:</label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control" name="schedule" id="editSchedule" required>
                        </div>
                    </div>

                    <!-- Description -->
                    <div class="form-group">
                        <label class="control-label col-sm-2">Description:</label>
                        <div class="col-sm-10">
                            <textarea class="form-control" name="description" id="editDescription" rows="3" required></textarea>
                        </div>
                    </div>

                    <!-- Sex -->
                    <div class="form-group">
                        <label class="control-label col-sm-2">Sex:</label>
                        <div class="col-sm-10">
                            <select class="form-control" name="sex" id="editSex" required>
                                <option value="male">Male</option>
                                <option value="female">Female</option>
                            </select>
                        </div>
                    </div>

                    <!-- Address -->
                    <div class="form-group">
                        <label class="control-label col-sm-2">Address:</label>
                        <div class="col-sm-10">
                            <textarea class="form-control" name="address" id="editAddress" rows="3" required></textarea>
                        </div>
                    </div>

                    <!-- Fee -->
                    <div class="form-group">
                        <label class="control-label col-sm-2">Fee:</label>
                        <div class="col-sm-10">
                            <input type="number" class="form-control" name="amount_due" id="editFee" step="0.01" required>
                        </div>
                    </div>

                    <div class="form-group">
                        <div class="col-sm-offset-2 col-sm-10">
                            <button type="submit" class="btn btn-primary">Update</button>
                            <button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<script>
// Edit Modal
$('#editModal').on('show.bs.modal', function (event) {
    var button = $(event.relatedTarget);
    var id = button.data('doctor-id');
    var name = button.data('doctor-name');
    var email = button.data('doctor-email');
    var phone = button.data('doctor-phone');
    var location = button.data('doctor-location');
    var schedule = button.data('doctor-schedule');
    var description = button.data('doctor-description');
    var sex = button.data('doctor-sex');
    var address = button.data('doctor-address');
    var fee = button.data('doctor-fee');

    // Update form fields
    $(this).find('#editDoctorId').val(id);
    $(this).find('#editName').val(name);
    $(this).find('#editEmail').val(email);
    $(this).find('#editPhone').val(phone);
    $(this).find('#editLocation').val(location);
    $(this).find('#editSchedule').val(schedule);
    $(this).find('#editDescription').val(description);
    $(this).find('#editSex').val(sex);
    $(this).find('#editAddress').val(address);
    $(this).find('#editFee').val(fee);
});
</script>

<?php
include("footer.php");
?>