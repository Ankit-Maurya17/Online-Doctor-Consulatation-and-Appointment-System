<?php
// Database connection
$conn = new mysqli("localhost", "root", "", "Medisched_db");

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Create admin_users table
$sql = "CREATE TABLE IF NOT EXISTS admin_users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
)";

if ($conn->query($sql) === TRUE) {
    echo "Admin users table created successfully\n";
    
    // Check if default admin user exists
    $check_admin = "SELECT * FROM admin_users WHERE username = 'admin'";
    $result = $conn->query($check_admin);
    
    if ($result === FALSE) {
        echo "Error checking for default admin user: " . $conn->error . "\n";
    } elseif ($result->num_rows == 0) {
        // Insert default admin user
        $default_username = 'admin';
        $default_password = 'admin123'; // You should change this in production
        
        $insert_sql = "INSERT INTO admin_users (username, password) VALUES (?, ?)";
        $stmt = $conn->prepare($insert_sql);
        
        if ($stmt === FALSE) {
            echo "Error preparing insert statement: " . $conn->error . "\n";
        } else {
            $stmt->bind_param("ss", $default_username, $default_password);
            
            if ($stmt->execute()) {
                echo "Default admin user created successfully\n";
                echo "Username: admin\n";
                echo "Password: admin123\n";
            } else {
                echo "Error creating default admin user: " . $conn->error . "\n";
            }
        }
    } else {
        echo "Default admin user already exists\n";
    }
} else {
    echo "Error creating table: " . $conn->error . "\n";
}

$conn->close();
?>
