<?php
session_start();
include("header.php");

// Check if required parameters are provided
if(!isset($_POST['doctor_name']) || !isset($_POST['speciality'])) {
    echo json_encode(array('success' => false, 'message' => 'Doctor name and specialty are required'));
    exit();
}

$doctor_name = $_POST['doctor_name'];
$speciality = $_POST['speciality'];

// Get current status
$current_status = "active"; // This should be fetched from database

// Toggle status
$new_status = ($current_status == "active") ? "inactive" : "active";

// Here you would typically update the database
// For now, we'll just show a success message

// Return success response
echo json_encode(array(
    'success' => true,
    'message' => 'Doctor status updated successfully',
    'new_status' => $new_status,
    'doctor_name' => $doctor_name,
    'speciality' => $speciality
));

include("footer.php");
?>
