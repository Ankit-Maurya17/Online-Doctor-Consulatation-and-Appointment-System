<?php
include("header.php");
?>
<div class="row">
    <div class="col-md-12">
        <h2 style="color:black;">Messages/Feedback</h2>
        <hr>
    </div>
</div>

<div class="row">
    <div class="col-md-12">
        <div class="panel panel-primary">
            <div class="panel-heading">
                <h3 class="panel-title">Write a New Message</h3>
            </div>
            <div class="panel-body">
                <div class="row">
                    <div class="col-md-12">
                        <form action="process_message.php" method="POST" class="form-horizontal">
                            <div class="form-group">
                                <label class="control-label col-sm-2">To:</label>
                                <div class="col-sm-10">
                                    <select class="form-control" name="recipient" required>
                                        <option value="all">All Users</option>
                                        <option value="doctors">Doctors Only</option>
                                        <option value="patients">Patients Only</option>
                                    </select>
                                </div>
                            </div>

                            <div class="form-group">
                                <label class="control-label col-sm-2">Subject:</label>
                                <div class="col-sm-10">
                                    <input type="text" class="form-control" name="subject" required>
                                </div>
                            </div>

                            <div class="form-group">
                                <label class="control-label col-sm-2">Message:</label>
                                <div class="col-sm-10">
                                    <textarea class="form-control" name="message" rows="10" required></textarea>
                                </div>
                            </div>

                            <div class="form-group">
                                <div class="col-sm-offset-2 col-sm-10">
                                    <button type="submit" class="btn btn-primary">Send Message</button>
                                    <button type="reset" class="btn btn-default">Clear</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="row">
    <div class="col-md-12">
        <div class="panel panel-primary">
            <div class="panel-heading">
                <h3 class="panel-title">Recent Messages</h3>
            </div>
            <div class="panel-body">
                <div class="table-responsive">
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th>From</th>
                                <th>Subject</th>
                                <th>Date</th>
                                <th>Message</th>
                                <th>Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            <!-- Messages will be populated here -->
                            <tr>
                                <td>No messages yet</td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<?php
include("footer.php");
?>
