<?php
include("header.php");
?>
<div class="row">
    <div class="col-md-12">
        <h2 style="color:black;">Doctors List</h2>
        <hr>
    </div>
</div>

<div class="row">
    <div class="col-md-12">
        <div class="panel panel-primary">
            <div class="panel-heading">
                <h3 class="panel-title">Doctors by Specialty</h3>
            </div>
            <div class="panel-body">
                <!-- Audiology -->
                <div class="panel panel-default">
                    <div class="panel-heading">
                        <h4 class="panel-title">Audiology</h4>
                    </div>
                    <div class="panel-body">
                        <ul class="list-unstyled">
                            <li>Dr. Ravi Sharma (Swaroop Rani Narsing Home, Prayagraj)</li>
                            <li>Dr. Pooja Verma (Tej Bahadur Sapru Hospital Beli, Prayagraj)</li>
                            <li>Dr. Anil Kumar (BHU, Varanasi)</li>
                            <li>Dr. Neha Singh (Appex, Varanasi)</li>
                            <li>Dr. Amit Yadav (KGMU, Lucknow)</li>
                        </ul>
                    </div>
                </div>

                <!-- Cardiology -->
                <div class="panel panel-default">
                    <div class="panel-heading">
                        <h4 class="panel-title">Cardiology</h4>
                    </div>
                    <div class="panel-body">
                        <ul class="list-unstyled">
                            <li>Dr. Amit Gupta (KGMU, Lucknow)</li>
                            <li>Dr. Priya Mehra (PGI, Lucknow)</li>
                            <li>Dr. Rakesh Patel (AIMS, Delhi)</li>
                            <li>Dr. Arvind Saxena (Sadar Hospital, Jaunpur)</li>
                            <li>Dr. Sunita Chauhan (Yash Hospital, Pratika Chauraha, Prayagraj)</li>
                        </ul>
                    </div>
                </div>

                <!-- Dentistry -->
                <div class="panel panel-default">
                    <div class="panel-heading">
                        <h4 class="panel-title">Dentistry</h4>
                    </div>
                    <div class="panel-body">
                        <ul class="list-unstyled">
                            <li>Dr. Neha Kapoor (BHU, Varanasi)</li>
                            <li>Dr. Sandeep Jain (Appex, Varanasi)</li>
                            <li>Dr. Sonali Gupta (Tej Bahadur Sapru Hospital Beli, Prayagraj)</li>
                            <li>Dr. Ritu Sharma (Swaroop Rani Narsing Home, Prayagraj)</li>
                            <li>Dr. Tarun Aggarwal (KGMU, Lucknow)</li>
                        </ul>
                    </div>
                </div>

                <!-- Diabetology -->
                <div class="panel panel-default">
                    <div class="panel-heading">
                        <h4 class="panel-title">Diabetology</h4>
                    </div>
                    <div class="panel-body">
                        <ul class="list-unstyled">
                            <li>Dr. Shubham Jain (PGI, Lucknow)</li>
                            <li>Dr. Smita Kapoor (AIMS, Delhi)</li>
                            <li>Dr. Rajesh Kumar (Sadar Hospital, Jaunpur)</li>
                            <li>Dr. Neelam Yadav (Swaroop Rani Narsing Home, Prayagraj)</li>
                            <li>Dr. Vikram Mishra (Yash Hospital, Pratika Chauraha, Prayagraj)</li>
                        </ul>
                    </div>
                </div>

                <!-- Radiology -->
                <div class="panel panel-default">
                    <div class="panel-heading">
                        <h4 class="panel-title">Radiology</h4>
                    </div>
                    <div class="panel-body">
                        <ul class="list-unstyled">
                            <li>Dr. Priya Sharma (KGMU, Lucknow)</li>
                            <li>Dr. Rakesh Yadav (PGI, Lucknow)</li>
                            <li>Dr. Alok Soni (AIMS, Delhi)</li>
                            <li>Dr. Ashish Gupta (BHU, Varanasi)</li>
                            <li>Dr. Manish Verma (Tej Bahadur Sapru Hospital Beli, Prayagraj)</li>
                        </ul>
                    </div>
                </div>

                <!-- Hepatology -->
                <div class="panel panel-default">
                    <div class="panel-heading">
                        <h4 class="panel-title">Hepatology</h4>
                    </div>
                    <div class="panel-body">
                        <ul class="list-unstyled">
                            <li>Dr. Suraj Bhattacharya (Sadar Hospital, Jaunpur)</li>
                            <li>Dr. Kunal Roy (AIMS, Delhi)</li>
                            <li>Dr. Ruchi Verma (KGMU, Lucknow)</li>
                            <li>Dr. Arvind Pandey (Yash Hospital, Pratika Chauraha, Prayagraj)</li>
                            <li>Dr. Nidhi Gupta (BHU, Varanasi)</li>
                        </ul>
                    </div>
                </div>

                <!-- Optician -->
                <div class="panel panel-default">
                    <div class="panel-heading">
                        <h4 class="panel-title">Optician</h4>
                    </div>
                    <div class="panel-body">
                        <ul class="list-unstyled">
                            <li>Dr. Sameer Jain (Swaroop Rani Narsing Home, Prayagraj)</li>
                            <li>Dr. Meera Verma (Tej Bahadur Sapru Hospital Beli, Prayagraj)</li>
                            <li>Dr. Anjali Tiwari (Appex, Varanasi)</li>
                            <li>Dr. Anshika Patel (PGI, Lucknow)</li>
                            <li>Dr. Varun Yadav (AIMS, Delhi)</li>
                        </ul>
                    </div>
                </div>

                <!-- Nephrology -->
                <div class="panel panel-default">
                    <div class="panel-heading">
                        <h4 class="panel-title">Nephrology</h4>
                    </div>
                    <div class="panel-body">
                        <ul class="list-unstyled">
                            <li>Dr. Rahul Yadav (KGMU, Lucknow)</li>
                            <li>Dr. Ramesh Chandra (BHU, Varanasi)</li>
                            <li>Dr. Sanjeev Kumar (Tej Bahadur Sapru Hospital Beli, Prayagraj)</li>
                            <li>Dr. Aditi Soni (Swaroop Rani Narsing Home, Prayagraj)</li>
                            <li>Dr. Kamal Mehta (PGI, Lucknow)</li>
                        </ul>
                    </div>
                </div>

                <!-- Neurology -->
                <div class="panel panel-default">
                    <div class="panel-heading">
                        <h4 class="panel-title">Neurology</h4>
                    </div>
                    <div class="panel-body">
                        <ul class="list-unstyled">
                            <li>Dr. Sanjay Soni (AIMS, Delhi)</li>
                            <li>Dr. Vikram Singh (Sadar Hospital, Jaunpur)</li>
                            <li>Dr. Shalini Rani (Tej Bahadur Sapru Hospital Beli, Prayagraj)</li>
                            <li>Dr. Ajay Kumar (KGMU, Lucknow)</li>
                            <li>Dr. Priya Bhardwaj (Yash Hospital, Pratika Chauraha, Prayagraj)</li>
                        </ul>
                    </div>
                </div>

                <!-- Children Medicine -->
                <div class="panel panel-default">
                    <div class="panel-heading">
                        <h4 class="panel-title">Children Medicine</h4>
                    </div>
                    <div class="panel-body">
                        <ul class="list-unstyled">
                            <li>Dr. Nisha Mehta (Swaroop Rani Narsing Home, Prayagraj)</li>
                            <li>Dr. Ruchika Singh (Tej Bahadur Sapru Hospital Beli, Prayagraj)</li>
                            <li>Dr. Gaurav Yadav (BHU, Varanasi)</li>
                            <li>Dr. Anjali Saini (Appex, Varanasi)</li>
                            <li>Dr. Sudhir Mishra (PGI, Lucknow)</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php
include("footer.php");
?>
