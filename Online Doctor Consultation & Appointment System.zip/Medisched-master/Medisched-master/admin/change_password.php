<?php
session_start();
include("header.php");

// Process password change
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $current_password = $_POST["current_password"] ?? "";
    $new_password = $_POST["new_password"] ?? "";
    $confirm_password = $_POST["confirm_password"] ?? "";
    
    // Validate input
    if (empty($current_password) || empty($new_password) || empty($confirm_password)) {
        $error = "All fields are required";
    } elseif ($new_password !== $confirm_password) {
        $error = "New passwords do not match";
    } elseif (strlen($new_password) < 8) {
        $error = "New password must be at least 8 characters long";
    } else {
        try {
            $conn = new mysqli("localhost", "root", "", "Medisched_db");
            
            if ($conn->connect_error) {
                throw new Exception("Connection failed: " . $conn->connect_error);
            }

            // Get current password
            $stmt = $conn->prepare("SELECT password FROM admin_users WHERE username = ?");
            $stmt->bind_param("s", $_SESSION["admin_user"]);
            $stmt->execute();
            $result = $stmt->get_result();
            $user = $result->fetch_assoc();

            if ($user && $user["password"] === $current_password) {
                // Update password
                $stmt = $conn->prepare("UPDATE admin_users SET password = ? WHERE username = ?");
                $stmt->bind_param("ss", $new_password, $_SESSION["admin_user"]);
                
                if ($stmt->execute()) {
                    $success = "Password changed successfully!";
                } else {
                    $error = "Error updating password";
                }
            } else {
                $error = "Current password is incorrect";
            }

            $stmt->close();
            $conn->close();
        } catch (Exception $e) {
            $error = "Error: " . $e->getMessage();
        }
    }
}
?>

<div class="container-fluid">
    <div class="row">
        <div class="col-md-12">
            <h2 style="color:black;">Change Password</h2>
            <hr>
        </div>
    </div>

    <div class="row">
        <div class="col-md-6 col-md-offset-3">
            <?php if (isset($success)): ?>
                <div class="alert alert-success"><?php echo $success; ?></div>
            <?php endif; ?>

            <?php if (isset($error)): ?>
                <div class="alert alert-danger"><?php echo $error; ?></div>
            <?php endif; ?>

            <form method="POST" action="" class="form-horizontal">
                <div class="form-group">
                    <label for="current_password" class="col-sm-4 control-label">Current Password</label>
                    <div class="col-sm-8">
                        <input type="password" class="form-control" id="current_password" name="current_password" required>
                    </div>
                </div>

                <div class="form-group">
                    <label for="new_password" class="col-sm-4 control-label">New Password</label>
                    <div class="col-sm-8">
                        <input type="password" class="form-control" id="new_password" name="new_password" required>
                    </div>
                </div>

                <div class="form-group">
                    <label for="confirm_password" class="col-sm-4 control-label">Confirm New Password</label>
                    <div class="col-sm-8">
                        <input type="password" class="form-control" id="confirm_password" name="confirm_password" required>
                    </div>
                </div>

                <div class="form-group">
                    <div class="col-sm-offset-4 col-sm-8">
                        <button type="submit" class="btn btn-primary">Change Password</button>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>

<?php include("footer.php"); ?>
