<?php
session_start();
include("header.php");

// Database configuration
$host = "localhost";
$username = "root";
$password = "";
$database = "medisched_db";

// Create connection
$conn = new mysqli($host, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if(isset($_POST['id'])) {
    $appointment_id = $_POST['id'];
    
    $sql = "SELECT a.*, p.name as patient_name, p.email as patient_email, p.phone as patient_phone,
                   d.name as doctor_name, d.email as doctor_email, d.speciality, d.phone as doctor_phone 
            FROM appointments a
            JOIN patients p ON a.patient_id = p.id
            JOIN doctors d ON a.doctor_id = d.id
            WHERE a.id = ?";

    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $appointment_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if($result->num_rows > 0) {
        $appointment = $result->fetch_assoc();
        ?>
        <div class="row">
            <div class="col-md-6">
                <h4>Patient Information</h4>
                <div class="form-group">
                    <label>Name:</label>
                    <p><?php echo htmlspecialchars($appointment['patient_name']); ?></p>
                </div>
                <div class="form-group">
                    <label>Email:</label>
                    <p><?php echo htmlspecialchars($appointment['patient_email']); ?></p>
                </div>
                <div class="form-group">
                    <label>Phone:</label>
                    <p><?php echo htmlspecialchars($appointment['patient_phone']); ?></p>
                </div>
            </div>
            <div class="col-md-6">
                <h4>Doctor Information</h4>
                <div class="form-group">
                    <label>Name:</label>
                    <p><?php echo htmlspecialchars($appointment['doctor_name']); ?></p>
                </div>
                <div class="form-group">
                    <label>Speciality:</label>
                    <p><?php echo htmlspecialchars($appointment['speciality']); ?></p>
                </div>
                <div class="form-group">
                    <label>Email:</label>
                    <p><?php echo htmlspecialchars($appointment['doctor_email']); ?></p>
                </div>
                <div class="form-group">
                    <label>Phone:</label>
                    <p><?php echo htmlspecialchars($appointment['doctor_phone']); ?></p>
                </div>
            </div>
        </div>
        <hr>
        <div class="row">
            <div class="col-md-6">
                <h4>Appointment Details</h4>
                <div class="form-group">
                    <label>Date & Time:</label>
                    <p><?php echo date('Y-m-d h:i A', strtotime($appointment['date_time'])); ?></p>
                </div>
                <div class="form-group">
                    <label>Amount Due:</label>
                    <p><?php echo "₹" . number_format($appointment['amount_due'], 2); ?></p>
                </div>
                <div class="form-group">
                    <label>Payment Status:</label>
                    <p><span class="label label-<?php echo $appointment['payment_status'] == 'Paid' ? 'success' : 'warning'; ?>">
                        <?php echo htmlspecialchars($appointment['payment_status']); ?>
                    </span></p>
                </div>
            </div>
        </div>
        <?php
    } else {
        echo "<p class='text-danger'>Appointment not found!</p>";
    }
    
    $stmt->close();
    $conn->close();
} else {
    echo "<p class='text-danger'>Invalid request!</p>";
}
?>
