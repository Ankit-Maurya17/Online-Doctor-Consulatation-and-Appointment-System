<?php
include("header.php");
include("../includes/refresh_session.php");

// Database connection
$conn = new mysqli("localhost", "root", "", "Medisched_db");

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Create doctors table if it doesn't exist
$sql = "CREATE TABLE IF NOT EXISTS doctors (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    speciality VARCHAR(255) NOT NULL,
    email VARCHAR(255) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    phone VARCHAR(20) NOT NULL,
    schedule VARCHAR(50) NOT NULL,
    description TEXT NOT NULL,
    sex ENUM('male', 'female') NOT NULL,
    address TEXT,
    amount_due DECIMAL(10,2) NOT NULL,
    location VARCHAR(255) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
)";

if (!$conn->query($sql)) {
    die("Error creating table: " . $conn->error);
}

// Process form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $full_name = $_POST['full_name'] ?? '';
    $email = $_POST['email'] ?? '';
    $password = $_POST['password'] ?? '';
    $phone = $_POST['phone'] ?? '';
    $location = $_POST['location'] ?? '';
    $speciality = $_POST['speciality'] ?? '';
    $schedule = $_POST['schedule'] ?? '';
    $description = $_POST['description'] ?? '';
    $sex = $_POST['sex'] ?? '';
    $address = $_POST['address'] ?? '';
    $amount_due = $_POST['amount_due'] ?? '';

    // Validate inputs
    $errors = array();
    
    if(empty($full_name)) {
        $errors[] = "Full name is required";
    }
    
    if(empty($email)) {
        $errors[] = "Email is required";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = "Invalid email format";
    }

    if(empty($password)) {
        $errors[] = "Password is required";
    } elseif (strlen($password) < 6) {
        $errors[] = "Password must be at least 6 characters long";
    }

    if(empty($phone)) {
        $errors[] = "Phone number is required";
    }

    if(empty($location)) {
        $errors[] = "Location is required";
    }

    if(empty($speciality)) {
        $errors[] = "Speciality is required";
    }

    if(empty($schedule)) {
        $errors[] = "Schedule is required";
    }

    if(empty($description)) {
        $errors[] = "Description is required";
    }

    if(empty($sex)) {
        $errors[] = "Sex is required";
    }

    if(empty($amount_due)) {
        $errors[] = "Amount due is required";
    }

    if(!empty($errors)) {
        $error_message = implode("<br>", $errors);
    } else {
        // Hash password
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);

        // Insert doctor
        $sql = "INSERT INTO doctors (name, email, password, phone, location, speciality, schedule, description, sex, address, amount_due) 
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        
        $stmt = $conn->prepare($sql);
        
        if ($stmt) {
            $stmt->bind_param("sssssssssss", 
                $full_name, $email, $hashed_password, $phone, $location,
                $speciality, $schedule, $description, $sex, $address, 
                $amount_due
            );
            
            if ($stmt->execute()) {
                $success_message = "Doctor added successfully!";
                header("refresh:2;url=manage_doctor.php");
            } else {
                $error_message = "Error adding doctor: " . $stmt->error;
            }
            
            $stmt->close();
        } else {
            $error_message = "Error preparing statement: " . $conn->error;
        }
    }
}

$conn->close();
?>

<div class="row">
    <div class="col-md-12">
        <h2 style="color:black;">Add New Doctor</h2>
        <hr>
    </div>
</div>

<div class="row">
    <div class="col-md-8 offset-md-2">
        <div class="card">
            <div class="card-body">
                <?php if(isset($success_message)): ?>
                <div class="alert alert-success">
                    <?php echo $success_message; ?>
                    <br>
                    Redirecting to doctor list...
                </div>
                <?php endif; ?>

                <?php if(isset($error_message)): ?>
                <div class="alert alert-danger">
                    <?php echo $error_message; ?>
                </div>
                <?php endif; ?>

                <form method="POST" action="">
                    <div class="form-group">
                        <label>Full Name</label>
                        <input type="text" class="form-control" name="full_name" 
                               value="<?php echo htmlspecialchars($_POST['full_name'] ?? ''); ?>" 
                               required>
                    </div>

                    <div class="form-group">
                        <label>Email (Username)</label>
                        <input type="email" class="form-control" name="email" 
                               value="<?php echo htmlspecialchars($_POST['email'] ?? ''); ?>" 
                               required>
                        <small class="text-muted">This will be used as the doctor's login username</small>
                    </div>

                    <div class="form-group">
                        <label>Password</label>
                        <input type="password" class="form-control" name="password" 
                               required>
                        <small class="text-muted">Minimum 6 characters required</small>
                    </div>

                    <div class="form-group">
                        <label>Phone Number</label>
                        <input type="tel" class="form-control" name="phone" 
                               value="<?php echo htmlspecialchars($_POST['phone'] ?? ''); ?>" 
                               required>
                    </div>

                    <div class="form-group">
                        <label>Location</label>
                        <input type="text" class="form-control" name="location" 
                               value="<?php echo htmlspecialchars($_POST['location'] ?? ''); ?>" 
                               required>
                    </div>

                    <div class="form-group">
                        <label>Speciality</label>
                        <select class="form-control" name="speciality" required>
                            <option value="">Select Speciality</option>
                            <option value="Audiology">Audiology</option>
                            <option value="Cardiology">Cardiology</option>
                            <option value="Dentistry">Dentistry</option>
                            <option value="Diabetology">Diabetology</option>
                            <option value="Children Medicine">Children Medicine</option>
                            <option value="Radiology">Radiology</option>
                            <option value="Hepatology">Hepatology</option>
                            <option value="Optician">Optician</option>
                            <option value="Nephrology">Nephrology</option>
                            <option value="Neurology">Neurology</option>
                        </select>
                    </div>

                    <div class="form-group">
                        <label>Schedule</label>
                        <select class="form-control" name="schedule" required>
                            <option value="">Select Schedule</option>
                            <option value="10 AM to 5 PM">10 AM to 5 PM</option>
                            <option value="5 PM to 10 PM">5 PM to 10 PM</option>
                            <option value="10 PM to 5 AM">10 PM to 5 AM</option>
                        </select>
                    </div>

                    <div class="form-group">
                        <label>Description</label>
                        <textarea class="form-control" name="description" rows="4" required><?php echo htmlspecialchars($_POST['description'] ?? ''); ?></textarea>
                    </div>

                    <div class="form-group">
                        <label>Sex</label>
                        <select class="form-control" name="sex" required>
                            <option value="">Select sex</option>
                            <option value="male" <?php echo ($_POST['sex'] ?? '') == 'male' ? 'selected' : ''; ?>>Male</option>
                            <option value="female" <?php echo ($_POST['sex'] ?? '') == 'female' ? 'selected' : ''; ?>>Female</option>
                        </select>
                    </div>

                    <div class="form-group">
                        <label>Address</label>
                        <textarea class="form-control" name="address" rows="3"><?php echo htmlspecialchars($_POST['address'] ?? ''); ?></textarea>
                    </div>

                    <div class="form-group">
                        <label>Amount Due (Fees)</label>
                        <select class="form-control" name="amount_due" required>
                            <option value="">Select Fees</option>
                            <option value="500">Rs. 500</option>
                            <option value="1000">Rs. 1000</option>
                            <option value="1500">Rs. 1500</option>
                            <option value="2000">Rs. 2000</option>
                        </select>
                    </div>

                    <div class="form-group">
                        <button type="submit" class="btn btn-primary btn-lg btn-block">Add Doctor</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<?php include("footer.php"); ?>
