<?php
session_start();

// Database connection
$conn = new mysqli("localhost", "root", "", "Medisched_db");

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if admin_users table exists
$sql = "SHOW TABLES LIKE 'admin_users'";
$result = $conn->query($sql);

if ($result === false) {
    $error = "Database error: " . $conn->error;
} elseif ($result->num_rows == 0) {
    // Try to create the table
    $create_table_sql = "CREATE TABLE admin_users (
        id INT AUTO_INCREMENT PRIMARY KEY,
        username VARCHAR(50) UNIQUE NOT NULL,
        password VARCHAR(255) NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )";
    
    if ($conn->query($create_table_sql) === TRUE) {
        // Insert default admin user
        $default_username = 'admin';
        $default_password = 'admin123';
        
        $insert_sql = "INSERT INTO admin_users (username, password) VALUES (?, ?)";
        $stmt = $conn->prepare($insert_sql);
        
        if ($stmt !== false) {
            $stmt->bind_param("ss", $default_username, $default_password);
            if ($stmt->execute()) {
                $error = "Admin system has been set up. Please try logging in again.";
            } else {
                $error = "Error creating default admin user: " . $conn->error;
            }
        } else {
            $error = "Error preparing statement: " . $conn->error;
        }
    } else {
        $error = "Error creating admin_users table: " . $conn->error;
    }
} else {
    // Check if form is submitted
    if (isset($_POST['login'])) {
        $username = $conn->real_escape_string($_POST['username']);
        $password = $conn->real_escape_string($_POST['password']);
        
        // Query to check admin credentials
        $sql = "SELECT * FROM admin_users WHERE username = ? AND password = ?";
        $stmt = $conn->prepare($sql);
        
        if ($stmt === false) {
            $error = "Database error occurred. Please try again later.";
        } else {
            $stmt->bind_param("ss", $username, $password);
            $stmt->execute();
            $result = $stmt->get_result();
            
            if ($result->num_rows > 0) {
                $_SESSION['admin_user'] = $username;
                $_SESSION['admin_login_time'] = date('Y-m-d H:i:s');
                header("Location: index.php");
                exit();
            } else {
                $error = "Invalid username or password";
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Login - Medisched</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #f8f9fa;
        }
        .login-container {
            max-width: 400px;
            margin: 100px auto;
            padding: 20px;
            background: white;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
        }
        .login-header {
            text-align: center;
            margin-bottom: 30px;
        }
        .login-header h1 {
            color: #333;
            font-size: 24px;
        }
        .error-message {
            color: #dc3545;
            margin-bottom: 15px;
            text-align: center;
        }
        .success-message {
            color: #28a745;
            margin-bottom: 15px;
            text-align: center;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="login-container">
            <div class="login-header">
                <h1>Admin Login</h1>
                <p>Please enter your credentials to continue</p>
            </div>
            
            <?php if (isset($error)): ?>
                <div class="error-message">
                    <?php echo $error; ?>
                </div>
            <?php endif; ?>
            
            <form method="POST" action="">
                <div class="mb-3">
                    <label for="username" class="form-label">Username</label>
                    <input type="text" class="form-control" id="username" name="username" required>
                </div>
                <div class="mb-3">
                    <label for="password" class="form-label">Password</label>
                    <input type="password" class="form-control" id="password" name="password" required>
                </div>
                <div class="d-grid">
                    <button type="submit" name="login" class="btn btn-primary">Login</button>
                </div>
            </form>
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
