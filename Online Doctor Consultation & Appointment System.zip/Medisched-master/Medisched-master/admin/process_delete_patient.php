<?php
session_start();

// Database configuration
$host = "localhost";
$username = "root";
$password = "";
$database = "medisched_db";

// Create connection
$conn = new mysqli($host, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if(isset($_GET['id'])) {
    $patient_id = $conn->real_escape_string($_GET['id']);

    // Delete patient
    $sql = "DELETE FROM patients WHERE id = ?";
    
    $stmt = $conn->prepare($sql);
    if (!$stmt) {
        die("Error preparing statement: " . $conn->error);
    }

    if (!$stmt->bind_param("i", $patient_id)) {
        die("Error binding parameters: " . $conn->error);
    }

    if($stmt->execute()) {
        echo "<script>alert('Patient deleted successfully!');
                window.location.href = 'patient_list.php';</script>";
    } else {
        echo "<script>alert('Error deleting patient: " . $stmt->error . ");
                window.location.href = 'patient_list.php';</script>";
    }
    
    $stmt->close();
} else {
    echo "<script>alert('Invalid request!');
            window.location.href = 'patient_list.php';</script>";
}

$conn->close();
?>
