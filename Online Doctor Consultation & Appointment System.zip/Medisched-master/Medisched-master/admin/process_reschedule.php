<?php
session_start();

// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get form data
    $appointment_id = isset($_POST["appointment_id"]) ? (int)$_POST["appointment_id"] : 0;
    $new_date = isset($_POST["new_date"]) ? trim($_POST["new_date"]) : '';
    $new_time = isset($_POST["new_time"]) ? trim($_POST["new_time"]) : '';
    $reason = isset($_POST["reason"]) ? trim($_POST["reason"]) : '';
    
    // Validate inputs
    if ($appointment_id <= 0) {
        echo "<div class='alert alert-danger'>Invalid appointment ID.</div>";
        exit();
    }

    if (empty($new_date)) {
        echo "<div class='alert alert-danger'>Please select a new date.</div>";
        exit();
    }

    if (empty($new_time)) {
        echo "<div class='alert alert-danger'>Please select a new time.</div>";
        exit();
    }

    if (empty($reason)) {
        echo "<div class='alert alert-danger'>Please provide a reason for rescheduling.</div>";
        exit();
    }

    try {
        // Connect to database
        $conn = new mysqli("localhost", "root", "", "medisched_db");
        
        if ($conn->connect_error) {
            throw new Exception("Connection failed: " . $conn->connect_error);
        }

        // Update appointment with new date, time, and reason
        $sql = "UPDATE appointments SET 
            date_time = CONCAT(?,' ',?),
            reason = ?,
            updated_at = NOW()
            WHERE id = ?";
        
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("sssi", $new_date, $new_time, $reason, $appointment_id);
        
        if ($stmt->execute()) {
            echo "<div class='alert alert-success'>Appointment rescheduled successfully!</div>";
            echo "<script>
                setTimeout(function() {
                    window.location.href = 'appointment_list.php';
                }, 2000);
            </script>";
        } else {
            echo "<div class='alert alert-danger'>Failed to reschedule appointment. Please try again.</div>";
        }
        
        $stmt->close();
        $conn->close();
    } catch (Exception $e) {
        echo "<div class='alert alert-danger'>Error: " . $e->getMessage() . "</div>";
    }
}

include("header.php");
include("footer.php");
?>
