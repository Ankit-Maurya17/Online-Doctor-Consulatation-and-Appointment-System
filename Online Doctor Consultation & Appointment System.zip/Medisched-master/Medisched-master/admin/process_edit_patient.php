<?php
session_start();

// Database configuration
$host = "localhost";
$username = "root";
$password = "";
$database = "medisched_db";

// Create connection
$conn = new mysqli($host, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Drop existing patients table if it exists
$sql = "DROP TABLE IF EXISTS patients";
$conn->query($sql);

// Create patients table
$sql = "CREATE TABLE patients (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    phone VARCHAR(20) NOT NULL,
    address TEXT,
    doctor VARCHAR(255),
    amount_due DECIMAL(10,2),
    payment_status ENUM('Pending', 'Paid') DEFAULT 'Pending',
    appointment_date DATE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
)";

if (!$conn->query($sql)) {
    die("Error creating table: " . $conn->error);
}

if(isset($_POST['patient_id'])) {
    $patient_id = $_POST['patient_id'];
    $patient_name = $conn->real_escape_string($_POST['patient_name']);
    $patient_phone = $conn->real_escape_string($_POST['patient_contact']);
    $patient_address = $conn->real_escape_string($_POST['patient_address']);
    $doctor_name = $conn->real_escape_string($_POST['doctor_name']);
    $amount_due = $conn->real_escape_string($_POST['doctor_fee']);
    $payment_status = $conn->real_escape_string($_POST['payment_status']);
    $appointment_date = $conn->real_escape_string($_POST['appointment_date']);

    // Update patient details
    $sql = "UPDATE patients SET 
            name = ?,
            phone = ?,
            address = ?,
            doctor = ?,
            amount_due = ?,
            payment_status = ?,
            appointment_date = ?
            WHERE id = ?";

    $stmt = $conn->prepare($sql);
    if (!$stmt) {
        die("Error preparing statement: " . $conn->error);
    }

    if (!$stmt->bind_param("sssssssi", 
        $patient_name, $patient_phone, $patient_address,
        $doctor_name, $amount_due, $payment_status,
        $appointment_date, $patient_id
    )) {
        die("Error binding parameters: " . $conn->error);
    }

    if($stmt->execute()) {
        echo "<script>alert('Patient details updated successfully!');
                window.location.href = 'patient_list.php';</script>";
    } else {
        echo "<script>alert('Error updating patient details: " . $stmt->error . ");
                window.location.href = 'patient_list.php';</script>";
    }
    
    $stmt->close();
} else {
    echo "<script>alert('Invalid request!');
            window.location.href = 'patient_list.php';</script>";
}

$conn->close();
?>
