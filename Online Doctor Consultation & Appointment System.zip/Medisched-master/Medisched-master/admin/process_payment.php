<?php
session_start();
include("header.php");

// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get form data
    $payment_method = $_POST["payment_method"];
    $transaction_id = $_POST["transaction_id"];
    $payment_date = $_POST["payment_date"];
    
    // Validate inputs
    if (empty($payment_method) || empty($transaction_id) || empty($payment_date)) {
        echo "<div class='alert alert-danger'>Please fill in all payment details.</div>";
        exit();
    }
    
    // Here you would typically update the database
    // For now, we'll just show a success message
    
    echo "<div class='alert alert-success'>Payment marked as paid successfully!</div>";
    
    // Redirect back to appointment list after 2 seconds
    echo "<script>
        setTimeout(function() {
            window.location.href = 'appointment_list.php';
        }, 2000);
    </script>";
}

include("footer.php");
?>
