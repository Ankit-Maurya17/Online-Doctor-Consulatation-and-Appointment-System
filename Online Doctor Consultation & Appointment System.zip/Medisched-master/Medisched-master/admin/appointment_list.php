<?php
include("header.php");

// Database configuration
$host = "localhost";
$username = "root";
$password = "";
$database = "medisched_db";

// Create connection
$conn = new mysqli($host, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Create tables if they don't exist
$sql = "CREATE TABLE IF NOT EXISTS appointments (
    id INT AUTO_INCREMENT PRIMARY KEY,
    patient_id INT NOT NULL,
    doctor_id INT NOT NULL,
    date_time DATETIME NOT NULL,
    amount_due DECIMAL(10,2) NOT NULL,
    status ENUM('Pending', 'Confirmed', 'Cancelled') DEFAULT 'Pending',
    reason TEXT,
    payment_status ENUM('Pending', 'Paid') DEFAULT 'Pending',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
)";

if ($conn->query($sql) === TRUE) {
    echo "";
} else {
    echo "Error creating table: " . $conn->error;
}

// Create patients table
$sql = "CREATE TABLE IF NOT EXISTS patients (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    email VARCHAR(255) NOT NULL,
    phone VARCHAR(20) NOT NULL,
    address TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
)";

if ($conn->query($sql) === TRUE) {
    echo "";
} else {
    echo "Error creating table: " . $conn->error;
}

// Create doctors table
$sql = "CREATE TABLE IF NOT EXISTS doctors (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    speciality VARCHAR(255) NOT NULL,
    email VARCHAR(255) NOT NULL,
    phone VARCHAR(20) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
)";

if ($conn->query($sql) === TRUE) {
    echo "";
} else {
    echo "Error creating table: " . $conn->error;
}

// Insert sample patients
$patients = array(
    array('name' => 'John Doe', 'email' => 'john@example.com', 'phone' => '1234567890'),
    array('name' => 'Jane Smith', 'email' => 'jane@example.com', 'phone' => '9876543210'),
    array('name' => 'Mike Brown', 'email' => 'mike@example.com', 'phone' => '5555555555'),
    array('name' => 'Sarah Johnson', 'email' => 'sarah@example.com', 'phone' => '1112223333'),
    array('name' => 'David Wilson', 'email' => 'david@example.com', 'phone' => '4445556666')
);

foreach($patients as $patient) {
    $sql = "INSERT INTO patients (name, email, phone) VALUES (?, ?, ?)";
    $stmt = $conn->prepare($sql);
    if ($stmt === false) {
        die("Error preparing statement: " . $conn->error);
    }
    $stmt->bind_param("sss", $patient['name'], $patient['email'], $patient['phone']);
    $stmt->execute();
    $stmt->close();
}

// Insert sample doctors
$doctors = array(
    array('name' => 'Dr. Smith', 'speciality' => 'Cardiology', 'email' => 'drsmith@example.com', 'phone' => '1111111111'),
    array('name' => 'Dr. Johnson', 'speciality' => 'Dentistry', 'email' => 'drjohnson@example.com', 'phone' => '2222222222'),
    array('name' => 'Dr. Williams', 'speciality' => 'Orthopedics', 'email' => 'drwilliams@example.com', 'phone' => '3333333333'),
    array('name' => 'Dr. Brown', 'speciality' => 'Neurology', 'email' => 'drbrown@example.com', 'phone' => '4444444444')
);

foreach($doctors as $doctor) {
    $sql = "INSERT INTO doctors (name, speciality, email, phone) VALUES (?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    if ($stmt === false) {
        die("Error preparing statement: " . $conn->error);
    }
    $stmt->bind_param("ssss", $doctor['name'], $doctor['speciality'], $doctor['email'], $doctor['phone']);
    $stmt->execute();
    $stmt->close();
}

// Insert sample appointments
$appointments = array(
    array('patient_id' => 1, 'doctor_id' => 1, 'date_time' => '2023-03-01 10:00:00', 'amount_due' => 100.00),
    array('patient_id' => 2, 'doctor_id' => 2, 'date_time' => '2023-03-02 11:00:00', 'amount_due' => 200.00),
    array('patient_id' => 3, 'doctor_id' => 3, 'date_time' => '2023-03-03 12:00:00', 'amount_due' => 300.00),
    array('patient_id' => 4, 'doctor_id' => 4, 'date_time' => '2023-03-04 13:00:00', 'amount_due' => 400.00),
    array('patient_id' => 5, 'doctor_id' => 5, 'date_time' => '2023-03-05 14:00:00', 'amount_due' => 500.00)
);

foreach($appointments as $appointment) {
    $sql = "INSERT INTO appointments (patient_id, doctor_id, date_time, amount_due) VALUES (?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    if ($stmt === false) {
        die("Error preparing statement: " . $conn->error);
    }
    $stmt->bind_param("iids", $appointment['patient_id'], $appointment['doctor_id'], $appointment['date_time'], $appointment['amount_due']);
    $stmt->execute();
    $stmt->close();
}

// Get appointments from database
$sql = "SELECT a.id, a.patient_id, a.doctor_id, a.date_time, a.amount_due, a.status, a.payment_status,
        p.name as patient_name, p.email as patient_email, d.name as doctor_name, d.speciality, d.email as doctor_email 
        FROM appointments a
        JOIN patients p ON a.patient_id = p.id
        JOIN doctors d ON a.doctor_id = d.id
        WHERE a.status != ?
        ORDER BY a.date_time ASC";

$stmt = $conn->prepare($sql);
if ($stmt === false) {
    die("Error preparing statement: " . $conn->error);
}

$status = 'Cancelled';
$stmt->bind_param("s", $status);
$stmt->execute();
$result = $stmt->get_result();

$appointments = array();
if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $appointments[] = array(
            'id' => $row['id'],
            'patient_name' => $row['patient_name'],
            'patient_email' => $row['patient_email'],
            'doctor_name' => $row['doctor_name'],
            'doctor_email' => $row['doctor_email'],
            'speciality' => $row['speciality'],
            'date_time' => date('Y-m-d h:i A', strtotime($row['date_time'])),
            'amount_due' => $row['amount_due'],
            'payment_status' => $row['payment_status']
        );
    }
}

$stmt->close();
$conn->close();
?>

<div class="row">
    <div class="col-md-12">
        <h2 style="color:black;">Appointment Details</h2>
        <hr>
    </div>
</div>

<div class="row">
    <div class="col-md-12">
        <div class="panel panel-primary">
            <div class="panel-heading">
                <h3 class="panel-title">Upcoming Appointments</h3>
            </div>
            <div class="panel-body">
                <div class="table-responsive">
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th>Patient Name</th>
                                <th>Patient Email</th>
                                <th>Doctor Name</th>
                                <th>Doctor Email</th>
                                <th>Speciality</th>
                                <th>Date & Time</th>
                                <th>Amount Due Fee</th>
                                <th>Payment Status</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            foreach($appointments as $appointment) {
                                echo "<tr>";
                                echo "<td>" . $appointment['patient_name'] . "</td>";
                                echo "<td>" . $appointment['patient_email'] . "</td>";
                                echo "<td>" . $appointment['doctor_name'] . "</td>";
                                echo "<td>" . $appointment['doctor_email'] . "</td>";
                                echo "<td>" . $appointment['speciality'] . "</td>";
                                echo "<td>" . $appointment['date_time'] . "</td>";
                                echo "<td>";
                                if($appointment['payment_status'] == 'Paid') {
                                    echo "<span class='label label-success'>₹" . $appointment['amount_due'] . " (Paid)</span>";
                                } else {
                                    echo "<span class='label label-warning'>₹" . $appointment['amount_due'] . " (Due)</span>";
                                }
                                echo "</td>";
                                echo "<td><span class='label label-" . ($appointment['payment_status'] == 'Paid' ? 'success' : 'warning') . "'>" . $appointment['payment_status'] . "</span></td>";
                                echo "<td>";
                                echo "<button class='btn btn-info btn-sm' data-toggle='modal' data-target='#appointmentDetailsModal' data-id='" . $appointment['id'] . "'>Details</button>";
                                echo "</td>";
                                echo "</tr>";
                            }
                            ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Appointment Details Modal -->
<div class="modal fade" id="appointmentDetailsModal" role="dialog">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h4 class="modal-title">Appointment Details</h4>
            </div>
            <div class="modal-body">
                <div id="appointmentDetails"></div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>

<script>
$(document).ready(function(){
    $("button[data-toggle='modal']").click(function(){
        var appointmentId = $(this).data('id');
        
        $.ajax({
            url: 'get_appointment_details.php',
            method: 'POST',
            data: {id: appointmentId},
            success: function(response){
                $('#appointmentDetails').html(response);
            }
        });
    });
});
</script>

<?php
include("footer.php");
?>
