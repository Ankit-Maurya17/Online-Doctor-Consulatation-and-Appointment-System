<?php
include("header.php");
?>
<div class="row">
    <div class="col-md-12">
        <h2 style="color:black;">Appointment Management</h2>
        <hr>
    </div>
</div>

<div class="row">
    <div class="col-md-12">
        <div class="panel panel-primary">
            <div class="panel-heading">
                <h3 class="panel-title">Upcoming Appointments</h3>
            </div>
            <div class="panel-body">
                <div class="table-responsive">
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th>Patient Name</th>
                                <th>Doctor Name</th>
                                <th>Speciality</th>
                                <th>Date & Time</th>
                                <th>Payment Status</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <!-- Sample appointment data - replace with actual data from database -->
                            <tr>
                                <td>John Doe</td>
                                <td>Dr. Smith</td>
                                <td>Cardiology</td>
                                <td>2025-03-28 10:00 AM</td>
                                <td><span class="label label-success">Paid</span></td>
                                <td>
                                    <button class="btn btn-warning btn-sm" data-toggle="modal" data-target="#rescheduleModal">
                                        Reschedule
                                    </button>
                                    <button class="btn btn-danger btn-sm" data-toggle="modal" data-target="#cancelModal">
                                        Cancel
                                    </button>
                                </td>
                            </tr>
                            <tr>
                                <td>Jane Smith</td>
                                <td>Dr. Johnson</td>
                                <td>Dentistry</td>
                                <td>2025-03-28 11:30 AM</td>
                                <td><span class="label label-warning">Pending</span></td>
                                <td>
                                    <button class="btn btn-warning btn-sm" data-toggle="modal" data-target="#rescheduleModal">
                                        Reschedule
                                    </button>
                                    <button class="btn btn-danger btn-sm" data-toggle="modal" data-target="#cancelModal">
                                        Cancel
                                    </button>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Reschedule Appointment Modal -->
<div class="modal fade" id="rescheduleModal" role="dialog">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h4 class="modal-title">Reschedule Appointment</h4>
            </div>
            <div class="modal-body">
                <form action="process_reschedule.php" method="POST" class="form-horizontal">
                    <div class="form-group">
                        <label class="control-label col-sm-2">New Date:</label>
                        <div class="col-sm-10">
                            <input type="date" class="form-control" name="new_date" required>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="control-label col-sm-2">New Time:</label>
                        <div class="col-sm-10">
                            <input type="time" class="form-control" name="new_time" required>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="control-label col-sm-2">Reason:</label>
                        <div class="col-sm-10">
                            <textarea class="form-control" name="reason" rows="3" required></textarea>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-warning">Reschedule</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<!-- Cancel Appointment Modal -->
<div class="modal fade" id="cancelModal" role="dialog">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h4 class="modal-title">Cancel Appointment</h4>
            </div>
            <div class="modal-body">
                <form action="process_cancel.php" method="POST" class="form-horizontal">
                    <div class="form-group">
                        <label class="control-label col-sm-2">Reason:</label>
                        <div class="col-sm-10">
                            <textarea class="form-control" name="reason" rows="3" required></textarea>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-danger">Cancel Appointment</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<div class="row">
    <div class="col-md-12">
        <div class="panel panel-primary">
            <div class="panel-heading">
                <h3 class="panel-title">Payment Status</h3>
            </div>
            <div class="panel-body">
                <div class="table-responsive">
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th>Patient Name</th>
                                <th>Appointment Date</th>
                                <th>Doctor Name</th>
                                <th>Amount Due</th>
                                <th>Payment Status</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>John Doe</td>
                                <td>2025-03-28</td>
                                <td>Dr. Smith</td>
                                <td>₹1000</td>
                                <td><span class="label label-success">Paid</span></td>
                                <td>
                                    <button class="btn btn-info btn-sm" data-toggle="modal" data-target="#paymentDetailsModal">
                                        View Details
                                    </button>
                                </td>
                            </tr>
                            <tr>
                                <td>Jane Smith</td>
                                <td>2025-03-28</td>
                                <td>Dr. Johnson</td>
                                <td>₹800</td>
                                <td><span class="label label-warning">Pending</span></td>
                                <td>
                                    <button class="btn btn-success btn-sm" data-toggle="modal" data-target="#paymentModal">
                                        Mark as Paid
                                    </button>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Payment Details Modal -->
<div class="modal fade" id="paymentDetailsModal" role="dialog">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h4 class="modal-title">Payment Details</h4>
            </div>
            <div class="modal-body">
                <div class="row">
                    <div class="col-md-6">
                        <strong>Patient Name:</strong> John Doe<br>
                        <strong>Appointment Date:</strong> 2025-03-28<br>
                        <strong>Doctor Name:</strong> Dr. Smith<br>
                        <strong>Payment Method:</strong> Credit Card<br>
                        <strong>Transaction ID:</strong> TXN123456789<br>
                        <strong>Amount:</strong> ₹1000<br>
                        <strong>Status:</strong> Completed<br>
                    </div>
                    <div class="col-md-6">
                        <strong>Payment Date:</strong> 2025-03-27<br>
                        <strong>Time:</strong> 14:30 PM<br>
                        <strong>Reference Number:</strong> REF123456<br>
                        <strong>Bank:</strong> HDFC Bank<br>
                        <strong>Payment Gateway:</strong> Razorpay<br>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>

<!-- Mark as Paid Modal -->
<div class="modal fade" id="paymentModal" role="dialog">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h4 class="modal-title">Mark as Paid</h4>
            </div>
            <div class="modal-body">
                <form action="process_payment.php" method="POST" class="form-horizontal">
                    <div class="form-group">
                        <label class="control-label col-sm-2">Payment Method:</label>
                        <div class="col-sm-10">
                            <select class="form-control" name="payment_method" required>
                                <option value="cash">Cash</option>
                                <option value="card">Credit/Debit Card</option>
                                <option value="upi">UPI</option>
                                <option value="bank">Bank Transfer</option>
                            </select>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="control-label col-sm-2">Transaction ID:</label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control" name="transaction_id" required>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="control-label col-sm-2">Payment Date:</label>
                        <div class="col-sm-10">
                            <input type="date" class="form-control" name="payment_date" required>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-success">Mark as Paid</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<?php
include("footer.php");
?>
