<?php
session_start();

// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get form data
    $doctor_id = $_POST['doctor_id'] ?? '';
    $full_name = $_POST['full_name'] ?? '';
    $email = $_POST['email'] ?? '';
    $phone = $_POST['phone'] ?? '';
    $location = $_POST['location'] ?? '';
    $speciality = $_POST['speciality'] ?? '';
    $schedule = $_POST['schedule'] ?? '';
    $description = $_POST['description'] ?? '';
    $sex = $_POST['sex'] ?? '';
    $address = $_POST['address'] ?? '';
    $amount_due = $_POST['amount_due'] ?? '';

    // Validate data
    $errors = array();
    
    if(empty($doctor_id)) {
        $errors[] = "Doctor ID is required";
    }
    
    if(empty($full_name)) {
        $errors[] = "Full name is required";
    }
    
    if(empty($email)) {
        $errors[] = "Email is required";
    }
    
    if(empty($phone)) {
        $errors[] = "Phone number is required";
    }
    
    if(empty($location)) {
        $errors[] = "Location is required";
    }
    
    if(empty($speciality)) {
        $errors[] = "Speciality is required";
    }
    
    if(empty($schedule)) {
        $errors[] = "Schedule is required";
    }
    
    if(empty($description)) {
        $errors[] = "Description is required";
    }
    
    if(empty($sex)) {
        $errors[] = "Sex is required";
    }
    
    if(empty($address)) {
        $errors[] = "Address is required";
    }
    
    if(empty($amount_due)) {
        $errors[] = "Fee is required";
    }

    // If there are errors, show them
    if(!empty($errors)) {
        echo "<div class='alert alert-danger'>";
        foreach($errors as $error) {
            echo "$error<br>";
        }
        echo "</div>";
        exit();
    }

    try {
        // Connect to database
        $conn = new mysqli("localhost", "root", "", "medisched_db");
        
        if ($conn->connect_error) {
            throw new Exception("Connection failed: " . $conn->connect_error);
        }

        // Update doctor data
        $sql = "UPDATE doctors SET 
            name = ?,
            email = ?,
            phone = ?,
            location = ?,
            speciality = ?,
            schedule = ?,
            description = ?,
            sex = ?,
            address = ?,
            amount_due = ?
            WHERE id = ?";
        
        $stmt = $conn->prepare($sql);
        if (!$stmt) {
            throw new Exception("Error preparing statement: " . $conn->error);
        }

        $stmt->bind_param("ssssssssdsi", 
            $full_name, $email, $phone, $location,
            $speciality, $schedule, $description,
            $sex, $address, $amount_due, $doctor_id
        );
        
        if ($stmt->execute()) {
            echo "<div class='alert alert-success'>Doctor profile updated successfully!</div>";
            echo "<script>
                setTimeout(function() {
                    window.location.href = 'manage_doctor.php';
                }, 2000);
            </script>";
        } else {
            throw new Exception("Error updating doctor: " . $stmt->error);
        }
        
        $stmt->close();
        $conn->close();
    } catch (Exception $e) {
        echo "<div class='alert alert-danger'>Error: " . $e->getMessage() . "</div>";
    }
}

include("header.php");
include("footer.php");
?>
