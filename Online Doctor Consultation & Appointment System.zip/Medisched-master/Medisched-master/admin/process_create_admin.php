<?php
session_start();
include("header.php");

// Process form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST["username"] ?? "";
    $password = $_POST["password"] ?? "";
    
    // Validate input
    if (empty($username) || empty($password)) {
        $error = "All fields are required";
    } elseif (strlen($password) < 8) {
        $error = "Password must be at least 8 characters long";
    } else {
        try {
            $conn = new mysqli("localhost", "root", "", "Medisched_db");
            
            if ($conn->connect_error) {
                throw new Exception("Connection failed: " . $conn->connect_error);
            }

            // Check if username already exists
            $stmt = $conn->prepare("SELECT id FROM admin_users WHERE username = ?");
            $stmt->bind_param("s", $username);
            $stmt->execute();
            $result = $stmt->get_result();

            if ($result->num_rows > 0) {
                $error = "Username already exists";
            } else {
                // Insert new admin user
                $stmt = $conn->prepare("INSERT INTO admin_users (username, password) VALUES (?, ?)");
                $stmt->bind_param("ss", $username, $password);
                
                if ($stmt->execute()) {
                    $success = "Admin account created successfully!";
                } else {
                    $error = "Error creating account";
                }
            }

            $stmt->close();
            $conn->close();
        } catch (Exception $e) {
            $error = "Error: " . $e->getMessage();
        }
    }
}

// Redirect back to account page
header("Location: account.php");
exit();
