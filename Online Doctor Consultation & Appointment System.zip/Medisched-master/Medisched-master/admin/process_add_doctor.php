<?php
session_start();

// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get form data
    $email = $_POST['email'] ?? '';
    $full_name = $_POST['full_name'] ?? '';
    $contact = $_POST['contact'] ?? '';
    $schedule = $_POST['schedule'] ?? '';
    $description = $_POST['description'] ?? '';
    $sex = $_POST['sex'] ?? '';
    $address = $_POST['address'] ?? '';
    $fees = $_POST['fees'] ?? '';
    $speciality = $_POST['speciality'] ?? '';
    $location = $_POST['location'] ?? '';

    // Validate data
    $errors = array();
    
    if(empty($email)) {
        $errors[] = "Email is required";
    }
    
    if(empty($full_name)) {
        $errors[] = "Full name is required";
    }
    
    if(empty($contact)) {
        $errors[] = "Contact number is required";
    }
    
    if(empty($schedule)) {
        $errors[] = "Schedule is required";
    }
    
    if(empty($description)) {
        $errors[] = "Description is required";
    }
    
    if(empty($sex)) {
        $errors[] = "Sex is required";
    }
    
    if(empty($address)) {
        $errors[] = "Address is required";
    }
    
    if(empty($fees)) {
        $errors[] = "Fees is required";
    }
    
    if(empty($speciality)) {
        $errors[] = "Speciality is required";
    }
    
    if(empty($location)) {
        $errors[] = "Location is required";
    }

    // If there are errors, show them
    if(!empty($errors)) {
        echo "<div class='alert alert-danger'>";
        foreach($errors as $error) {
            echo "$error<br>";
        }
        echo "</div>";
        exit();
    }

    try {
        // Connect to database
        $conn = new mysqli("localhost", "root", "", "medisched_db");
        
        if ($conn->connect_error) {
            throw new Exception("Connection failed: " . $conn->connect_error);
        }

        // Drop existing doctors table if it exists
        $sql = "DROP TABLE IF EXISTS doctors";
        $conn->query($sql);

        // Create doctors table
        $sql = "CREATE TABLE doctors (
            id INT AUTO_INCREMENT PRIMARY KEY,
            name VARCHAR(255) NOT NULL,
            speciality VARCHAR(255) NOT NULL,
            email VARCHAR(255) NOT NULL,
            phone VARCHAR(20) NOT NULL,
            schedule VARCHAR(50) NOT NULL,
            description TEXT NOT NULL,
            sex ENUM('male', 'female') NOT NULL,
            address TEXT,
            amount_due DECIMAL(10,2) NOT NULL,
            location VARCHAR(255) NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
        )";

        if (!$conn->query($sql)) {
            throw new Exception("Error creating table: " . $conn->error);
        }

        // Insert doctor data
        $sql = "INSERT INTO doctors (
            name, speciality, email, phone, schedule, description, 
            sex, address, amount_due, location
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        
        $stmt = $conn->prepare($sql);
        if (!$stmt) {
            throw new Exception("Error preparing statement: " . $conn->error);
        }

        $stmt->bind_param("sssssssssd", 
            $full_name, $speciality, $email, $contact, $schedule,
            $description, $sex, $address, $fees, $location
        );
        
        if ($stmt->execute()) {
            echo "<div class='alert alert-success'>Doctor added successfully!</div>";
            echo "<script>
                setTimeout(function() {
                    window.location.href = 'manage_doctor.php';
                }, 2000);
            </script>";
        } else {
            throw new Exception("Error executing query: " . $stmt->error);
        }
        
        $stmt->close();
        $conn->close();
    } catch (Exception $e) {
        echo "<div class='alert alert-danger'>Error: " . $e->getMessage() . "</div>";
    }
}

include("header.php");
include("footer.php");
?>
