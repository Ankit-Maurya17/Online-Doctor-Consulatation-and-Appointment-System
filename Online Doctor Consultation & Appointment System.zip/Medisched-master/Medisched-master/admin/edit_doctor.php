<?php
session_start();

// Check if doctor ID is provided
if (!isset($_GET['id'])) {
    header("Location: manage_doctor.php");
    exit();
}

$doctor_id = $_GET['id'];

try {
    // Connect to database
    $conn = new mysqli("localhost", "root", "", "medisched_db");
    
    if ($conn->connect_error) {
        throw new Exception("Connection failed: " . $conn->connect_error);
    }

    // Get doctor details
    $sql = "SELECT * FROM doctors WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $doctor_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows == 0) {
        throw new Exception("Doctor not found");
    }

    $doctor = $result->fetch_assoc();
    $stmt->close();
    $conn->close();

} catch (Exception $e) {
    echo "<div class='alert alert-danger'>Error: " . $e->getMessage() . "</div>";
    exit();
}

include("header.php");
?>

<div class="row">
    <div class="col-md-12">
        <h2 style="color:black;">Edit Doctor Profile</h2>
        <hr>
    </div>
</div>

<div class="row">
    <div class="col-md-12">
        <div class="panel panel-primary">
            <div class="panel-heading">
                <h3 class="panel-title">Edit Doctor Details</h3>
            </div>
            <div class="panel-body">
                <form action="process_edit_doctor.php" method="POST" class="form-horizontal">
                    <input type="hidden" name="doctor_id" value="<?php echo $doctor_id; ?>">
                    
                    <!-- Full Name -->
                    <div class="form-group">
                        <label class="control-label col-sm-2">Full Name:</label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control" name="full_name" value="<?php echo htmlspecialchars($doctor['name']); ?>" required>
                        </div>
                    </div>

                    <!-- Email -->
                    <div class="form-group">
                        <label class="control-label col-sm-2">Email:</label>
                        <div class="col-sm-10">
                            <input type="email" class="form-control" name="email" value="<?php echo htmlspecialchars($doctor['email']); ?>" required>
                        </div>
                    </div>

                    <!-- Phone -->
                    <div class="form-group">
                        <label class="control-label col-sm-2">Phone:</label>
                        <div class="col-sm-10">
                            <input type="tel" class="form-control" name="phone" value="<?php echo htmlspecialchars($doctor['phone']); ?>" required>
                        </div>
                    </div>

                    <!-- Location -->
                    <div class="form-group">
                        <label class="control-label col-sm-2">Location:</label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control" name="location" value="<?php echo htmlspecialchars($doctor['location']); ?>" required>
                        </div>
                    </div>

                    

                    <!-- Schedule -->
                    <div class="form-group">
                        <label class="control-label col-sm-2">Schedule:</label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control" name="schedule" value="<?php echo htmlspecialchars($doctor['schedule']); ?>" required>
                        </div>
                    </div>

                    <!-- Description -->
                    <div class="form-group">
                        <label class="control-label col-sm-2">Description:</label>
                        <div class="col-sm-10">
                            <textarea class="form-control" name="description" rows="3" required><?php echo htmlspecialchars($doctor['description']); ?></textarea>
                        </div>
                    </div>

                    <!-- Sex -->
                    <div class="form-group">
                        <label class="control-label col-sm-2">Sex:</label>
                        <div class="col-sm-10">
                            <select class="form-control" name="sex" required>
                                <option value="male" <?php echo $doctor['sex'] == 'male' ? 'selected' : ''; ?>>Male</option>
                                <option value="female" <?php echo $doctor['sex'] == 'female' ? 'selected' : ''; ?>>Female</option>
                            </select>
                        </div>
                    </div>

                    <!-- Address -->
                    <div class="form-group">
                        <label class="control-label col-sm-2">Address:</label>
                        <div class="col-sm-10">
                            <textarea class="form-control" name="address" rows="3" required><?php echo htmlspecialchars($doctor['address']); ?></textarea>
                        </div>
                    </div>

                    <!-- Fee -->
                    <div class="form-group">
                        <label class="control-label col-sm-2">Fee:</label>
                        <div class="col-sm-10">
                            <input type="number" class="form-control" name="amount_due" value="<?php echo htmlspecialchars($doctor['amount_due']); ?>" required>
                        </div>
                    </div>

                    <!-- Submit Button -->
                    <div class="form-group">
                        <div class="col-sm-offset-2 col-sm-10">
                            <button type="submit" class="btn btn-primary">Update Profile</button>
                            <button type="button" class="btn btn-default" onclick="window.location.href='manage_doctor.php'">Cancel</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<?php
include("footer.php");
?>
