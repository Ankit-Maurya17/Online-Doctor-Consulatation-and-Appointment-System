<?php
include("header.php");
?>
<div class="row">
    <div class="col-md-12">
        <h2 style="color:black;">Patients List</h2>
        <hr>
    </div>
</div>

<div class="row">
    <div class="col-md-12">
        <div class="panel panel-primary">
            <div class="panel-heading">
                <h3 class="panel-title">All Patients</h3>
            </div>
            <div class="panel-body">
                <div class="table-responsive">
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th>Patient Name</th>
                                <th>Contact No</th>
                                <th>Address</th>
                                <th>Doctor Name</th>
                                <th>Doctor Fee</th>
                                <th>Appointment Date</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <!-- Sample data - replace with actual database query -->
                            <?php
                            // Sample data - replace with actual database query
                            $patients = array(
                                array(
                                    'id' => 1,
                                    'name' => 'John Doe',
                                    'contact' => '+91 1234567890',
                                    'address' => '123 Main Street, Prayagraj',
                                    'doctor' => 'Dr. Smith',
                                    'fee' => '1000',
                                    'status' => 'Paid',
                                    'appointment_date' => '2025-03-28'
                                ),
                                array(
                                    'id' => 2,
                                    'name' => 'Jane Smith',
                                    'contact' => '+91 9876543210',
                                    'address' => '456 Park Avenue, Prayagraj',
                                    'doctor' => 'Dr. Johnson',
                                    'fee' => '500',
                                    'status' => 'Unpaid',
                                    'appointment_date' => '2025-03-29'
                                ),
                                array(
                                    'id' => 3,
                                    'name' => 'Mike Brown',
                                    'contact' => '+91 1122334455',
                                    'address' => '789 Lake Road, Prayagraj',
                                    'doctor' => 'Dr. Williams',
                                    'fee' => '1500',
                                    'status' => 'Paid',
                                    'appointment_date' => '2025-03-30'
                                )
                            );

                            foreach($patients as $patient) {
                                echo "<tr>";
                                echo "<td>" . $patient['name'] . "</td>";
                                echo "<td>" . $patient['contact'] . "</td>";
                                echo "<td>" . $patient['address'] . "</td>";
                                echo "<td>" . $patient['doctor'] . "</td>";
                                echo "<td>";
                                if($patient['status'] == 'Paid') {
                                    echo "<span class='label label-success'>₹" . $patient['fee'] . " (Paid)</span>";
                                } else {
                                    echo "<span class='label label-warning'>₹" . $patient['fee'] . " (Unpaid)</span>";
                                }
                                echo "</td>";
                                echo "<td>" . $patient['appointment_date'] . "</td>";
                                echo "<td>";
                                echo "<button class='btn btn-info btn-sm' data-toggle='modal' data-target='#viewDetailsModal' 
                                        data-patient-id='" . $patient['id'] . "'
                                        data-patient-name='" . $patient['name'] . "'
                                        data-patient-contact='" . $patient['contact'] . "'
                                        data-patient-address='" . $patient['address'] . "'
                                        data-doctor-name='" . $patient['doctor'] . "'
                                        data-doctor-fee='" . $patient['fee'] . "'
                                        data-status='" . $patient['status'] . "'
                                        data-appointment-date='" . $patient['appointment_date'] . "'>
                                    View Details
                                </button>";
                                echo "<button class='btn btn-warning btn-sm' data-toggle='modal' data-target='#editPatientModal' 
                                        data-patient-id='" . $patient['id'] . "'
                                        data-patient-name='" . $patient['name'] . "'
                                        data-patient-contact='" . $patient['contact'] . "'
                                        data-patient-address='" . $patient['address'] . "'
                                        data-doctor-name='" . $patient['doctor'] . "'
                                        data-doctor-fee='" . $patient['fee'] . "'
                                        data-status='" . $patient['status'] . "'
                                        data-appointment-date='" . $patient['appointment_date'] . "'>
                                    Edit
                                </button>";
                                echo "<button class='btn btn-danger btn-sm' onclick=\"deletePatient('" . $patient['id'] . "')\">
                                    Delete
                                </button>";
                                echo "</td>";
                                echo "</tr>";
                            }
                            ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- View Details Modal -->
<div class="modal fade" id="viewDetailsModal" role="dialog">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h4 class="modal-title">Patient Details</h4>
            </div>
            <div class="modal-body">
                <div class="row">
                    <div class="col-md-6">
                        <strong>Patient Name:</strong> <span id="patientName"></span><br>
                        <strong>Contact No:</strong> <span id="patientContact"></span><br>
                        <strong>Address:</strong> <span id="patientAddress"></span><br>
                        <strong>Doctor Name:</strong> <span id="doctorName"></span><br>
                        <strong>Doctor Fee:</strong> <span id="doctorFee"></span><br>
                        <strong>Appointment Date:</strong> <span id="appointmentDate"></span><br>
                    </div>
                    <div class="col-md-6">
                        <strong>Payment Status:</strong> <span id="paymentStatus"></span><br>
                        <!-- Add any additional patient information here -->
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>

<!-- Edit Patient Modal -->
<div class="modal fade" id="editPatientModal" role="dialog">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h4 class="modal-title">Edit Patient Details</h4>
            </div>
            <div class="modal-body">
                <form action="process_edit_patient.php" method="POST" class="form-horizontal">
                    <input type="hidden" name="patient_id" id="editPatientId">
                    
                    <div class="form-group">
                        <label class="control-label col-sm-2">Patient Name:</label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control" name="patient_name" id="editPatientName" required>
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="control-label col-sm-2">Contact No:</label>
                        <div class="col-sm-10">
                            <input type="tel" class="form-control" name="patient_contact" id="editPatientContact" required>
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="control-label col-sm-2">Address:</label>
                        <div class="col-sm-10">
                            <textarea class="form-control" name="patient_address" id="editPatientAddress" rows="3" required></textarea>
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="control-label col-sm-2">Doctor Name:</label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control" name="doctor_name" id="editDoctorName" required>
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="control-label col-sm-2">Doctor Fee:</label>
                        <div class="col-sm-10">
                            <select class="form-control" name="doctor_fee" id="editDoctorFee" required>
                                <option value="500">₹500</option>
                                <option value="1000">₹1000</option>
                                <option value="1500">₹1500</option>
                                <option value="2000">₹2000</option>
                            </select>
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="control-label col-sm-2">Payment Status:</label>
                        <div class="col-sm-10">
                            <select class="form-control" name="payment_status" id="editPaymentStatus" required>
                                <option value="Paid">Paid</option>
                                <option value="Unpaid">Unpaid</option>
                            </select>
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="control-label col-sm-2">Appointment Date:</label>
                        <div class="col-sm-10">
                            <input type="date" class="form-control" name="appointment_date" id="editAppointmentDate" required>
                        </div>
                    </div>

                    <div class="modal-footer">
                        <button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-warning">Save Changes</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<script>
$(document).ready(function() {
    // View Details Modal
    $('#viewDetailsModal').on('show.bs.modal', function (event) {
        var button = $(event.relatedTarget);
        var name = button.data('patient-name');
        var contact = button.data('patient-contact');
        var address = button.data('patient-address');
        var doctor = button.data('doctor-name');
        var fee = button.data('doctor-fee');
        var status = button.data('status');
        var date = button.data('appointment-date');
        
        var modal = $(this);
        modal.find('#patientName').text(name);
        modal.find('#patientContact').text(contact);
        modal.find('#patientAddress').text(address);
        modal.find('#doctorName').text(doctor);
        modal.find('#doctorFee').text('₹' + fee);
        modal.find('#appointmentDate').text(date);
        modal.find('#paymentStatus').text(status);
    });

    // Edit Patient Modal
    $('#editPatientModal').on('show.bs.modal', function (event) {
        var button = $(event.relatedTarget);
        var id = button.data('patient-id');
        var name = button.data('patient-name');
        var contact = button.data('patient-contact');
        var address = button.data('patient-address');
        var doctor = button.data('doctor-name');
        var fee = button.data('doctor-fee');
        var status = button.data('status');
        var date = button.data('appointment-date');
        
        var modal = $(this);
        modal.find('#editPatientId').val(id);
        modal.find('#editPatientName').val(name);
        modal.find('#editPatientContact').val(contact);
        modal.find('#editPatientAddress').val(address);
        modal.find('#editDoctorName').val(doctor);
        modal.find('#editDoctorFee').val(fee);
        modal.find('#editPaymentStatus').val(status.toLowerCase());
        modal.find('#editAppointmentDate').val(date);
    });
});

function deletePatient(id) {
    if (confirm("Are you sure you want to delete this patient?")) {
        window.location.href = "process_delete_patient.php?id=" + id;
    }
}
</script>

<?php
include("footer.php");
?>
