<?php
session_start();

// Check if admin is not logged in
if (!isset($_SESSION['admin_user'])) {
    header("Location: login.php");
    exit();
}
?>
