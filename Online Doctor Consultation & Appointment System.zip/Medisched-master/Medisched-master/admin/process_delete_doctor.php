<?php
session_start();

// Check if doctor ID is provided
if (!isset($_GET['id'])) {
    header("Location: manage_doctor.php");
    exit();
}

$doctor_id = $_GET['id'];

try {
    // Connect to database
    $conn = new mysqli("localhost", "root", "", "medisched_db");
    
    if ($conn->connect_error) {
        throw new Exception("Connection failed: " . $conn->connect_error);
    }

    // Delete doctor
    $sql = "DELETE FROM doctors WHERE id = ?";
    $stmt = $conn->prepare($sql);
    
    if (!$stmt) {
        throw new Exception("Error preparing statement: " . $conn->error);
    }

    $stmt->bind_param("i", $doctor_id);
    
    if ($stmt->execute()) {
        header("Location: manage_doctor.php");
        exit();
    } else {
        throw new Exception("Error deleting doctor: " . $stmt->error);
    }
    
    $stmt->close();
    $conn->close();
} catch (Exception $e) {
    echo "<div class='alert alert-danger'>Error: " . $e->getMessage() . "</div>";
    exit();
}
?>
