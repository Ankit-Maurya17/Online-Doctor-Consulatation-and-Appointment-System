<?php 
session_start();
include('../includes/refresh_session.php');
include('header.php');

// Database connection
$conn = new mysqli("localhost", "root", "", "Medisched_db");

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Pagination settings
$items_per_page = 10;
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$offset = ($page - 1) * $items_per_page;

// Get appointments for this patient
$patient_email = $_SESSION['user'];

// First get patient ID
$sql = "SELECT id FROM patients WHERE email = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $patient_email);
$stmt->execute();
$result = $stmt->get_result();

if ($result && $result->num_rows > 0) {
    $patient = $result->fetch_assoc();
    $patient_id = $patient['id'];
} else {
    // Create new patient record if not found
    $sql = "INSERT INTO patients (email) VALUES (?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $patient_email);
    $stmt->execute();
    $patient_id = $conn->insert_id;
}

// Get total number of appointments
$sql = "SELECT COUNT(*) as total FROM appointments WHERE patient_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $patient_id);
$stmt->execute();
$result = $stmt->get_result();
$total_appointments = $result->fetch_assoc()['total'];
$stmt->close();

// Get appointments for current page
$sql = "SELECT DISTINCT
            p.name as patient_name,
            d.name as doctor_name,
            d.speciality,
            a.date_time,
            a.created_at,
            a.reason,
            a.status,
            a.payment_status,
            a.amount_due,
            a.id
        FROM appointments a 
        JOIN doctors d ON a.doctor_id = d.id 
        JOIN patients p ON a.patient_id = p.id 
        WHERE a.patient_id = ? 
        ORDER BY a.date_time DESC 
        LIMIT ? OFFSET ?";

$stmt = $conn->prepare($sql);
$stmt->bind_param("iii", $patient_id, $items_per_page, $offset);
$stmt->execute();
$result = $stmt->get_result();

// Calculate total pages
$total_pages = ceil($total_appointments / $items_per_page);

?>

<head>
    <link href="assets/css/font-awesome.css" rel="stylesheet" />
    <link href="assets/css/custom.css" rel="stylesheet" />
    <style>
        .status-pending { color: #f39c12; }
        .status-confirmed { color: #00a65a; }
        .status-cancelled { color: #dd4b39; }
        .booking-date {
            font-size: 0.9em;
            color: #666;
        }
        .table th {
            background-color: #f8f9fa;
            font-weight: bold;
        }
        .table td {
            vertical-align: middle;
        }
        .pagination {
            margin-top: 20px;
        }
        .pagination li a {
            color: #333;
            padding: 6px 12px;
        }
        .pagination li.active a {
            background-color: #a01f62;
            color: white;
            border-color: #a01f62;
        }
        .pagination li.active a:hover {
            background-color: #8c1a50;
            border-color: #8c1a50;
        }
    </style>
</head>

<div class="container">
    <div class="row">
        <div class="col-md-12">
            <h2 style="color:black">My Appointments</h2>
            <div class="text-right mb-3">
                <button type="button" class="btn btn-primary active" style="background-color:#a01f62;color:white;" id="booking-btn" onclick="window.location.href='new_booking.php'">
                    <i class="fas fa-calendar-plus"></i> Book New Appointment
                </button>
            </div>
            <hr>
        </div>
    </div>

    <div class="row">
        <div class="col-md-12">
            <div class="panel panel-default">
                <div class="panel-heading" style="background-color:#a01f62;color:white;">
                    Appointment History
                </div>
                <div class="panel-body">
                    <div class="table-responsive">
                        <table id="appointmentTable" class="table table-striped table-bordered">
                            <thead>
                                <tr>
                                    <th>Patient Name</th>
                                    <th>Doctor Name</th>
                                    <th>Specialization</th>
                                    <th>Appointment Date</th>
                                    <th>Time Slot</th>
                                    <th>Amount Due</th>
                                    <th>Payment Status</th>
                                    <th>Appointment Status</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                if ($result && $result->num_rows > 0) {
                                    while ($row = $result->fetch_assoc()) {
                                        // Format dates and times
                                        $appointment_date = date('d/m/Y', strtotime($row['date_time']));
                                        $appointment_time = date('h:i A', strtotime($row['date_time']));
                                        $booking_date = date('d/m/Y', strtotime($row['created_at']));

                                        // Format amount
                                        $amount_due = number_format($row['amount_due'], 2);

                                        // Determine status classes and icons
                                        $status_class = '';
                                        $status_icon = '';
                                        $payment_status_class = '';
                                        $payment_status_icon = '';

                                        // Appointment status
                                        switch(strtolower($row['status'])) {
                                            case 'pending':
                                                $status_class = 'text-warning';
                                                $status_icon = 'fa-clock';
                                                break;
                                            case 'confirmed':
                                                $status_class = 'text-success';
                                                $status_icon = 'fa-check-circle';
                                                break;
                                            case 'cancelled':
                                                $status_class = 'text-danger';
                                                $status_icon = 'fa-times-circle';
                                                break;
                                        }

                                        // Payment status
                                        switch(strtolower($row['payment_status'])) {
                                            case 'pending':
                                                $payment_status_class = 'text-warning';
                                                $payment_status_icon = 'fa-clock';
                                                break;
                                            case 'paid':
                                                $payment_status_class = 'text-success';
                                                $payment_status_icon = 'fa-check-circle';
                                                break;
                                            case 'failed':
                                                $payment_status_class = 'text-danger';
                                                $payment_status_icon = 'fa-times-circle';
                                                break;
                                        }

                                        echo "<tr>
                                            <td>" . htmlspecialchars($row['patient_name']) . "</td>
                                            <td>Dr. " . htmlspecialchars($row['doctor_name']) . "</td>
                                            <td>" . htmlspecialchars($row['speciality']) . "</td>
                                            <td>" . $appointment_date . "</td>
                                            <td>" . $appointment_time . "</td>
                                            <td>₹" . $amount_due . "</td>
                                            <td class='" . $payment_status_class . "'>
                                                <i class='fas " . $payment_status_icon . "'></i> 
                                                " . ucfirst($row['payment_status']) . "
                                            </td>
                                            <td class='" . $status_class . "'>
                                                <i class='fas " . $status_icon . "'></i> 
                                                " . ucfirst($row['status']) . "
                                            </td>
                                            <td>
                                                <button type='button' class='btn btn-sm btn-primary' 
                                                        data-bs-toggle='modal' 
                                                        data-bs-target='#detailsModal'
                                                        data-appointment-id='" . $row['id'] . "'
                                                        data-patient-name='" . htmlspecialchars($row['patient_name']) . "'
                                                        data-doctor-name='" . htmlspecialchars($row['doctor_name']) . "'
                                                        data-speciality='" . htmlspecialchars($row['speciality']) . "'
                                                        data-appointment-date='" . $appointment_date . "'
                                                        data-appointment-time='" . $appointment_time . "'
                                                        data-booking-date='" . $booking_date . "'
                                                        data-reason='" . htmlspecialchars($row['reason']) . "'
                                                        data-payment-status='" . ucfirst($row['payment_status']) . "'
                                                        data-amount='" . $amount_due . "'
                                                        data-status='" . ucfirst($row['status']) . "'>
                                                    <i class='fas fa-info-circle'></i> Details
                                                </button>
                                            </td>
                                        </tr>";
                                    }
                                } else {
                                    echo "<tr><td colspan='9' class='text-center'>No appointments found</td></tr>";
                                }
                                ?>
                            </tbody>
                        </table>

                        <!-- Pagination -->
                        <?php if ($total_pages > 1): ?>
                        <div class="text-center mt-3">
                            <ul class="pagination">
                                <?php for ($i = 1; $i <= $total_pages; $i++): ?>
                                    <li class="<?php echo $i == $page ? 'active' : ''; ?>">
                                        <a href="?page=<?php echo $i; ?>"><?php echo $i; ?></a>
                                    </li>
                                <?php endfor; ?>
                            </ul>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Appointment Details Modal -->
<div class="modal fade" id="detailsModal" tabindex="-1" role="dialog" aria-labelledby="detailsModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="detailsModalLabel">Appointment Details</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div id="appointmentDetails">
                    <!-- Details will be loaded here -->
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>

<!-- Include jQuery before Bootstrap JS -->
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/js/all.min.js"></script>
<script src="https://cdn.datatables.net/1.10.24/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.10.24/js/dataTables.bootstrap4.min.js"></script>
<script>
    $(document).ready(function() {
        // Initialize DataTable
        $('#appointmentTable').DataTable({
            "paging": true,
            "lengthChange": true,
            "searching": true,
            "ordering": true,
            "info": true,
            "autoWidth": false,
            "responsive": true,
            "pageLength": 10,
            "order": [[3, "desc"]], // Order by appointment date
            "language": {
                "info": "Showing _START_ to _END_ of _TOTAL_ entries",
                "infoEmpty": "Showing 0 to 0 of 0 entries",
                "infoFiltered": "(filtered from _MAX_ total entries)"
            },
            "columnDefs": [
                {
                    "targets": [0, 1, 2, 4, 5, 6, 7],
                    "className": "text-center"
                },
                {
                    "targets": [3], // Appointment Date
                    "className": "text-center"
                },
                {
                    "targets": [8], // Actions
                    "className": "text-center"
                }
            ]
        });

        // Details modal button click
        $('#appointmentTable').on('click', 'button[data-bs-target="#detailsModal"]', function() {
            const details = document.getElementById('appointmentDetails');

            // Show loading state
            details.innerHTML = '<div class="text-center"><i class="fas fa-spinner fa-spin"></i> Loading details...</div>';

            // Load details from data attributes
            const data = {
                patient_name: $(this).data('patient-name'),
                doctor_name: $(this).data('doctor-name'),
                speciality: $(this).data('speciality'),
                appointment_date: $(this).data('appointment-date'),
                appointment_time: $(this).data('appointment-time'),
                booking_date: $(this).data('booking-date'),
                reason: $(this).data('reason'),
                payment_status: $(this).data('payment-status'),
                amount: $(this).data('amount'),
                status: $(this).data('status')
            };

            // Update modal content
            details.innerHTML = `
                <div class="row">
                    <div class="col-md-6">
                        <p><strong>Patient Name:</strong> ${data.patient_name}</p>
                        <p><strong>Doctor Name:</strong> Dr. ${data.doctor_name}</p>
                        <p><strong>Specialization:</strong> ${data.speciality}</p>
                        <p><strong>Appointment Date:</strong> ${data.appointment_date}</p>
                        <p><strong>Time Slot:</strong> ${data.appointment_time}</p>
                    </div>
                    <div class="col-md-6">
                        <p><strong>Booking Date:</strong> ${data.booking_date}</p>
                        <p><strong>Reason:</strong> ${data.reason}</p>
                        <p><strong>Payment Status:</strong> ${data.payment_status}</p>
                        <p><strong>Amount:</strong> ₹${data.amount}</p>
                        <p><strong>Status:</strong> ${data.status}</p>
                    </div>
                </div>
            `;
        });

        // Book Appointment button click
        $('#booking-btn').click(function() {
            // Show loading state
            $(this).prop('disabled', true);
            $(this).html('<i class="fas fa-spinner fa-spin"></i> Booking...');

            // Redirect to new booking page after a short delay
            setTimeout(function() {
                window.location.href = 'new_booking.php';
            }, 1000);
        });
    });
</script>

<?php include('footer.php'); ?>

<?php
if(isset($_POST['delete_id'])){ 
    $id = $_POST['delete_id'];
    $sql = "DELETE FROM appointments WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $stmt->close();
    header("Location: index.php");
    exit();
}

$conn->close();
?>