<?php 
session_start();
include('../includes/refresh_session.php');

// Database connection
$conn = new mysqli("localhost", "root", "", "Medisched_db");

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get available doctors with proper error handling
$doctors = [];
$doctors_sql = "SELECT id, name, speciality as specialty_name 
               FROM doctors 
               ORDER BY speciality, name";
$result = $conn->query($doctors_sql);

if($result && $result->num_rows > 0) {
    while($doctor = $result->fetch_assoc()) {
        $doctors[] = $doctor;
    }
}

// Get patient details with proper error handling
$patient = null;
if(isset($_SESSION['user'])) {
    $patient_email = $_SESSION['user'];
    $sql = "SELECT * FROM patients WHERE email = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $patient_email);
    $stmt->execute();
    $result = $stmt->get_result();
    if($result->num_rows > 0) {
        $patient = $result->fetch_assoc();
    }
    $stmt->close();
}

// Process booking
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Patient information
    $patient_name = $_POST['patient_name'] ?? '';
    $patient_age = $_POST['patient_age'] ?? '';
    $patient_gender = $_POST['patient_gender'] ?? '';
    $patient_contact = $_POST['patient_contact'] ?? '';
    $patient_email = $_POST['patient_email'] ?? '';
    
    // Appointment details
    $date = $_POST['date'] ?? '';
    $time = $_POST['time'] ?? '';
    $doctor_id = $_POST['doctor_id'] ?? '';
    $reason = $_POST['reason'] ?? '';
    $amount_due = $_POST['amount_due'] ?? 0;
    $medical_records = $_FILES['medical_records'] ?? null;

    // First check if patient exists
    $patient_id = null;
    $check_patient_sql = "SELECT id FROM patients WHERE email = ?";
    $stmt = $conn->prepare($check_patient_sql);
    $stmt->bind_param("s", $patient_email);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if($result->num_rows > 0) {
        $patient = $result->fetch_assoc();
        $patient_id = $patient['id'];
    } else {
        // Create new patient record
        $insert_patient_sql = "INSERT INTO patients (name, phone, email) VALUES (?, ?, ?)";
        $stmt = $conn->prepare($insert_patient_sql);
        $stmt->bind_param("sss", 
            $patient_name,
            $patient_contact,
            $patient_email
        );
        
        if($stmt->execute()) {
            $patient_id = $conn->insert_id;
        } else {
            $error = "Error creating patient record: " . $conn->error;
            $stmt->close();
            return;
        }
        $stmt->close();
    }

    // Continue with appointment booking
    if($patient_id) {
        $sql = "INSERT INTO appointments (patient_id, doctor_id, date_time, reason, status, payment_status, amount_due) 
                VALUES (?, ?, ?, ?, ?, ?, ?)";
        
        $stmt = $conn->prepare($sql);
        $appointment_datetime = $date . ' ' . $time;
        $status = 'Pending';
        $payment_status = 'Pending';
        $stmt->bind_param("iissssd", 
            $patient_id,
            $doctor_id,
            $appointment_datetime,
            $reason,
            $status,
            $payment_status,
            $amount_due
        );
        
        if($stmt->execute()) {
            // Handle medical records upload if provided
            if($medical_records && $medical_records['error'] == 0) {
                $appointment_id = $conn->insert_id;
                $upload_dir = "../uploads/medical_records/";
                if(!file_exists($upload_dir)) {
                    mkdir($upload_dir, 0777, true);
                }
                $file_name = "appointment_" . $appointment_id . "_" . basename($medical_records['name']);
                move_uploaded_file($medical_records['tmp_name'], $upload_dir . $file_name);
            }
            
            // Set success message
            $_SESSION['success_message'] = "Appointment Booked Successfully";
            
            header("Location: appointment_history.php");
            exit();
        } else {
            $error = "Error booking appointment: " . $conn->error;
        }
        $stmt->close();
    } else {
        $error = "Could not create patient record";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Book New Appointment - Medisched</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        .booking-form {
            max-width: 1000px;
            margin: 2rem auto;
            padding: 2rem;
            background: white;
            border-radius: 10px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        .form-label {
            font-weight: 500;
        }
        .time-slot {
            padding: 0.5rem;
            margin-bottom: 0.5rem;
            border: 1px solid #dee2e6;
            border-radius: 4px;
            cursor: pointer;
        }
        .time-slot:hover {
            background-color: #f8f9fa;
        }
        .time-slot.selected {
            background-color: #e3f2fd;
            border-color: #0d6efd;
        }
        .card {
            margin-bottom: 1.5rem;
            border: 1px solid #dee2e6;
        }
        .card-header {
            background-color: #f8f9fa;
            padding: 1rem;
        }
        .form-control:focus {
            border-color: #a01f62;
            box-shadow: 0 0 0 0.2rem rgba(160, 31, 98, 0.25);
        }
        .btn-primary {
            background-color: #a01f62;
            border-color: #a01f62;
        }
        .btn-primary:hover {
            background-color: #8c1a50;
            border-color: #8c1a50;
        }
        .alert {
            margin-top: 1rem;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-12">
                <div class="booking-form">
                    <?php if(isset($error)): ?>
                        <div class="alert alert-danger"><?php echo $error; ?></div>
                    <?php endif; ?>
                    
                    <?php if(isset($success)): ?>
                        <div class="alert alert-success"><?php echo $success; ?></div>
                    <?php endif; ?>
                    
                    <form method="POST" action="" enctype="multipart/form-data">
                        <!-- Patient Information Section -->
                        <div class="card mb-4">
                            <div class="card-header">
                                <h5 class="mb-0">Patient Information</h5>
                            </div>
                            <div class="card-body">
                                <div class="row">
                                    <div class="col-md-6 mb-3">
                                        <label for="name" class="form-label">Name</label>
                                        <input type="text" class="form-control" id="name" name="patient_name" value="<?php echo isset($patient) ? htmlspecialchars($patient['name']) : ''; ?>" required>
                                    </div>
                                    <div class="col-md-6 mb-3">
                                        <label for="age" class="form-label">Age</label>
                                        <input type="number" class="form-control" id="age" name="patient_age" 

                                               min="1" max="80" required>
                                        <div class="form-text text-muted">Age must be between 1 and 80 years</div>
                                    </div>
                                    <div class="col-md-6 mb-3">
                                        <label for="gender" class="form-label">Gender</label>
                                        <select class="form-select" id="gender" name="patient_gender" required>
                                            <option value="">Select Gender</option>
                                            <option value="Male" <?php echo (isset($patient['gender']) && $patient['gender'] == 'Male') ? 'selected' : ''; ?>>Male</option>
                                            <option value="Female" <?php echo (isset($patient['gender']) && $patient['gender'] == 'Female') ? 'selected' : ''; ?>>Female</option>
                                        </select>
                                    </div>
                                    <div class="col-md-6 mb-3">
                                        <label for="contact" class="form-label">Contact Number</label>
                                        <input type="tel" class="form-control" id="contact" name="patient_contact" value="<?php echo isset($patient) ? htmlspecialchars($patient['phone']) : ''; ?>" required pattern="[0-9]{10}" placeholder="10-digit phone number">
                                        <div class="form-text">Please enter a 10-digit phone number</div>
                                        
                                    </div>
                                    <div class="col-md-6 mb-3">
                                        <label for="email" class="form-label">Email</label>
                                        <input type="email" class="form-control" id="email" name="patient_email" value="<?php echo isset($patient) ? htmlspecialchars($patient['email']) : ''; ?>" required>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Appointment Details Section -->
                        <div class="card mb-4">
                            <div class="card-header">
                                <h5 class="mb-0">Appointment Details</h5>
                            </div>
                            <div class="card-body">
                                <div class="row">
                                    <div class="col-md-6 mb-3">
                                        <label for="doctor" class="form-label">Select Doctor</label>
                                        <select class="form-select" id="doctor" name="doctor_id" required>
                                            <option value="">Select Doctor</option>
                                            <?php foreach ($doctors as $doctor): ?>
                                                <option value="<?php echo $doctor['id']; ?>" <?php echo isset($_POST['doctor_id']) && $_POST['doctor_id'] == $doctor['id'] ? 'selected' : ''; ?>>
                                                    <?php echo htmlspecialchars($doctor['name']); ?> - <?php echo htmlspecialchars($doctor['specialty_name']); ?>
                                                </option>
                                            <?php endforeach; ?>
                                        </select>
                                    </div>
                                    <div class="col-md-6 mb-3">
                                        <label for="date" class="form-label">Appointment Date</label>
                                        <input type="date" class="form-control" id="date" name="date" required min="<?php echo date('Y-m-d'); ?>">
                                        
                                    </div>
                                    <div class="col-md-6 mb-3">
                                        <label for="time" class="form-label">Appointment Time</label>
                                        <select class="form-select" id="time" name="time" required>
                                             <option value="">Select Time Slot</option>
                                             <optgroup label="Morning Session (9 AM - 12:30 PM)">
                                                 <option value="09:00:00">09:00 AM</option>
                                                 <option value="09:30:00">09:30 AM</option>
                                                 <option value="10:00:00">10:00 AM</option>
                                                 <option value="10:30:00">10:30 AM</option>
                                                 <option value="11:00:00">11:00 AM</option>
                                                 <option value="11:30:00">11:30 AM</option>
                                                 <option value="12:00:00">12:00 PM</option>
                                                 <option value="12:30:00">12:30 PM</option>
                                             </optgroup>
                                             <optgroup label="Afternoon Session (2 PM - 5 PM)">
                                                 <option value="14:00:00">02:00 PM</option>
                                                 <option value="14:30:00">02:30 PM</option>
                                                 <option value="15:00:00">03:00 PM</option>
                                                 <option value="15:30:00">03:30 PM</option>
                                                 <option value="16:00:00">04:00 PM</option>
                                                 <option value="16:30:00">04:30 PM</option>
                                                 <option value="17:00:00">05:00 PM</option>
                                                 <option value="17:30:00">05:30 PM</option>
                                             </optgroup>
                                         </select>
                                     </div>
                                    <div class="col-md-12 mb-3">
                                        <label for="reason" class="form-label">Reason for Appointment</label>
                                        <textarea class="form-control" id="reason" name="reason" rows="3" required></textarea>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Payment Details Section -->
                        <div class="card mb-4">
                            <div class="card-header">
                                <h5 class="mb-0">Payment Details</h5>
                            </div>
                            <div class="card-body">
                                <div class="row">
                                    <div class="col-md-6 mb-3">
                                        <label for="amount" class="form-label">Amount Due</label>
                                        <select class="form-select" id="amount" name="amount_due" required>
                                            <option value="">Select Amount</option>
                                            <option value="500">₹500 - General Consultation</option>
                                            <option value="1000">₹1000 - Specialist Consultation</option>
                                            <option value="1500">₹1500 - Advanced Consultation</option>
                                            <option value="2000">₹2000 - Expert Consultation</option>
                                        </select>
                                    </div>
                                    <div class="col-md-6 mb-3">
                                        <label for="payment_method" class="form-label">Payment Method</label>
                                        <select class="form-select" id="payment_method" name="payment_method" required>
                                            <option value="">Select Payment Method</option>
                                            <option value="UPI">UPI</option>
                                            <option value="Card">Card</option>
                                            <option value="Cash">Cash</option>
                                            <option value="Other">Other</option>
                                        </select>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Additional Options Section -->
                        <div class="card mb-4">
                            <div class="card-header">
                                <h5 class="mb-0">Additional Options</h5>
                            </div>
                            <div class="card-body">
                                <div class="row">
                                    <div class="col-md-6 mb-3">
                                        <label for="medical_records" class="form-label">Upload Medical Records</label>
                                        <input type="file" class="form-control" id="medical_records" name="medical_records" accept=".pdf,.jpg,.jpeg,.png">
                                        <small class="text-muted">Supported formats: PDF, JPG, JPEG, PNG (Max size: 5MB)</small>
                                    </div>
                                    <div class="col-md-6 mb-3">
                                        <label for="reminder_time" class="form-label">Previous Appointment Details</label>
                                        <select class="form-select" id="reminder_time" name="reminder_time">
                                            <option value="">Previous Appointment</option>
                                            <option value="1">1 Day Before</option>
                                            <option value="2">2 Days Before</option>
                                            <option value="3">3 Days Before</option>
                                            <option value="7">1 Week Before</option>
                                        </select>
                                    </div>
                                    <div class="col-md-12 mb-3">
                                        <div class="form-check">
                                            <input class="form-check-input" type="checkbox" id="terms" name="terms" required>
                                            <label class="form-check-label" for="terms">
                                                I agree to the terms and conditions
                                            </label>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="text-center mt-4">
                            <button type="submit" class="btn btn-primary btn-lg">Book Appointment</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Add validation for medical records file size
        document.getElementById('medical_records').addEventListener('change', function() {
            const file = this.files[0];
            if(file && file.size > 5 * 1024 * 1024) { // 5MB
                alert('File size exceeds 5MB limit');
                this.value = '';
            }
        });

        // Add age validation
        document.getElementById('age').addEventListener('input', function() {
            const age = parseInt(this.value);
            if (isNaN(age) || age < 1 || age > 80) {
                this.setCustomValidity('Please enter a valid age between 1 and 80');
            } else {
                this.setCustomValidity('');
            }
        });

        // Show success message with a delay
        document.addEventListener('DOMContentLoaded', function() {
            const successMessage = document.querySelector('.alert-success');
            if(successMessage) {
                setTimeout(() => {
                    successMessage.style.display = 'none';
                }, 5000); // Hide after 5 seconds
            }
        });

        function formatDate(dateString) {
            const date = new Date(dateString);
            const day = date.getDate().toString().padStart(2, '0');
            const month = (date.getMonth() + 1).toString().padStart(2, '0');
            const year = date.getFullYear();
            return `${day}/${month}/${year}`;
        }
    </script>
</body>
</html>