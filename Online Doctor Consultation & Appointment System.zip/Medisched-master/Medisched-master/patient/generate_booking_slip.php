<?php
session_start();
include('../includes/refresh_session.php');

// Database connection
$conn = new mysqli("localhost", "root", "", "Medisched_db");

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "GET" && isset($_GET['appointment_id'])) {
    $appointment_id = $_GET['appointment_id'];
    
    // Get appointment details
    $sql = "SELECT 
            a.id as appointment_id,
            a.date_time,
            a.reason,
            a.amount_due,
            a.payment_status,
            a.payment_mode,
            p.name as patient_name,
            p.phone as patient_phone,
            p.email as patient_email,
            d.name as doctor_name,
            d.speciality as doctor_speciality
            FROM appointments a
            JOIN patients p ON a.patient_id = p.id
            JOIN doctors d ON a.doctor_id = d.id
            WHERE a.id = ?";
    
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $appointment_id);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if($result->num_rows > 0) {
        $appointment = $result->fetch_assoc();
        ?>
        <!DOCTYPE html>
        <html lang="en">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>Appointment Booking Slip</title>
            <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
            <style>
                body { font-family: Arial, sans-serif; }
                .header { text-align: center; margin-bottom: 30px; }
                .header h1 { color: #2c3e50; }
                .container { max-width: 800px; margin: 0 auto; }
                .appointment-details { margin: 20px 0; }
                .appointment-details h3 { color: #2c3e50; margin-bottom: 15px; }
                .details-table { width: 100%; border-collapse: collapse; margin: 15px 0; }
                .details-table th, .details-table td { padding: 10px; border: 1px solid #ddd; }
                .details-table th { background-color: #f8f9fa; }
                .payment-info { margin: 20px 0; padding: 20px; background-color: #f8f9fa; border-radius: 5px; }
                .footer { margin-top: 30px; text-align: center; color: #6c757d; }
                .barcode { margin-top: 20px; text-align: center; }
                .print-btn { margin-top: 20px; text-align: center; }
            </style>
        </head>
        <body>
            <div class="header">
                <h1>MediSched</h1>
                <h2>Appointment Booking Slip</h2>
            </div>
            
            <div class="container">
                <div class="appointment-details">
                    <h3>Appointment Details</h3>
                    <table class="details-table">
                        <tr>
                            <th>Patient Name</th>
                            <td><?php echo htmlspecialchars($appointment['patient_name']); ?></td>
                        </tr>
                        <tr>
                            <th>Contact Number</th>
                            <td><?php echo htmlspecialchars($appointment['patient_phone']); ?></td>
                        </tr>
                        <tr>
                            <th>Email</th>
                            <td><?php echo htmlspecialchars($appointment['patient_email']); ?></td>
                        </tr>
                        <tr>
                            <th>Doctor Name</th>
                            <td><?php echo htmlspecialchars($appointment['doctor_name']); ?></td>
                        </tr>
                        <tr>
                            <th>Speciality</th>
                            <td><?php echo htmlspecialchars($appointment['doctor_speciality']); ?></td>
                        </tr>
                        <tr>
                            <th>Appointment Date & Time</th>
                            <td><?php echo date('d/m/Y h:i A', strtotime($appointment['date_time'])); ?></td>
                        </tr>
                        <tr>
                            <th>Reason for Visit</th>
                            <td><?php echo htmlspecialchars($appointment['reason']); ?></td>
                        </tr>
                    </table>
                </div>
                
                <div class="payment-info">
                    <h3>Payment Information</h3>
                    <p><strong>Amount Due:</strong> ₹<?php echo number_format($appointment['amount_due'], 2); ?></p>
                    <p><strong>Payment Mode:</strong> <?php echo ucfirst($appointment['payment_mode']); ?></p>
                    <p><strong>Payment Status:</strong> <?php echo ucfirst($appointment['payment_status']); ?></p>
                </div>
                
                <div class="barcode">
                    <img src='https://api.qrserver.com/v1/create-qr-code/?size=150x150&data=Appointment ID: <?php echo $appointment['appointment_id']; ?>' alt='QR Code'>
                </div>
                
                <div class="footer">
                    <p>Thank you for choosing MediSched. Please bring this slip to your appointment.</p>
                    <p>For any queries, contact us at: support@medisched.com</p>
                </div>
                
                <div class="print-btn">
                    <button onclick="window.print()" class="btn btn-primary">
                        <i class="fas fa-print"></i> Print Slip
                    </button>
                </div>
            </div>

            <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
            <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/js/all.min.js"></script>
        </body>
        </html>
        <?php
    } else {
        $_SESSION['error'] = "Appointment not found";
        header("Location: appointment_history.php");
        exit();
    }
}
?>
