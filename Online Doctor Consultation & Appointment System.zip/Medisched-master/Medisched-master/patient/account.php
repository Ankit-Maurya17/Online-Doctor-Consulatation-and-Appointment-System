<?php
include("header.php");
session_start();
$conn = new mysqli("localhost", "root", "", "MediSched");
$error = '';
$success = '';

if(isset($_POST['SubmitButton'])) {
    $current_password = $_POST['current_password'];
    $new_password = $_POST['new_password'];
    $confirm_password = $_POST['confirm_password'];
    $sid = $_SESSION['user'];

    // First verify current password
    $sql = "SELECT pass FROM patients WHERE email='$sid'";
    $result = mysqli_query($conn, $sql);
    $row = mysqli_fetch_assoc($result);

    if($row['pass'] == $current_password) {
        if($new_password == $confirm_password) {
            $sql = "UPDATE patients SET pass='$new_password' WHERE email='$sid'";
            if(mysqli_query($conn, $sql)) {
                $success = 'Password updated successfully!';
            } else {
                $error = 'Error updating password. Please try again.';
            }
        } else {
            $error = 'New password and confirm password do not match!';
        }
    } else {
        $error = 'Current password is incorrect!';
    }
    mysqli_close($conn);
}
?>
                
                 <!-- /. ROW  -->
               <div class="row">
                <div class="col-md-12">
                    <!-- Form Elements -->
					<h3>Change My Password </h3>
                    <div class="panel panel-default" style="padding:50px;background-color:transparent;">
                        
                        <div class="panel-body">
                            <div class="row">
                                <div class="col-md-6">
                                    <?php if($error != ''): ?>
                                        <div class="alert alert-danger"><?php echo $error; ?></div>
                                    <?php endif; ?>
                                    <?php if($success != ''): ?>
                                        <div class="alert alert-success"><?php echo $success; ?></div>
                                    <?php endif; ?>
                                    <form role="form" method="post" action="account.php">
                                        <div class="form-group">
                                            <label>Current Password</label>
                                            <input type="password" name="current_password" required class="form-control" placeholder="Enter current password" />
                                        </div>
                                        <div class="form-group">
                                            <label>New Password</label>
                                            <input type="password" name="new_password" required class="form-control" placeholder="Enter new password" />
                                        </div>
                                        <div class="form-group">
                                            <label>Confirm New Password</label>
                                            <input type="password" name="confirm_password" required class="form-control" placeholder="Confirm new password" />
                                        </div>
                                        <button type="submit" class="btn" name="SubmitButton" style="background-color:#a01f62;color:white;">Change Password</button>
 
								</div>
                                    </form>
                                
							</div>
						</div>
                     <!-- End Form Elements -->
                </div>
            </div>
               
    </div>
           <?php
include("footer.php");
?>