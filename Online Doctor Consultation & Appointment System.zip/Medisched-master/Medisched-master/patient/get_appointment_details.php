<?php
session_start();
include('../includes/refresh_session.php');

// Database connection
$conn = new mysqli("localhost", "root", "", "Medisched_db");

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if (isset($_GET['id'])) {
    $appointment_id = $_GET['id'];
    
    $sql = "SELECT 
        p.name as patient_name,
        d.name as doctor_name,
        d.speciality,
        a.date_time,
        a.created_at,
        a.reason,
        a.status,
        a.payment_status,
        a.amount_due
    FROM appointments a 
    JOIN doctors d ON a.doctor_id = d.id 
    JOIN patients p ON a.patient_id = p.id 
    WHERE a.id = ?";

    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $appointment_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result && $result->num_rows > 0) {
        $row = $result->fetch_assoc();
        
        // Format dates
        $appointment_date = date('d/m/Y', strtotime($row['date_time']));
        $appointment_time = date('h:i A', strtotime($row['date_time']));
        $booking_date = date('d/m/Y h:i A', strtotime($row['created_at']));

        $response = [
            'patient_name' => htmlspecialchars($row['patient_name']),
            'doctor_name' => htmlspecialchars($row['doctor_name']),
            'speciality' => htmlspecialchars($row['speciality']),
            'appointment_date' => $appointment_date,
            'appointment_time' => $appointment_time,
            'booking_date' => $booking_date,
            'reason' => htmlspecialchars($row['reason']),
            'status' => ucfirst($row['status']),
            'payment_status' => ucfirst($row['payment_status']),
            'amount' => number_format($row['amount_due'], 2)
        ];

        echo json_encode($response);
    } else {
        http_response_code(404);
        echo json_encode(['error' => 'Appointment not found']);
    }
    
    $stmt->close();
} else {
    http_response_code(400);
    echo json_encode(['error' => 'Invalid request']);
}

$conn->close();
?>
