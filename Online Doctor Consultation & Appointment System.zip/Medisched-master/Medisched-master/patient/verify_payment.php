<?php
session_start();
include('../includes/refresh_session.php');

// Database connection
$conn = new mysqli("localhost", "root", "", "Medisched_db");

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Verify payment with Razorpay
function verifyPayment($payment_id) {
    $razorpay_key = "rzp_test_YOUR_KEY_HERE"; // Replace with your Razorpay key
    $razorpay_secret = "YOUR_SECRET_HERE"; // Replace with your Razorpay secret

    // Get payment details from Razorpay
    $url = "https://api.razorpay.com/v1/payments/" . $payment_id;
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_USERPWD, $razorpay_key . ":" . $razorpay_secret);
    $response = curl_exec($ch);
    curl_close($ch);

    $payment_details = json_decode($response, true);

    // Verify payment status
    if ($payment_details['status'] === 'captured') {
        return true;
    }
    return false;
}

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['payment_id'])) {
    $payment_id = $_POST['payment_id'];
    
    if (verifyPayment($payment_id)) {
        // Update payment status in database
        $appointment_id = $_POST['appointment_id'];
        $sql = "UPDATE appointments SET payment_status = 'Completed' WHERE id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("i", $appointment_id);
        
        if ($stmt->execute()) {
            $_SESSION['success_message'] = "Payment verified successfully!";
        } else {
            $_SESSION['error'] = "Error updating payment status: " . $conn->error;
        }
        $stmt->close();
    } else {
        $_SESSION['error'] = "Payment verification failed!";
    }
    
    header("Location: appointment_history.php");
    exit();
}
?>
