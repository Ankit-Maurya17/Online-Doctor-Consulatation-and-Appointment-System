<?php
session_start();
include("../includes/refresh_session.php");

if(!isset($_SESSION['user'])){
    header("location:../index.php");
    exit();
}

// Refresh session data
refresh_session_data('patient');

// Database connection
$conn = new mysqli("localhost", "root", "", "MediSched");

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get all doctors
$sql = "SELECT * FROM doctors ORDER BY name ASC";
$result = $conn->query($sql);
$doctors = $result->fetch_all(MYSQLI_ASSOC);

// Handle booking submission
if(isset($_POST['book'])) {
    $doctor_id = $_POST['doctor'];
    $patient_id = $_SESSION['user'];
    $contact = $_POST['contact'];
    $problem = $_POST['problem'];
    $date = $_POST['date'];
    $time = $_POST['time'];
    $patient_name = $_POST['patient_name'];

    // Validate inputs
    $errors = [];
    
    // Validate patient name (letters and spaces only)
    if (!preg_match("/^[a-zA-Z ]+$/", $patient_name)) {
        $errors[] = "Patient name should contain only letters and spaces";
    }
    
    // Validate contact number (exactly 10 digits)
    if (!preg_match("/^[0-9]{10}$/", $contact)) {
        $errors[] = "Contact number must be exactly 10 digits";
    }
    
    if (empty($errors)) {
        // Check if the selected time slot is available
        $check_sql = "SELECT COUNT(*) as count FROM bookings WHERE doctor = ? AND date = ? AND time = ?";
        $stmt = $conn->prepare($check_sql);
        
        if ($stmt === false) {
            die("Error preparing statement: " . $conn->error);
        }
        
        $stmt->bind_param("iss", $doctor_id, $date, $time);
        $stmt->execute();
        $result = $stmt->get_result();
        $slot_taken = $result->fetch_assoc()['count'] > 0;
        $stmt->close();

        if($slot_taken) {
            $error = "This time slot is already booked. Please choose another time.";
        } else {
            // Insert booking
            $insert_sql = "INSERT INTO bookings (doctor, patient, contact, problem, date, time, user, patient_name) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
            $stmt = $conn->prepare($insert_sql);
            
            if ($stmt === false) {
                die("Error preparing statement: " . $conn->error);
            }
            
            $stmt->bind_param("iissssss", $doctor_id, $patient_id, $contact, $problem, $date, $time, $patient_id, $patient_name);
            
            if($stmt->execute()) {
                $appointment_id = $conn->insert_id;
                
                // Send notification to doctor
                $doctor_sql = "SELECT name FROM doctors WHERE id = ?";
                $doctor_stmt = $conn->prepare($doctor_sql);
                $doctor_stmt->bind_param("i", $doctor_id);
                $doctor_stmt->execute();
                $doctor_result = $doctor_stmt->get_result();
                $doctor = $doctor_result->fetch_assoc();
                $doctor_stmt->close();

                // Create notification message
                $message = "New appointment booked by " . htmlspecialchars($patient_name) . "\n" .
                          "Problem: " . htmlspecialchars($problem) . "\n" .
                          "Date: " . htmlspecialchars($date) . "\n" .
                          "Time: " . htmlspecialchars($time);

                // Insert notification
                $notification_sql = "INSERT INTO notifications (doctor_id, patient_email, appointment_id, message) VALUES (?, ?, ?, ?)";
                $notification_stmt = $conn->prepare($notification_sql);
                
                if ($notification_stmt === false) {
                    die("Error preparing notification statement: " . $conn->error);
                }

                $notification_stmt->bind_param("iiss", $doctor_id, $patient_id, $appointment_id, $message);
                
                if($notification_stmt->execute()) {
                    $success = "Appointment booked successfully! Doctor has been notified.";
                } else {
                    $error = "Error sending notification: " . $notification_stmt->error;
                }
                $notification_stmt->close();
            } else {
                $error = "Error booking appointment: " . $stmt->error;
            }
            $stmt->close();
        }
    } else {
        $error = implode("<br>", $errors);
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Book Appointment - Medisched</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        .booking-container {
            max-width: 800px;
            margin: 50px auto;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
        }
        .form-label {
            font-weight: 500;
        }
        .time-slot {
            margin: 5px 0;
            padding: 8px;
            border: 1px solid #ddd;
            border-radius: 4px;
            cursor: pointer;
            transition: background-color 0.3s;
        }
        .time-slot:hover {
            background-color: #f8f9fa;
        }
        .selected-time {
            background-color: #007bff;
            color: white;
        }
        .error-message {
            color: red;
            font-size: 0.875em;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="booking-container">
            <h2 class="text-center mb-4">Book New Appointment</h2>
            
            <?php if(isset($success)): ?>
                <div class="alert alert-success"><?php echo $success; ?></div>
            <?php endif; ?>
            
            <?php if(isset($error)): ?>
                <div class="alert alert-danger"><?php echo $error; ?></div>
            <?php endif; ?>

            <form method="POST" action="" class="needs-validation" novalidate>
                <div class="row">
                    <div class="col-md-6 mb-3">
                        <label for="patient_name" class="form-label">Patient Name*</label>
                        <input type="text" class="form-control" id="patient_name" name="patient_name" 
                               pattern="[a-zA-Z ]+" title="Only letters and spaces allowed" 
                               oninput="this.value = this.value.replace(/[^a-zA-Z ]/g, '')" required>
                        <div class="invalid-feedback">Please enter a valid name (letters only)</div>
                    </div>

                    <div class="col-md-6 mb-3">
                        <label for="doctor" class="form-label">Select Doctor*</label>
                        <select class="form-select" id="doctor" name="doctor" required>
                            <option value="">Select a doctor</option>
                            <?php foreach($doctors as $doctor): ?>
                                <option value="<?php echo $doctor['id']; ?>">
                                    <?php echo htmlspecialchars($doctor['name']); ?> - <?php echo htmlspecialchars($doctor['special']); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                        <div class="invalid-feedback">Please select a doctor</div>
                    </div>

                    <div class="col-md-6 mb-3">
                        <label for="contact" class="form-label">Contact Number*</label>
                        <input type="tel" class="form-control" id="contact" name="contact" 
                               pattern="[0-9]{10}" title="Exactly 10 digits required"
                               oninput="this.value = this.value.replace(/\D/g, '').slice(0, 10)" required>
                        <div class="invalid-feedback">Please enter a 10-digit contact number</div>
                    </div>

                    <div class="col-md-12 mb-3">
                        <label for="problem" class="form-label">Problem Description*</label>
                        <textarea class="form-control" id="problem" name="problem" rows="3" required></textarea>
                        <div class="invalid-feedback">Please describe your problem</div>
                    </div>

                    <div class="col-md-6 mb-3">
                        <label for="date" class="form-label">Select Date*</label>
                        <input type="date" class="form-control" id="date" name="date" min="<?php echo date('Y-m-d'); ?>" required>
                        <div class="invalid-feedback">Please select a valid date</div>
                        
                    </div>

                    <div class="col-md-6 mb-3">
                        <label for="time" class="form-label">Select Time*</label>
                        <select class="form-select" id="time" name="time" required>
                            <option value="">Select a time</option>
                            <option value="10:00">10:00 AM</option>
                            <option value="10:30">10:30 AM</option>
                            <option value="11:00">11:00 AM</option>
                            <option value="11:30">11:30 AM</option>
                            <option value="12:00">12:00 PM</option>
                            <option value="12:30">12:30 PM</option>
                            <option value="14:00">02:00 PM</option>
                            <option value="14:30">02:30 PM</option>
                            <option value="15:00">03:00 PM</option>
                            <option value="15:30">03:30 PM</option>
                            <option value="16:00">04:00 PM</option>
                            <option value="16:30">04:30 PM</option>
                        </select>
                        <div class="invalid-feedback">Please select a time</div>
                    </div>
                </div>

                <div class="text-center">
                    <button type="submit" name="book" class="btn btn-primary">Book Appointment</button>
                    <a href="index.php" class="btn btn-secondary">Cancel</a>
                </div>
            </form>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Form validation
        (function () {
            'use strict'
            
            var forms = document.querySelectorAll('.needs-validation')
            
            Array.prototype.slice.call(forms)
                .forEach(function (form) {
                    form.addEventListener('submit', function (event) {
                        if (!form.checkValidity()) {
                            event.preventDefault()
                            event.stopPropagation()
                        }
                        form.classList.add('was-validated')
                    }, false)
                })
        })()
    </script>
</body>
</html>