<?php
session_start();

// Check if user is logged in
if (!isset($_SESSION['user'])) {
    header('Location: ../login.php');
    exit();
}

// Database connection
$conn = new mysqli("localhost", "root", "", "Medisched_db");

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get patient ID from email
$patient_email = $_SESSION['user'];

// First check if email exists in patients table
$sql = "SELECT id FROM patients WHERE email = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $patient_email);
$stmt->execute();
$result = $stmt->get_result();

if ($result && $result->num_rows > 0) {
    $patient = $result->fetch_assoc();
    $patient_id = $patient['id'];
} else {
    // If not found, try to create a patient record
    $sql = "INSERT INTO patients (email) VALUES (?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $patient_email);
    
    if ($stmt->execute()) {
        $patient_id = $conn->insert_id;
    } else {
        die("Error creating patient record: " . $stmt->error);
    }
}

// Get success message if any
$success_message = isset($_SESSION['success_message']) ? $_SESSION['success_message'] : '';
unset($_SESSION['success_message']);

// Fetch appointment history and patient details
$sql = "SELECT a.*, d.name as doctor_name, d.speciality, p.name as patient_name, 
        DATE_FORMAT(a.created_at, '%Y-%m-%d %H:%i:%s') as booking_date,
        DATE_FORMAT(a.date_time, '%Y-%m-%d %H:%i:%s') as appointment_date,
        a.reason, a.status
        FROM appointments a 
        JOIN doctors d ON a.doctor_id = d.id 
        JOIN patients p ON a.patient_id = p.id 
        WHERE a.patient_id = ? 
        ORDER BY a.created_at DESC";

$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $patient_id);
$stmt->execute();
$result = $stmt->get_result();

// Debug output
if ($stmt->error) {
    echo "Error: " . $stmt->error;
    exit();
}

// Check if any appointments were found
if ($result && $result->num_rows > 0) {
    // Store the first row to verify data
    $first_row = $result->fetch_assoc();
    $result->data_seek(0); // Reset pointer
}
?>

<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>My Appointment History - MediSched</title>
    <link href="assets/css/bootstrap.css" rel="stylesheet" />
    <link href="assets/css/font-awesome.css" rel="stylesheet" />
    <link href="assets/css/custom.css" rel="stylesheet" />
    <link href="assets/js/dataTables/dataTables.bootstrap.css" rel="stylesheet" />
    <style>
        .status-pending { color: #f39c12; }
        .status-confirmed { color: #00a65a; }
        .status-cancelled { color: #dd4b39; }
        .booking-date {
            font-size: 0.9em;
            color: #666;
        }
    </style>
</head>
<body>
    <div id="wrapper">
        <?php include 'header.php'; ?>
        <div id="page-wrapper">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-12">
                        <h2 class="page-header">My Appointment History</h2>
                        
                        <?php if ($success_message): ?>
                            <div class="alert alert-success">
                                <?php echo htmlspecialchars($success_message); ?>
                            </div>
                        <?php endif; ?>

                        <div class="panel panel-default">
                            <div class="panel-heading" style="background-color:#a01f62;color:white;">
                                Appointment History
                            </div>
                            <div class="panel-body">
                                <div class="table-responsive">
                                    <table id="appointmentTable" class="table table-striped table-bordered table-hover">
                                        <thead>
                                            <tr>
                                                <th>Doctor</th>
                                                <th>Specialization</th>
                                                <th>Appointment Date & Time</th>
                                                <th>Booking Date</th>
                                                <th>Reason</th>
                                                <th>Appointment Status</th>
                                                <th>Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php
                                            if ($result && $result->num_rows > 0) {
                                                while($row = $result->fetch_assoc()) {
                                                    $appointmentId = $row['id'];
                                                    $status = strtolower($row['status']);
                                                    $cancelButton = '';
                                                    
                                                    // Add cancel button only for pending appointments
                                                    if ($status === 'pending') {
                                                        $cancelButton = "
                                                            <td>
                                                                <button onclick='handleCancelAppointment($appointmentId)' 
                                                                        class='btn btn-danger btn-sm'>
                                                                    Cancel
                                                                </button>
                                                            </td>
                                                        ";
                                                    }
                                                    
                                                    echo "<tr>
                                                        <td>" . htmlspecialchars($row['doctor_name']) . "</td>
                                                        <td>" . htmlspecialchars($row['speciality']) . "</td>
                                                        <td>" . date('M d, Y h:i A', strtotime($row['appointment_date'])) . "</td>
                                                        <td>" . htmlspecialchars($row['booking_date']) . "</td>
                                                        <td>" . htmlspecialchars($row['reason']) . "</td>
                                                        <td class='status-" . $status . "'><span class='fa fa-circle'></span> " . htmlspecialchars($row['status']) . "</td>
                                                        " . $cancelButton . "
                                                    </tr>";
                                                }
                                            } else {
                                                echo "<tr><td colspan='7' class='text-center'>No appointments found</td></tr>";
                                            }
                                            ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script src="assets/js/jquery-1.10.2.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>
    <script src="assets/js/dataTables/jquery.dataTables.js"></script>
    <script src="assets/js/dataTables/dataTables.bootstrap.js"></script>
    <script>
        $(document).ready(function() {
            $('#appointmentTable').DataTable({
                "order": [[3, "desc"]], // Order by booking date column (4th column)
                "pageLength": 10,
                "columns": [
                    { 
                        "data": "doctor_name",
                        "render": function(data, type, row) {
                            return data;
                        }
                    },
                    { 
                        "data": "speciality",
                        "render": function(data, type, row) {
                            return data;
                        }
                    },
                    { 
                        "data": "appointment_date",
                        "render": function(data, type, row) {
                            return data ? new Date(data).toLocaleString('en-US', { 
                                month: 'short',
                                day: 'numeric',
                                year: 'numeric',
                                hour: 'numeric',
                                minute: '2-digit',
                                hour12: true
                            }) : '';
                        }
                    },
                    { 
                        "data": "booking_date",
                        "render": function(data, type, row) {
                            return data;
                        }
                    },
                    { 
                        "data": "reason",
                        "render": function(data, type, row) {
                            return data;
                        }
                    },
                    { 
                        "data": "status",
                        "render": function(data, type, row) {
                            return '<span class="fa fa-circle"></span> ' + data;
                        }
                    },
                    { 
                        "data": "action",
                        "render": function(data, type, row) {
                            return data;
                        }
                    }
                ],
                "language": {
                    "emptyTable": "No appointments found",
                    "zeroRecords": "No matching appointments found"
                }
            });

            function handleCancelAppointment(appointmentId) {
                if (confirm('Are you sure you want to cancel this appointment?')) {
                    const cancelBtn = document.querySelector(`button[onclick="handleCancelAppointment(${appointmentId})"]`);
                    cancelBtn.disabled = true;
                    cancelBtn.innerHTML = '<span class="spinner-border spinner-border-sm" role="status"></span> Processing';

                    fetch('cancel_appointment.php', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json',
                        },
                        body: JSON.stringify({ appointment_id: appointmentId })
                    })
                    .then(response => response.json())
                    .then(data => {
                        if (data.success) {
                            location.reload(); // Refresh the page to show updated status
                        } else {
                            alert(data.message);
                            cancelBtn.disabled = false;
                            cancelBtn.innerHTML = 'Cancel';
                        }
                    })
                    .catch(error => {
                        console.error('Error:', error);
                        alert('Failed to cancel appointment');
                        cancelBtn.disabled = false;
                        cancelBtn.innerHTML = 'Cancel';
                    });
                }
            }
        });
    </script>
</body>
</html>
<?php
$stmt->close();
$conn->close();
?>