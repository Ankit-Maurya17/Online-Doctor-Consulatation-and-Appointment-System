<?php
session_start();
header('Content-Type: application/json');

// Database connection
$conn = new mysqli("localhost", "root", "", "Medisched_db");

if ($conn->connect_error) {
    echo json_encode(['success' => false, 'message' => 'Database connection failed']);
    exit();
}

// Check if user is logged in
if(!isset($_SESSION['user'])) {
    echo json_encode(['success' => false, 'message' => 'Unauthorized access']);
    exit();
}

// Get JSON data
$json = file_get_contents('php://input');
$data = json_decode($json, true);

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $appointment_id = $data['appointment_id'] ?? null;
    
    if(empty($appointment_id)) {
        echo json_encode(['success' => false, 'message' => 'Appointment ID is required']);
        exit();
    }

    // Verify appointment belongs to this patient
    $patient_email = $_SESSION['user'];
    $stmt = $conn->prepare("SELECT p.id FROM patients p 
                            JOIN appointments a ON p.id = a.patient_id 
                            WHERE p.email = ? AND a.id = ?");
    $stmt->bind_param("si", $patient_email, $appointment_id);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if($result->num_rows === 0) {
        echo json_encode(['success' => false, 'message' => 'Appointment not found or unauthorized']);
        exit();
    }

    // Update appointment status
    $update_stmt = $conn->prepare("UPDATE appointments 
                                  SET status = 'Cancelled', 
                                      updated_at = NOW() 
                                  WHERE id = ?");
    $update_stmt->bind_param("i", $appointment_id);
    
    if($update_stmt->execute()) {
        echo json_encode(['success' => true, 'message' => 'Appointment cancelled successfully']);
    } else {
        echo json_encode(['success' => false, 'message' => 'Failed to cancel appointment']);
    }
    
    $update_stmt->close();
} else {
    echo json_encode(['success' => false, 'message' => 'Invalid request method']);
}

$conn->close();
?>
