<?php
session_start();
include('../includes/refresh_session.php');

// Database connection
$conn = new mysqli("localhost", "root", "", "Medisched_db");

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get patient data from POST request
$data = json_decode(file_get_contents('php://input'), true);

if (!$data || !isset($data['email'])) {
    echo json_encode([
        'success' => false,
        'message' => 'Invalid patient data'
    ]);
    exit;
}

// Check if patient exists
$sql = "SELECT * FROM patients WHERE email = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $data['email']);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $patient = $result->fetch_assoc();
    echo json_encode([
        'success' => true,
        'patient' => [
            'name' => $patient['name'],
            'age' => $data['age'],
            'gender' => $data['gender'],
            'contact' => $patient['phone'],
            'email' => $patient['email']
        ]
    ]);
} else {
    // Create new patient record
    $insert_sql = "INSERT INTO patients (name, phone, email) VALUES (?, ?, ?)";
    $stmt = $conn->prepare($insert_sql);
    $stmt->bind_param("sss", 
        $data['name'],
        $data['contact'],
        $data['email']
    );
    
    if ($stmt->execute()) {
        echo json_encode([
            'success' => true,
            'patient' => [
                'name' => $data['name'],
                'age' => $data['age'],
                'gender' => $data['gender'],
                'contact' => $data['contact'],
                'email' => $data['email']
            ]
        ]);
    } else {
        echo json_encode([
            'success' => false,
            'message' => 'Failed to create patient record: ' . $conn->error
        ]);
    }
}

$conn->close();
