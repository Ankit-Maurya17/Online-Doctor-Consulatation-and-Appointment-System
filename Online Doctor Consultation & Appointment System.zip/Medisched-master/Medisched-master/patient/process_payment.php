<?php
session_start();
include('../includes/refresh_session.php');

// Database connection
$conn = new mysqli("localhost", "root", "", "Medisched_db");

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get payment details
    $appointment_id = $_POST['appointment_id'] ?? '';
    $payment_id = $_POST['payment_id'] ?? '';
    $amount = $_POST['amount_due'] ?? 0;
    
    // Validate required fields
    if(empty($appointment_id)) {
        $_SESSION['error'] = "Invalid appointment";
        header("Location: appointment_history.php");
        exit();
    }
    
    // Get appointment details
    $sql = "SELECT * FROM appointments WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $appointment_id);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if($result->num_rows === 0) {
        $_SESSION['error'] = "Appointment not found";
        header("Location: appointment_history.php");
        exit();
    }
    
    // Verify Razorpay payment
    $razorpay_key = "rzp_test_YOUR_KEY_HERE"; // Replace with your Razorpay key
    $razorpay_secret = "YOUR_SECRET_HERE"; // Replace with your Razorpay secret

    $url = "https://api.razorpay.com/v1/payments/" . $payment_id;
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_USERPWD, $razorpay_key . ":" . $razorpay_secret);
    $response = curl_exec($ch);
    curl_close($ch);

    $payment_details = json_decode($response, true);
    $payment_status = ($payment_details['status'] === 'captured') ? 'Completed' : 'Failed';
    
    // Update appointment payment status
    $update_sql = "UPDATE appointments SET 
                   payment_status = ?, 
                   payment_mode = 'Razorpay', 
                   payment_id = ?,
                   amount_paid = ? 
                   WHERE id = ?";
    
    $stmt = $conn->prepare($update_sql);
    $stmt->bind_param("ssdi", 
        $payment_status,
        $payment_id,
        $amount,
        $appointment_id
    );
    
    if($stmt->execute()) {
        // Generate booking slip
        header("Location: generate_booking_slip.php?appointment_id=" . $appointment_id);
        exit();
    } else {
        $_SESSION['error'] = "Error processing payment: " . $conn->error;
        header("Location: appointment_history.php");
        exit();
    }
}


?>
