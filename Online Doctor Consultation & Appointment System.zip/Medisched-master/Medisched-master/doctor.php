<?php
session_start(); 	
include("header.php");
include("find.php");
?>
<body onload="initialize()">
<div class="container">
	<div class="row">
		<div class="col-lg-7">
			<div class="join-now-doc">
				<h3 style="text-align:center;">
					<?php  
					if (isset($_SESSION['success'])) { 
						echo "Successfully registered!";
						unset($_SESSION['success']); // Unset only the success message
					} 
					?>
				</h3>
			</div>
			<div class="join-now-doc">
				<h3>Join now</h3>
			</div>
			<div class="row">
				<div class="join-now-doc-1">
					<form role="form" action="registration.php" method="post" data-parsley-validate class="validate" enctype="multipart/form-data">
						<div class="col-lg-6">
							<input type="hidden" name="status" id="status" value="2">

							<div class="form-group<input type="text" class="form-control" id="name" name="name" placeholder="Enter Name" required pattern="[A-Za-z\s]+" title="Only letters and spaces are allowed for the name">">
								<label for="email">Email</label>
								<input type="email" class="form-control" id="email" name="email" required placeholder="Enter Email">
							</div>

							<div class="form-group">
								<label for="name">Full Name</label>
								<input type="text" class="form-control" id="name" name="name" placeholder="Enter Name" required pattern="[A-Za-z\s]+" title="Only letters and spaces are allowed for the name">
							</div>

							<div class="form-group">
								<label for="phone">Contact</label>
								<input type="text" class="form-control" id="phone" name="phone" placeholder="Enter Phone" required pattern="^\d{10}$" maxlength="10" title="Please enter exactly 10 digits for the phone number">
							</div>

							<div class="form-group">
								<label for="schedule">Select Your Schedule</label>						
								<select class="form-control" id="schedule" name="time">
									<option disabled selected>Select Time</option>
									<option value="10 AM to 5 PM">10 AM to 5 PM</option>
									<option value="5 PM to 10 PM">5 PM to 10 PM</option>
									<option value="10 PM to 5 AM">10 PM to 5 AM</option>
								</select>
							</div>

							<div class="form-group">
								<label for="desc">Description</label>
								<textarea class="form-control" id="desc" style="resize: none;" rows="3" name="desc" required></textarea>	
							</div>

							<div class="form-group">
								<label>Sex</label>
								<div class="radio">
									<label><input type="radio" name="sex" value="Male"> Male</label>
								</div>
								<div class="radio">
									<label><input type="radio" name="sex" value="Female"> Female</label>
								</div>
							</div>                        
						</div>

						<div class="col-lg-6">
							<div class="form-group">
								<label for="password">Password</label>
								<input type="password" class="form-control" id="password" name="pass" placeholder="* * * *" required>
							</div>

							<div class="form-group">
								<label for="address">Address</label>
								<input type="text" class="form-control" id="address" name="address" placeholder="Enter Address" required>
							</div>

							<div class="form-group">
								<label for="fees">Select Your Fees</label>						
								<select class="form-control" id="fees" name="fees">
									<option disabled selected>Select Fee</option>
									<option value="Rs. 500">Rs. 500</option>
									<option value="Rs. 1000">Rs. 1000</option>
									<option value="Rs. 1500">Rs. 1500</option>
									<option value="Rs. 2000">Rs. 2000</option>
								</select>
							</div>

							<div class="form-group">
								<label for="special">Select Your Speciality</label>
								<select class="form-control" id="special" name="special" required>
									<option disabled selected>Select Speciality</option>
									<option value="Audiology">Audiology</option>
									<option value="Cardiology">Cardiology</option>
									<option value="Dentistry">Dentistry</option>
									<option value="Diabetology">Diabetology</option>
									<option value="Children Medicine">Children Medicine</option>
									<option value="Radiology">Radiology</option>
									<option value="Hepatology">Hepatology</option>
									<option value="Optician">Optician</option>
									<option value="Nephrology">Nephrology</option>
									<option value="Neurology">Neurology</option>
								</select>
							</div>							                              

							<div class="form-group">
								<label for="city">Select Your Location</label>
								<select class="form-control" id="city" name="city" required>
									<option disabled selected>Select The City</option>
									<option value="Swaroop Rani Narsing Home Prayagraj">Swaroop Rani Narsing Home Prayagraj</option>
									<option value="Tej Bahadur Sapru Hospital Beli 'Prayagraj'">Tej Bahadur Sapru Hospital Beli Prayagraj</option>
									<option value="BHU 'varanasi'">BHU Varanasi</option>
									<option value="Appex 'Varanasi'">Appex Varanasi</option>
									<option value="KGMU Lucknow">KGMU Lucknow</option>
									<option value="PGI 'Lucknow'">PGI Lucknow</option>
									<option value="AIMS 'Delhi'">AIMS Delhi</option>
									<option value="Sadar Hospital'Jaunpur'">Sadar Hospital Jaunpur</option>
									<option value="Yash Hospital 'Pratika Chauraha Prayagraj'">Yash Hospital Pratika Chauraha Prayagraj</option>
								</select>
							</div>

							<div class="checkbox">
								<label><input type="checkbox" value="agreed" name="terms" required> I Agree to the Terms and Conditions</label>
							</div>

							<div class="form-group">
								<button type="submit" name="doctor" class="btn btn-default btn-continue">Continue</button>
							</div>
						</div>
					</form>
				</div>
			</div>
		</div>
	</div>
</div>
<?php include("footer.php"); ?>
