-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 02, 2025 at 09:25 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `medisched_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `appointments`
--

CREATE TABLE `appointments` (
  `id` int(11) NOT NULL,
  `patient_id` int(11) NOT NULL,
  `doctor_id` int(11) NOT NULL,
  `date_time` datetime NOT NULL,
  `amount_due` decimal(10,2) NOT NULL,
  `status` enum('Pending','Confirmed','Cancelled') DEFAULT 'Pending',
  `reason` text DEFAULT NULL,
  `payment_status` enum('Pending','Paid') DEFAULT 'Pending',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `appointments`
--

INSERT INTO `appointments` (`id`, `patient_id`, `doctor_id`, `date_time`, `amount_due`, `status`, `reason`, `payment_status`, `created_at`, `updated_at`) VALUES
(1, 1, 1, '0000-00-00 00:00:00', 2023.00, 'Pending', NULL, 'Pending', '2025-03-28 07:31:37', '2025-03-28 07:31:37'),
(2, 2, 2, '0000-00-00 00:00:00', 2023.00, 'Pending', NULL, 'Pending', '2025-03-28 07:31:37', '2025-03-28 07:31:37'),
(3, 3, 3, '0000-00-00 00:00:00', 2023.00, 'Pending', NULL, 'Pending', '2025-03-28 07:31:37', '2025-03-28 07:31:37'),
(4, 4, 4, '0000-00-00 00:00:00', 2023.00, 'Pending', NULL, 'Pending', '2025-03-28 07:31:37', '2025-03-28 07:31:37'),
(5, 5, 5, '0000-00-00 00:00:00', 2023.00, 'Pending', NULL, 'Pending', '2025-03-28 07:31:37', '2025-03-28 07:31:37'),
(6, 1, 1, '0000-00-00 00:00:00', 2023.00, 'Pending', NULL, 'Pending', '2025-03-28 07:34:15', '2025-03-28 07:34:15'),
(7, 2, 2, '0000-00-00 00:00:00', 2023.00, 'Pending', NULL, 'Pending', '2025-03-28 07:34:15', '2025-03-28 07:34:15'),
(8, 3, 3, '0000-00-00 00:00:00', 2023.00, 'Pending', NULL, 'Pending', '2025-03-28 07:34:15', '2025-03-28 07:34:15'),
(9, 4, 4, '0000-00-00 00:00:00', 2023.00, 'Pending', NULL, 'Pending', '2025-03-28 07:34:15', '2025-03-28 07:34:15'),
(10, 5, 5, '0000-00-00 00:00:00', 2023.00, 'Pending', NULL, 'Pending', '2025-03-28 07:34:15', '2025-03-28 07:34:15'),
(11, 1, 1, '0000-00-00 00:00:00', 2023.00, 'Pending', NULL, 'Pending', '2025-03-28 07:59:06', '2025-03-28 07:59:06'),
(12, 2, 2, '0000-00-00 00:00:00', 2023.00, 'Pending', NULL, 'Pending', '2025-03-28 07:59:06', '2025-03-28 07:59:06'),
(13, 3, 3, '0000-00-00 00:00:00', 2023.00, 'Pending', NULL, 'Pending', '2025-03-28 07:59:06', '2025-03-28 07:59:06'),
(14, 4, 4, '0000-00-00 00:00:00', 2023.00, 'Pending', NULL, 'Pending', '2025-03-28 07:59:06', '2025-03-28 07:59:06'),
(15, 5, 5, '0000-00-00 00:00:00', 2023.00, 'Pending', NULL, 'Pending', '2025-03-28 07:59:06', '2025-03-28 07:59:06'),
(16, 1, 1, '0000-00-00 00:00:00', 2023.00, 'Pending', NULL, 'Pending', '2025-03-28 08:07:18', '2025-03-28 08:07:18'),
(17, 2, 2, '0000-00-00 00:00:00', 2023.00, 'Pending', NULL, 'Pending', '2025-03-28 08:07:18', '2025-03-28 08:07:18'),
(18, 3, 3, '0000-00-00 00:00:00', 2023.00, 'Pending', NULL, 'Pending', '2025-03-28 08:07:18', '2025-03-28 08:07:18'),
(19, 4, 4, '0000-00-00 00:00:00', 2023.00, 'Pending', NULL, 'Pending', '2025-03-28 08:07:18', '2025-03-28 08:07:18'),
(20, 5, 5, '0000-00-00 00:00:00', 2023.00, 'Pending', NULL, 'Pending', '2025-03-28 08:07:18', '2025-03-28 08:07:18'),
(21, 1, 1, '0000-00-00 00:00:00', 100.00, 'Pending', NULL, 'Pending', '2025-04-01 05:57:57', '2025-04-01 05:57:57'),
(22, 2, 2, '0000-00-00 00:00:00', 200.00, 'Pending', NULL, 'Pending', '2025-04-01 05:57:57', '2025-04-01 05:57:57'),
(23, 3, 3, '0000-00-00 00:00:00', 300.00, 'Pending', NULL, 'Pending', '2025-04-01 05:57:57', '2025-04-01 05:57:57'),
(24, 4, 4, '0000-00-00 00:00:00', 400.00, 'Pending', NULL, 'Pending', '2025-04-01 05:57:57', '2025-04-01 05:57:57'),
(25, 5, 5, '0000-00-00 00:00:00', 500.00, 'Pending', NULL, 'Pending', '2025-04-01 05:57:57', '2025-04-01 05:57:57');

-- --------------------------------------------------------

--
-- Table structure for table `bookings`
--

CREATE TABLE `bookings` (
  `id` int(11) NOT NULL,
  `patient` varchar(255) NOT NULL,
  `contact` varchar(20) NOT NULL,
  `address` text NOT NULL,
  `problem` text NOT NULL,
  `doctor` varchar(255) NOT NULL,
  `speciality` varchar(255) NOT NULL,
  `fees` decimal(10,2) NOT NULL,
  `schedule` varchar(50) NOT NULL,
  `location` varchar(255) NOT NULL,
  `user` varchar(255) NOT NULL,
  `type` enum('online','offline') NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `bookings`
--

INSERT INTO `bookings` (`id`, `patient`, `contact`, `address`, `problem`, `doctor`, `speciality`, `fees`, `schedule`, `location`, `user`, `type`, `created_at`, `updated_at`) VALUES
(2, 'Ankit Maurya', '8303861034', 'srk hostel old katra prayagraj', 'ear problem', 'Abhishek Maurya', 'Audiology', 500.00, 'morning', 'BHU varanasi', 'am138117@gmail.com', 'online', '2025-03-28 09:50:45', '2025-03-28 09:50:45'),
(3, 'Shyam Pratap', '9876543210', 'Rajapur Prayagraj', 'not voice clear hearing ', 'Abhishek Maurya', 'Audiology', 500.00, 'morning', 'BHU varanasi', 'am138117@gmail.com', 'online', '2025-03-28 10:13:28', '2025-03-28 10:13:28'),
(4, 'lorens', '9876543210', 'salori prayagraj', 'ear prpblem', 'Abhishek Maurya', 'Audiology', 500.00, 'morning', 'BHU varanasi', 'am138117@gmail.com', 'online', '2025-03-28 10:17:22', '2025-03-28 10:17:22');

-- --------------------------------------------------------

--
-- Table structure for table `doctors`
--

CREATE TABLE `doctors` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `speciality` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `schedule` varchar(50) NOT NULL,
  `description` text NOT NULL,
  `sex` enum('male','female') NOT NULL,
  `address` text DEFAULT NULL,
  `amount_due` decimal(10,2) NOT NULL,
  `location` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `doctors`
--

INSERT INTO `doctors` (`id`, `name`, `speciality`, `email`, `password`, `phone`, `schedule`, `description`, `sex`, `address`, `amount_due`, `location`, `created_at`, `updated_at`) VALUES
(2, 'Dr. Ravi Sharma', 'Audiology', 'ravisharma@gmail.com', '123456', '1122334455', '10 AM to 5 PM', ' A healthcare professional specializing in the diagnosis, assessment, and management of hearing, balance, and related disorders, including tinnitus and auditory processing    ', 'male', 'Swaroop Rani Narsing Home, Prayagraj', 500.00, 'Swaroop Rani Narsing Home, Prayagraj', '2025-03-30 10:33:06', '2025-03-30 12:41:42'),
(3, 'Dr. Priya Mehra', 'Cardiology', 'priyamehra@gmail.com', '123456', '1122334455', '5 PM to 10 PM', 'a physician specializing in the diagnosis, treatment, and prevention of diseases and conditions affecting the heart and blood vessels, including the circulatory system. ', 'female', 'PGI LUCKNOW', 1000.00, 'PGI, Lucknow', '2025-03-30 13:08:14', '2025-03-30 13:13:49'),
(4, 'Dr. Neha Kapoor ', 'Dentistry', 'nehakapoor@gmail.com', '123456', '1122334455', '10 PM to 5 AM', 'A branch of medicine focused on the teeth, gums, and mouth, encompassing the study, diagnosis, prevention, and treatment of diseases, disorders, and conditions of the oral cavity. ', 'female', 'BHU VARANASI', 1500.00, 'BHU, Varanasi', '2025-03-31 11:02:18', '2025-03-31 11:14:51'),
(9, 'Dr. Priya Sharma', 'Radiology', 'priyasharma@gmail.com', '123456', '1122334455', '10 AM to 5 PM', 'GOOD DOCTOR ', 'female', 'KGMU LUCKNOW', 1000.00, 'KGMU LUCKNOW', '2025-04-01 07:02:46', '2025-04-01 18:15:48'),
(10, 'Dr. Suraj Bhattacharya', 'Hepatology', 'surajbhattcharya@gmail.com', '123456', '1122334455', '10 AM to 5 PM', 'Good experience Doctor', 'male', 'Sadar Hospital, Jaunpur', 500.00, 'Sadar Hospital, Jaunpur', '2025-04-01 07:06:38', '2025-04-01 18:18:41'),
(11, 'Dr. Sameer Jain', 'Optician', 'sameerjain@gmail.com', '123456', '1122334455', '10 AM to 5 PM', 'good experience doctor', 'male', 'Swaroop Rani Narsing Home, Prayagraj', 1000.00, 'Swaroop Rani Narsing Home, Prayagraj', '2025-04-01 07:09:21', '2025-04-01 18:19:06'),
(12, 'Dr. Sanjay Soni ', 'Neurology', 'sanjaysoni@gmail.com', '123456', '1122334455', '10 AM to 5 PM', 'good experience doctor', 'male', 'AIMS, Delhi', 1500.00, 'AIMS, Delhi', '2025-04-01 07:10:37', '2025-04-01 18:19:22'),
(13, 'Dr. Nisha Mehta', 'Children Medicine', 'nishamehta@gmail.com', '123456', '1122334455', '5 PM to 10 PM', 'good experience doctor', 'female', 'Swaroop Rani Narsing Home, Prayagraj)', 500.00, 'Swaroop Rani Narsing Home, Prayagraj', '2025-04-01 07:12:26', '2025-04-01 18:20:28'),
(14, 'Dr. Pooja Verma', 'Audiology', 'poojaverma@gmail.com', '123456', '1122334455', '5 PM to 10 PM', 'good experience doctor', 'female', 'Tej Bahadur Sapru Hospital Beli, Prayagraj', 1000.00, 'Tej Bahadur Sapru Hospital Beli, Prayagraj', '2025-04-01 07:14:11', '2025-04-01 18:19:41'),
(15, 'Dr. Anil Kumar', 'Audiology', 'anilkumar@gmail.com', '123456', '1122334455', '10 AM to 5 PM', 'Good experience doctor', 'male', 'BHU Varanasi', 500.00, 'BHU, Varanasi', '2025-04-01 07:15:59', '2025-04-01 18:20:05'),
(16, 'Dr. Neha Singh', 'Audiology', 'nehasingh@gmail.com', '123456', '1122334455', '5 PM to 10 PM', 'Good experience doctor ', 'female', 'Appex Varanasi', 500.00, 'Appex, Varanasi', '2025-04-01 07:20:20', '2025-04-01 18:16:51');

-- --------------------------------------------------------

--
-- Table structure for table `patients`
--

CREATE TABLE `patients` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `password` varchar(255) NOT NULL,
  `address` text DEFAULT NULL,
  `doctor` varchar(255) DEFAULT NULL,
  `amount_due` decimal(10,2) DEFAULT NULL,
  `payment_status` enum('Pending','Paid') DEFAULT 'Pending',
  `appointment_date` date DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `email` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `patients`
--

INSERT INTO `patients` (`id`, `name`, `phone`, `password`, `address`, `doctor`, `amount_due`, `payment_status`, `appointment_date`, `created_at`, `updated_at`, `email`) VALUES
(1, 'John Doe', '1234567890', '', NULL, NULL, NULL, 'Pending', NULL, '2025-04-01 05:57:57', '2025-04-01 05:57:57', 'john@example.com'),
(2, 'Jane Smith', '9876543210', '', NULL, NULL, NULL, 'Pending', NULL, '2025-04-01 05:57:57', '2025-04-01 05:57:57', 'jane@example.com'),
(4, 'Sarah Johnson', '1112223333', '', NULL, NULL, NULL, 'Pending', NULL, '2025-04-01 05:57:57', '2025-04-01 05:57:57', 'sarah@example.com'),
(5, 'David Wilson', '4445556666', '', NULL, NULL, NULL, 'Pending', NULL, '2025-04-01 05:57:57', '2025-04-01 05:57:57', 'david@example.com');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `appointments`
--
ALTER TABLE `appointments`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `bookings`
--
ALTER TABLE `bookings`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `doctors`
--
ALTER TABLE `doctors`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `patients`
--
ALTER TABLE `patients`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `appointments`
--
ALTER TABLE `appointments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT for table `bookings`
--
ALTER TABLE `bookings`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `doctors`
--
ALTER TABLE `doctors`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `patients`
--
ALTER TABLE `patients`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
