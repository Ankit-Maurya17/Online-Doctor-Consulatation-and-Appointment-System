<?php include("header.php"); ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <link href='http://fonts.googleapis.com/css?family=Creepster|Audiowide' rel='stylesheet' type='text/css'>
    <title>Error</title>
</head>
<body>
<div class="container-fluid about-bac-another">
    <div class="container">
        <div class="f-f4">
            <h1><img src="assets/images/home/404.png" /></h1>
            <h2>error <span>404!</span></h2>
            <h3>Oops! Seems like some unexpected error has occurred.</h3>
            <h4>Please <a href="index.php">click here</a> to go to the home page.</h4>
        </div>
    </div>
</div>
</body>
</html>
<!--footer-->
<?php include("footer.php"); ?>