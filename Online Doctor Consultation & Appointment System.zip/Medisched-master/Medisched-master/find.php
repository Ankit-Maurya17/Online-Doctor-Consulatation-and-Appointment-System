<div class="find-main col-lg-6 nopadding">
    <div  onclick="mysigninFunction()" data-toggle="modal"  data-target="#myModal" class="find col-lg-1 nopadding">
        <img src="assets/images/home/find.png"  alt=""/>
    </div>
	
    
</div>