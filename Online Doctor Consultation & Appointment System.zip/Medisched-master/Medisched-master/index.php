					<?php
					include("header.php");
					include("find.php");
					?>
<body onload="initialize()"><!--banner-section-->
<div class="container-fluid">
    <div class="banner">
        <div class="container">
            <div class="col-lg-12">
                <div class="banner-text animated fadeInLeft">
                    <h3>Keep your</h3>
                    <h2>Family More Healthy</h2>
                    <p>Smart appointment booking system that provides patients or any user an easy way of booking a doctor‟s appointment online.</p>																																																								</p>
                    
                    <div class="scroll">
                        <img class="hvr-grow" src="assets/images/home/scroll.png" alt=""/>
                        <h3 >Scroll Down</h3>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!--banner-section-->
<!--map-section-->
<div class="container-fluid">
    <div class="map">
        <div class="man">
            <img src="assets/images/home/man.png" class="img-responsive animated fadeInDown" alt=""/>
        </div>
        <div class="container">
            <div class="map-text">
                <h3>HEALTHCARE AT YOUR DEMAND !</h3>
                <h4>Find a nearby doctor or dentist and book an appointment instantly. And it's free !</span></h4>
            </div>
        </div>
    </div>

</div>
<?php include("footer.php"); ?>