<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

function refresh_session_data($user_type) {
    // Database connection
    $conn = new mysqli("localhost", "root", "", "Medisched_db");
    
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Get user ID from session
    $user_id = $_SESSION['user'] ?? '';
    
    if (empty($user_id)) {
        return;
    }

    try {
        // Get user data based on user type
        switch($user_type) {
            case 'admin':
                $sql = "SELECT * FROM admins WHERE id = ?";
                break;
            case 'doctor':
                $sql = "SELECT * FROM doctors WHERE id = ?";
                break;
            case 'patient':
                $sql = "SELECT * FROM patients WHERE id = ?";
                break;
            default:
                return;
        }

        $stmt = $conn->prepare($sql);
        if (!$stmt) {
            throw new Exception("Error preparing statement: " . $conn->error);
        }

        $stmt->bind_param("i", $user_id);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            $user_data = $result->fetch_assoc();
            
            // Update session data
            $_SESSION['user_data'] = $user_data;
            
            // Update any specific fields
            switch($user_type) {
                case 'admin':
                    $_SESSION['name'] = $user_data['name'];
                    $_SESSION['email'] = $user_data['email'];
                    break;
                case 'doctor':
                    $_SESSION['name'] = $user_data['name'];
                    $_SESSION['speciality'] = $user_data['speciality'];
                    break;
                case 'patient':
                    $_SESSION['name'] = $user_data['name'];
                    $_SESSION['contact'] = $user_data['contact'];
                    break;
            }
        }

        $stmt->close();
        $conn->close();
    } catch (Exception $e) {
        error_log("Error refreshing session data: " . $e->getMessage());
    }
}

// After any data change (add/edit/delete), call this function
function refresh_after_change($user_type) {
    refresh_session_data($user_type);
    
    // Redirect to appropriate page
    switch($user_type) {
        case 'admin':
            header("Location: admin/index.php");
            break;
        case 'doctor':
            header("Location: doctor/index.php");
            break;
        case 'patient':
            header("Location: patient/index.php");
            break;
    }
    exit();
}
?>
