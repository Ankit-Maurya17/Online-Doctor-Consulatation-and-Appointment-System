<?php
session_start();

// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get form data
    $appointment_id = isset($_POST["appointment_id"]) ? (int)$_POST["appointment_id"] : 0;
    $reason = isset($_POST["reason"]) ? trim($_POST["reason"]) : '';
    
    // Validate inputs
    if ($appointment_id <= 0) {
        echo "<div class='alert alert-danger'>Invalid appointment ID.</div>";
        exit();
    }

    try {
        // Connect to database
        $conn = new mysqli("localhost", "root", "", "medisched_db");
        
        if ($conn->connect_error) {
            throw new Exception("Connection failed: " . $conn->connect_error);
        }

        // Update the appointment status and add cancellation reason
        $sql = "UPDATE appointments SET 
            status = 'Cancelled',
            reason = ?,
            updated_at = NOW()
            WHERE id = ?";
        
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("si", $reason, $appointment_id);
        
        if ($stmt->execute()) {
            echo "<div class='alert alert-success'>Appointment cancelled successfully!</div>";
            echo "<script>
                setTimeout(function() {
                    window.location.href = 'appointment_list.php';
                }, 2000);
            </script>";
        } else {
            echo "<div class='alert alert-danger'>Failed to cancel appointment. Please try again.</div>";
        }
        
        $stmt->close();
        $conn->close();
    } catch (Exception $e) {
        echo "<div class='alert alert-danger'>Error: " . $e->getMessage() . "</div>";
    }
}
?>
